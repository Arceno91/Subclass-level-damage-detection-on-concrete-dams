# Result files

Every number in the manuscript traces to one of these files. The archive flattens the
authors' `runs/` layout into single file names (`__` = path separator), so the mapping table
below also gives the original path.

| File here | Original path in the working tree | Paper item |
|---|---|---|
| `runs__metrics_suite__metrics.json` | `runs/metrics_suite/metrics.json` | §4.1 baseline (3 seeds) |
| `runs__metrics_suite__suite_20260915.json` | `runs/metrics_suite/suite_20260915.json` | §4.1/§4.8 unified metric suite |
| `runs__e16_method__results.json` | `runs/e16_method/results.json` | §4.12 DACW/DAAA/DBJT (seed 42) |
| `runs__e16_method__seed123__results.json` | `runs/e16_method/seed123/results.json` | §4.12 seeds 123 |
| `runs__e16_method__seed456__results.json` | `runs/e16_method/seed456/results.json` | §4.12 seeds 456 |
| `runs__e15_dsi__dsi2_yolo11n_metrics.json` | `runs/e15_dsi/dsi2_yolo11n_metrics.json` | §4.14 DSI 2-class |
| `runs__e15_dsi__dsi5_yolo11n_metrics.json` | `runs/e15_dsi/dsi5_yolo11n_metrics.json` | §4.14 DSI 5-class |
| `runs__e12_cross_batch__results.json` | `runs/e12_cross_batch/results.json` | §4.9 cross-batch |
| `runs__e6_kshot__kshot_results.json` | `runs/e6_kshot/kshot_results.json` | §4.4 K-shot matrix (Table 6) |
| `runs__e6_kshot__diag_results.json` | `runs/e6_kshot/diag_results.json` | §4.4 diagnostics |
| `runs__e10_inc__incremental_results.json` | `runs/e10_inc/incremental_results.json` | §4.11 incremental |
| `runs__e11_novel_probe__probe_results.json` | `runs/e11_novel_probe/probe_results.json` | §4.11 novel-class probe |
| `runs__e13_zoo__detector_zoo.json` | `runs/e13_zoo/detector_zoo.json` | §4.8 detector zoo |
| `runs__sim_imaging__results.json` | `runs/sim_imaging/results.json` | §4.5 imaging envelope (Table 7) |
| `runs__sim_imaging__remedy_results.json` | `runs/sim_imaging/remedy_results.json` | §4.6 remedies (Table 8, self-written pipeline) |
| `runs__sim_imaging__remedy_validator.json` | `runs/sim_imaging/remedy_validator.json` | §4.6 remedy validation |
| `runs__sim_imaging__remedy_clean.json` | `runs/sim_imaging/remedy_clean.json` | §4.6 remedies, unified val() pipeline (Table 8) |
| `runs__e14_detectors__det_v8n__test_metrics.json` | `runs/e14_detectors/det_v8n/test_metrics.json` | §4.8 YOLOv8n |
| `runs__e14_detectors__det_v10n__test_metrics.json` | `runs/e14_detectors/det_v10n/test_metrics.json` | §4.8 YOLOv10n |
| `runs__e17_resolution__reeval_done.json` | `runs/e17_resolution/reeval_done.json` | §4.7 resolution re-evaluation |
| `runs__threshold_tuning__results.json` | `runs/threshold_tuning/results.json` | §4.10 operating point |
| `runs__e8_multi__results_multi.json` | `runs/e8_multi/results_multi.json` | §4.2 multi-seed augmentation (Table 4) |
| `runs__e17_resolution__results.json` | `runs/e17_resolution/results.json` | §4.7 resolution (Table 19) |
| `runs__e18_annot_budget__results.json` | `runs/e18_annot_budget/results.json` | §4.13 annotation budget (Table 20) |
| `runs__e18_annot_budget__learning_curve.csv` | `runs/e18_annot_budget/learning_curve.csv` | §4.13 learning curve |
| `runs__separability__results.json` | `runs/separability/results.json` | §4.3 frequency vs difficulty |
| `runs__separability__per_class_stats.csv` | `runs/separability/per_class_stats.csv` | §4.3 per-class stats |
| `runs__queue_logs__backlog_status.json` | `runs/queue_logs/backlog_status.json` | run provenance / queue log |
