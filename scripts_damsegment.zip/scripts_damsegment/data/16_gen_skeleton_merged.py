# -*- coding: utf-8 -*-
"""
16_gen_skeleton_merged.py — 为 DamCrack-Sub5 生成骨架伪标签（方案D）

与 11_gen_skeleton_labels.py 同规则：OpenCV LSD 在 crack 类(0/1/2) bbox 内提取细线，
输出 datasets/DamCrack-Sub5/skeleton/{train,val,test}/<stem>.png (1ch, 0/255)。

用法: python 16_gen_skeleton_merged.py [--split train,val,test]
"""
import argparse
import json
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main\datasets\DamCrack-Sub5")
OUT = ROOT / "skeleton"
CRACK_CLASSES = (0, 1, 2)
STD = 8


def gen_skeleton(img_bgr, boxes):
    H, W = img_bgr.shape[:2]
    mask = np.zeros((H, W), dtype=np.uint8)
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    lsd = cv2.createLineSegmentDetector(cv2.LSD_REFINE_STD)
    for cls, x1, y1, x2, y2 in boxes:
        if cls not in CRACK_CLASSES:
            continue
        x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
        crop = gray[y1:y2, x1:x2]
        if crop.size < 16:
            continue
        lines = lsd.detect(crop)[0]
        if lines is None:
            continue
        for ln in lines:
            xa, ya, xb, yb = ln[0]
            if np.hypot(xb - xa, yb - ya) < STD:
                continue
            cv2.line(mask, (int(xa) + x1, int(ya) + y1), (int(xb) + x1, int(yb) + y1), 255, 1, cv2.LINE_8)
    return mask


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", default="train,val,test")
    args = ap.parse_args()
    summary = {}
    for split in args.split.split(","):
        img_dir = ROOT / "images" / split
        lbl_dir = ROOT / "labels" / split
        out_dir = OUT / split
        out_dir.mkdir(parents=True, exist_ok=True)
        n_ok = n_missing_img = 0
        for txt in sorted(lbl_dir.glob("*.txt")):
            img_path = img_dir / f"{txt.stem}.jpg"
            if not img_path.exists():
                n_missing_img += 1
                continue
            img = cv2.imread(str(img_path))
            if img is None:
                n_missing_img += 1
                continue
            H, W = img.shape[:2]
            boxes = []
            for ln in txt.read_text(encoding="utf-8", errors="ignore").splitlines():
                ln = ln.strip()
                if not ln:
                    continue
                p = ln.split()
                if len(p) != 5:
                    continue
                c, cx, cy, nw, nh = int(p[0]), float(p[1]), float(p[2]), float(p[3]), float(p[4])
                if c in CRACK_CLASSES:
                    boxes.append((c, (cx - nw / 2) * W, (cy - nh / 2) * H,
                                  (cx + nw / 2) * W, (cy + nh / 2) * H))
            mask = gen_skeleton(img, boxes)
            cv2.imwrite(str(out_dir / f"{txt.stem}.png"), mask)
            n_ok += 1
        summary[split] = {"images": n_ok, "missing": n_missing_img}
        print(f"[{split}] done: {n_ok} ({n_missing_img} missing)")
    (OUT / "manifest.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print("saved to", OUT)


if __name__ == "__main__":
    main()
