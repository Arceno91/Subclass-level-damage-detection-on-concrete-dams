# -*- coding: utf-8 -*-
"""
03_preview_subclasses.py — 子类划分人工校验预览图

从 mapping.csv 读取分类结果，为每个子类抽样 12 个 patch 拼成一张预览图，
输出到 pipeline/preview/subclass_preview.png（含类名标注）。

用途：肉眼检查自动规则是否合理；
  - 若个别框分错：编辑 pipeline/mapping.csv 的 new_class 列，然后
        python 02_subclass_mapping.py --apply-csv
  - 若整体偏好：调 02 脚本顶部阈值（AR_EXTREME / NEIGHBOR_TH / SPALLING_AREA_TH）重跑
"""
import csv
import random
from pathlib import Path

import cv2
import numpy as np

DAMSEG_ROOT = Path(r"E:\Arceno\\harmess\\project\\YOLO-PEFT-main\\datasets\\DamSegment")
ROOT = DAMSEG_ROOT
DST = DAMSEG_ROOT
MAPPING = DAMSEG_ROOT / "metadata" / "mapping.csv"
PREVIEW_DIR = DAMSEG_ROOT / "metadata" / "preview"
CLASS_NAMES = {0: "crack_fine", 1: "crack_network", 2: "crack_blocky", 3: "spalling_small", 4: "spalling_large"}
SAMPLE_PER_CLASS = 12
PATCH_SIZE = 120  # 预览用小图


def load_records():
    recs = {k: [] for k in CLASS_NAMES}
    with MAPPING.open(encoding="utf-8") as f:
        for row in csv.DictReader(f):
            recs[int(row["new_class"])].append(row)
    return recs


def crop_patch(row, box_pad=1.2):
    img = cv2.imread(str(DST / "images" / row["split"] / row["image"]))
    H, W = img.shape[:2]
    cx, cy, nw, nh = [float(x) for x in (row["cx"], row["cy"], row["w"], row["h"])]
    # 用 csv 里的 w/h 重建 bbox（避免再读标签）
    x1 = (cx - nw / 2) * W
    y1 = (cy - nh / 2) * H
    x2 = (cx + nw / 2) * W
    y2 = (cy + nh / 2) * H
    pw, ph = x2 - x1, y2 - y1
    x1 -= pw * (box_pad - 1) / 2
    y1 -= ph * (box_pad - 1) / 2
    x2 += pw * (box_pad - 1) / 2
    y2 += ph * (box_pad - 1) / 2
    x1, y1 = max(0, int(x1)), max(0, int(y1))
    x2 = min(W, int(np.ceil(x2)))
    y2 = min(H, int(np.ceil(y2)))
    patch = img[y1:y2, x1:x2]
    cv2.rectangle(patch, (int((x2 - x1) * 0.1), int((y2 - y1) * 0.1)),
                  (int((x2 - x1) * 0.9), int((y2 - y1) * 0.9)), (0, 0, 255), 1)
    return cv2.resize(patch, (PATCH_SIZE, PATCH_SIZE))


def main():
    recs = load_records()
    PREVIEW_DIR.mkdir(parents=True, exist_ok=True)
    rng = random.Random(42)
    n_classes = len(CLASS_NAMES)
    grid = np.full((n_classes * (PATCH_SIZE + 24), SAMPLE_PER_CLASS * (PATCH_SIZE + 4), 3), 30, dtype=np.uint8)

    for cls_id, name in CLASS_NAMES.items():
        pool = recs[cls_id]
        if not pool:
            print(f"[WARN] 类 {name} 无样本")
            continue
        sample = rng.sample(pool, min(SAMPLE_PER_CLASS, len(pool)))
        y0 = cls_id * (PATCH_SIZE + 24)
        cv2.putText(grid, f"{cls_id}: {name} ({len(pool)} boxes)", (10, y0 + 17),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
        for j, row in enumerate(sample):
            patch = crop_patch(row)
            x0 = j * (PATCH_SIZE + 4)
            grid[y0 + 24: y0 + 24 + PATCH_SIZE, x0: x0 + PATCH_SIZE] = patch
        print(f"类 {cls_id} ({name}): 抽样 {len(sample)}/{len(pool)}")

    out = PREVIEW_DIR / "subclass_preview.png"
    cv2.imwrite(str(out), grid)
    print(f"\n[OK] 预览图已生成: {out}")


if __name__ == "__main__":
    main()
