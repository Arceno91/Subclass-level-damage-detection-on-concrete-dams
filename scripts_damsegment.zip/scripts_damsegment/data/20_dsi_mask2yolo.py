# -*- coding: utf-8 -*-
"""20_dsi_mask2yolo.py — DSI 坝面数据（爬壁机器人，多类缺陷分割 mask）→ YOLO 检测数据集

用途：论文跨数据集泛化验证（第二个水工场景，与 DamCrack 无人机/手机采集互补）。
输入：DSI_data/DSI_data/DSI-MultiClass/{Multi_Original,Multi_Label,Augment_*/{original,label}}
      DSI_data/DSI_data/DSI-LessClass/{Less_Original,Less_Label}
输出：datasets/DSI-Det/{images,labels}/{train,val,test} + data.yaml + convert_manifest.csv

处理：每个类别值（0 为背景）做连通域 → 面积过滤（--min-area）→ 外接矩形 → YOLO 归一化 bbox。

注意（论文需交代）：DSI 标签数值→语义词的对应关系需据 Buildings 2023 (10.3390/buildings13020285)
或官方预览图图例确认后再定类名；脚本默认保留原始数值作为类别 id（--names 可覆盖）。
"""
import argparse
import csv
import random
from collections import Counter, defaultdict
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
DSI = ROOT / "DSI_data" / "DSI_data"
OUT = ROOT / "datasets" / "DSI-Det"

# 默认类别名（占位，待据官方图例确认）
DEFAULT_NAMES = {1: "class_1", 2: "class_2", 3: "class_3", 4: "class_4", 5: "class_5", 6: "class_6"}


def collect_pairs():
    pairs = []
    m = DSI / "DSI-MultiClass"
    if (m / "Multi_Original").is_dir():
        for img in sorted((m / "Multi_Original").glob("*.png")):
            lbl = m / "Multi_Label" / f"{img.stem}_Label.png"
            if lbl.exists():
                pairs.append((img, lbl))
    for aug in sorted(m.glob("Augment_*")):
        o, l = aug / "original", aug / "label"
        if o.is_dir() and l.is_dir():
            for img in sorted(o.glob("*.png")):
                lbl = l / f"{img.stem}_Label.png"
                if lbl.exists():
                    pairs.append((img, lbl))
    b = DSI / "DSI-LessClass"
    if (b / "Less_Original").is_dir():
        for img in sorted((b / "Less_Original").glob("*.png")):
            lbl = b / "Less_Label" / f"{img.stem}_Label.png"
            if lbl.exists():
                pairs.append((img, lbl))
    return pairs


def mask_to_boxes(mask, min_area):
    """每类别连通域 → (cls, cx, cy, w, h) 归一化"""
    h, w = mask.shape[:2]
    out = []
    for v in sorted(int(x) for x in np.unique(mask) if int(x) != 0):
        binary = (mask == v).astype(np.uint8)
        n, labels, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
        for i in range(1, n):
            x, y, bw, bh, area = stats[i]
            if area < min_area or bw < 2 or bh < 2:
                continue
            out.append((v, (x + bw / 2) / w, (y + bh / 2) / h, bw / w, bh / h))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--min-area", type=int, default=24, help="连通域最小像素面积（去噪）")
    ap.add_argument("--ratios", default="0.7,0.2,0.1")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    r0, r1, _ = [float(x) for x in args.ratios.split(",")]

    pairs = collect_pairs()
    print(f"发现 (image, mask) 对: {len(pairs)}")
    records = []
    for img_path, lbl_path in pairs:
        img = cv2.imread(str(img_path))
        mask = cv2.imread(str(lbl_path), cv2.IMREAD_GRAYSCALE)
        if img is None or mask is None:
            continue
        if mask.ndim == 3:
            mask = mask[..., 0]
        if mask.shape[:2] != img.shape[:2]:
            mask = cv2.resize(mask, (img.shape[1], img.shape[0]), interpolation=cv2.INTER_NEAREST)
        boxes = mask_to_boxes(mask, args.min_area)
        if boxes:
            records.append((img_path, boxes))

    cls_cnt = Counter()
    for _p, boxes in records:
        for b in boxes:
            cls_cnt[b[0]] += 1
    print("图像含缺陷:", len(records), "| 类别框数:", dict(sorted(cls_cnt.items())))

    # 按类别组合分层 7:2:1
    groups = defaultdict(list)
    for img_path, boxes in records:
        groups[frozenset(b[0] for b in boxes)].append((img_path, boxes))
    rng = random.Random(args.seed)
    split_of = {}
    for key, items in groups.items():
        items = sorted(items, key=lambda x: x[0].name)
        rng.shuffle(items)
        n = len(items)
        n_tr, n_va = int(n * r0), int(n * r1)
        for i, (p, _b) in enumerate(items):
            split_of[p] = "train" if i < n_tr else ("val" if i < n_tr + n_va else "test")
    counts = Counter(split_of.values())
    print("划分:", dict(counts))

    if args.dry_run:
        print("[dry-run] 未写文件")
        return

    for sp in ("train", "val", "test"):
        (OUT / "images" / sp).mkdir(parents=True, exist_ok=True)
        (OUT / "labels" / sp).mkdir(parents=True, exist_ok=True)
    manifest = []
    for img_path, boxes in records:
        sp = split_of[img_path]
        n_img = len(list((OUT / "images" / sp).glob("*.jpg")))
        stem = f"dsi_{n_img:05d}"
        cv2.imwrite(str(OUT / "images" / sp / f"{stem}.jpg"), cv2.imread(str(img_path)))
        with (OUT / "labels" / sp / f"{stem}.txt").open("w", encoding="utf-8") as f:
            for cls, cx, cy, w, h in boxes:
                f.write(f"{cls - 1} {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}\n")
        manifest.append({"new_stem": stem, "src": img_path.relative_to(ROOT).as_posix(), "split": sp})

    with (OUT / "convert_manifest.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["new_stem", "src", "split"])
        w.writeheader()
        w.writerows(manifest)

    nc = max(DEFAULT_NAMES)  # 6（数值 1..6 → id 0..5）
    with (OUT / "data.yaml").open("w", encoding="utf-8") as f:
        f.write(f"path: {OUT.as_posix()}\ntrain: images/train\nval: images/val\ntest: images/test\n\nnc: {nc}\nnames:\n")
        for c in range(nc):
            f.write(f"  {c}: {DEFAULT_NAMES[c + 1]}\n")
    print("完成:", OUT)


if __name__ == "__main__":
    main()
