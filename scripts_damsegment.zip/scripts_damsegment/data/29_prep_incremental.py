# -*- coding: utf-8 -*-
"""29_prep_incremental.py — 准备「base→novel 增量缺陷检测」协议数据集（建议②的支撑）

协议设计（对应 FSOD 的 base/novel 划分）：
  base 组   = 裂缝类 0/1/2（标注充足，占训练集 94%）
  novel 组  = 剥落类 3/4（模拟巡检中新增的缺陷类型，仅有 K-shot 标注）

产出（datasets/DamCrack-Incremental/）：
  base/{images,labels}/{train,val}      仅含裂缝类标注，图像用硬链接（不占额外空间）
  novel5/{images,labels}                每类 5 张的剥落小样本（仅保留剥落类框）
  replay50/{images,labels}              50 张随机基类图像（用于 Replay 缓解遗忘）
  base.yaml / novel_ft.yaml / novel_replay.yaml / eval5.yaml
  manifest.json                         划分与抽样记录（可复现）

用法：python 29_prep_incremental.py [--kshots 5] [--replay 50] [--seed 42]
"""
import argparse
import json
import os
import random
import shutil
from pathlib import Path

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
SRC = ROOT / "datasets/DamCrack-Sub5"
DST = ROOT / "datasets/DamCrack-Incremental"
NAMES = {0: "crack_fine", 1: "crack_network", 2: "crack_blocky", 3: "spalling_small", 4: "spalling_large"}
BASE_CLS, NOVEL_CLS = {0, 1, 2}, {3, 4}


def link_or_copy(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        return
    try:
        os.link(src, dst)  # NTFS 硬链接：同盘、免管理员、零额外空间
    except OSError:
        shutil.copy2(src, dst)


def filter_label(src_txt: Path, dst_txt: Path, keep, allow_empty=True):
    lines = []
    if src_txt.exists():
        for ln in src_txt.read_text(encoding="utf-8").splitlines():
            p = ln.split()
            if len(p) == 5 and int(p[0]) in keep:
                lines.append(ln)
    dst_txt.parent.mkdir(parents=True, exist_ok=True)
    if lines or allow_empty:
        dst_txt.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
    return len(lines)


def prep_base():
    n_img = n_box = 0
    for split in ("train", "val"):
        for img in sorted((SRC / "images" / split).glob("*.jpg")):
            txt = SRC / "labels" / split / f"{img.stem}.txt"
            keep = filter_label(txt, DST / "base/labels" / split / f"{img.stem}.txt", BASE_CLS)
            if keep == 0:  # 无裂缝框的图像不进 base 训练集（避免纯负样本稀释）
                continue
            link_or_copy(img, DST / "base/images" / split / img.name)
            n_img += 1
            n_box += keep
    print(f"[base] {n_img} 图 / {n_box} 裂缝框")
    return n_img, n_box


def prep_novel(kshots, seed):
    rng = random.Random(seed)
    picked = []
    for c in sorted(NOVEL_CLS):
        cands = []
        for txt in sorted((SRC / "labels/train").glob("*.txt")):
            classes = {int(l.split()[0]) for l in txt.read_text(encoding="utf-8").splitlines() if l.strip()}
            if c in classes:
                cands.append(txt.stem)
        if len(cands) < kshots:
            print(f"[warn] 类 {NAMES[c]} 仅 {len(cands)} 张可用 < K={kshots}")
        for stem in rng.sample(cands, min(kshots, len(cands))):
            picked.append(stem)
    picked = sorted(set(picked))
    n_box = 0
    for stem in picked:
        img = SRC / "images/train" / f"{stem}.jpg"
        if not img.exists():
            continue
        link_or_copy(img, DST / "novel5/images" / img.name)
        n_box += filter_label(SRC / "labels/train" / f"{stem}.txt",
                              DST / "novel5/labels" / f"{stem}.txt", NOVEL_CLS)
    print(f"[novel] {len(picked)} 图 / {n_box} 剥落框（K={kshots}/类）")
    return picked, n_box


def prep_replay(n, seed):
    rng = random.Random(seed + 1)
    base_imgs = sorted((DST / "base/images/train").glob("*.jpg"))
    picked = rng.sample(base_imgs, min(n, len(base_imgs)))
    for img in picked:
        link_or_copy(img, DST / "replay50/images" / img.name)
        lbl_dst = DST / "replay50/labels" / f"{img.stem}.txt"
        lbl_dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(DST / "base/labels/train" / f"{img.stem}.txt", lbl_dst)
    print(f"[replay] {len(picked)} 张基类图像")
    return [p.stem for p in picked]


def merge_novel_replay():
    """novel+replay 合并训练集（Replay 组的训练目录）"""
    for sub in ("images", "labels"):
        d = DST / "novel_replay" / sub
        d.mkdir(parents=True, exist_ok=True)
        for src_dir in (DST / "novel5" / sub, DST / "replay50" / sub):
            if src_dir.is_dir():
                for f in src_dir.iterdir():
                    link_or_copy(f, d / f.name) if sub == "images" else shutil.copy2(f, d / f.name)
    n = len(list((DST / "novel_replay/images").glob("*.jpg")))
    print(f"[novel_replay] {n} 图（novel5 + replay50）")


def write_yamls():
    def yaml(path, train, val):
        (DST / path).write_text(
            f"path: {DST.as_posix()}\ntrain: {train}\nval: {val}\n\nnc: 5\nnames:\n"
            + "".join(f"  {c}: {NAMES[c]}\n" for c in range(5)),
            encoding="utf-8",
        )

    yaml("base.yaml", "base/images/train", "base/images/val")            # 阶段1：基类训练
    yaml("novel_ft.yaml", "novel5/images", "base/images/val")             # 阶段2a：朴素微调（验证用基类 val）
    yaml("novel_replay.yaml", "novel_replay/images", "base/images/val")   # 阶段2b：Replay 微调
    yaml("eval5.yaml", f"{SRC.as_posix()}/images/test", f"{SRC.as_posix()}/images/test")  # 最终 5 类评测
    print("[yaml] base.yaml / novel_ft.yaml / novel_replay.yaml / eval5.yaml")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kshots", type=int, default=5)
    ap.add_argument("--replay", type=int, default=50)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()
    DST.mkdir(parents=True, exist_ok=True)
    n_img, n_box = prep_base()
    picked, n_novel_box = prep_novel(args.kshots, args.seed)
    replay = prep_replay(args.replay, args.seed)
    merge_novel_replay()
    write_yamls()
    (DST / "manifest.json").write_text(json.dumps({
        "protocol": {"base_classes": sorted(BASE_CLS), "novel_classes": sorted(NOVEL_CLS),
                     "k_shots_per_novel_class": args.kshots, "replay_images": args.replay, "seed": args.seed},
        "base": {"images": n_img, "boxes": n_box},
        "novel": {"images": len(picked), "boxes": n_novel_box, "stems": picked},
        "replay_stems": replay,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print("完成 ->", DST)


if __name__ == "__main__":
    main()
