# -*- coding: utf-8 -*-
"""41_build_batch_datasets.py — 按采集批次拆分数据集（跨批次泛化实验的基础）

依据 datasets/DamCrack-Sub5/merge_manifest.csv 的 src_set 字段：
  A 批 = 4000 幅（文件名 A1–A4000，官方 Detection 子集）
  B 批 = 1500 幅（E/H/M 命名，早期批次，同坝体）
输出 datasets/DamCrack-Batch{A,B}/（图像用硬链接，标签复制）+ 4 个 yaml：
  batchA.yaml      A 批内 7:2:1（train/val/test 均为 A）
  batchB.yaml      B 批内 7:2:1（train/val/test 均为 B）
  crossA2B.yaml    训练集=A 批 train，测试/验证=B 批 test（跨批次）
  crossB2A.yaml    训练集=B 批 train，测试/验证=A 批 test（跨批次）
"""
import csv
import json
import os
import shutil
from pathlib import Path

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
SRC = ROOT / "datasets/DamCrack-Sub5"
BASE = ROOT / "datasets/DamCrack-Batches"
NAMES = {0: "crack_fine", 1: "crack_network", 2: "crack_blocky", 3: "spalling_small", 4: "spalling_large"}


def link_or_copy(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        return
    try:
        os.link(src, dst)
    except OSError:
        shutil.copy2(src, dst)


def main():
    manifest = list(csv.DictReader((SRC / "merge_manifest.csv").open(encoding="utf-8")))
    print(f"清单记录: {len(manifest)}")
    by_batch = {"A": {}, "B": {}}
    for row in manifest:
        by_batch[row["src_set"]][row["new_stem"]] = row["split"]
    for b in ("A", "B"):
        cnt = len(by_batch[b])
        splits = {}
        for s in by_batch[b].values():
            splits[s] = splits.get(s, 0) + 1
        print(f"  批次 {b}: {cnt} 幅, 划分 {splits}")
        d = BASE / f"batch{b}"
        for stem, split in by_batch[b].items():
            link_or_copy(SRC / "images" / split / f"{stem}.jpg", d / "images" / split / f"{stem}.jpg")
            lbl_dst = d / "labels" / split / f"{stem}.txt"
            lbl_dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(SRC / "labels" / split / f"{stem}.txt", lbl_dst)
    (BASE / "batch_index.json").write_text(json.dumps(
        {b: {"n": len(by_batch[b])} for b in ("A", "B")}, ensure_ascii=False, indent=2), encoding="utf-8")

    def yaml(path, train, val, test):
        (path).write_text(
            f"path: {BASE.as_posix()}\ntrain: {train}\nval: {val}\ntest: {test}\n\nnc: 5\nnames:\n"
            + "".join(f"  {c}: {NAMES[c]}\n" for c in range(5)), encoding="utf-8")

    yaml(BASE / "batchA.yaml", "batchA/images/train", "batchA/images/val", "batchA/images/test")
    yaml(BASE / "batchB.yaml", "batchB/images/train", "batchB/images/val", "batchB/images/test")
    # 跨批次：训练用源批次 train，验证与测试用目标批次 test（避免任何同批次测试泄漏）
    yaml(BASE / "crossA2B.yaml", "batchA/images/train", "batchB/images/test", "batchB/images/test")
    yaml(BASE / "crossB2A.yaml", "batchB/images/train", "batchA/images/test", "batchA/images/test")
    print("完成 ->", BASE)
    for p in sorted(BASE.glob("*.yaml")):
        print("   ", p.name)


if __name__ == "__main__":
    main()
