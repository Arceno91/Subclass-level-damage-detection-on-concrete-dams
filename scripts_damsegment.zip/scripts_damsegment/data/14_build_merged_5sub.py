# -*- coding: utf-8 -*-
"""
14_build_merged_5sub.py — 合并 DamCrack 两批 patch（E/H/M 1500 + A 4000）→ 5 子类 → 分层 7:2:1

数据源:
  SetA: Damage Detection/Damage Detection/{images, labels/Yolo}   (A1..A4000, 2 类)
  SetB: datasets/DamSegment/raw/{Images, Labels/Yolo}             (E/H/M 各 500, 2 类)
        + metadata/mapping.csv 的已审阅新类标签（new_class）

输出:
  datasets/DamCrack-Sub5/{images,labels}/{train,val,test}
  datasets/DamCrack-Sub5/data.yaml
  datasets/DamCrack-Sub5/merge_manifest.csv   (new_stem, src_set, src_img, split)
  datasets/DamCrack-Sub5/stats_summary.json

子类规则（与 02_subclass_mapping.py 一致）:
  0 crack_fine    : 宽高比 >=3 或 <=1/3
  1 crack_network : 非细长 且 同图邻近 crack 框数 >=4
  2 crack_blocky  : 其余 crack
  3 spalling_small: spalling 且 面积 <4096 px^2 (64x64 @640)
  4 spalling_large: spalling 且 面积 >=4096 px^2

划分: 按图像级类别组合分层 7:2:1，seed=42；无框背景图全部进 train。
"""
import argparse
import csv
import json
import math
import random
import shutil
from collections import Counter, defaultdict
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
SET_A = ROOT / "Damage Detection" / "Damage Detection"
SET_B_BASE = ROOT / "datasets" / "DamSegment"
SET_B_IMG = SET_B_BASE / "raw" / "Images"
SET_B_LBL = SET_B_BASE / "raw" / "Labels" / "Yolo"
MAPPING_CSV = SET_B_BASE / "metadata" / "mapping.csv"
OUT = ROOT / "datasets" / "DamCrack-Sub5"

SEED = 42
SPLITS = (0.7, 0.2, 0.1)
INIT = (0.80, 0.10, 0.10)  # 备用（未使用）

AR_EXTREME = 3.0
NEIGHBOR_TH = 4
SPALLING_AREA_TH = 4096.0
NEW_CLASSES = {0: "crack_fine", 1: "crack_network", 2: "crack_blocky", 3: "spalling_small", 4: "spalling_large"}


def gradient_entropy(patch_bgr):
    gray = cv2.cvtColor(patch_bgr, cv2.COLOR_BGR2GRAY)
    gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
    mag = np.sqrt(gx * gx + gy * gy)
    ang = (np.arctan2(gy, gx) + np.pi) / (2 * np.pi)
    bins = (ang * 8).astype(int) % 8
    hist = np.bincount(bins.ravel(), weights=mag.ravel().astype(np.float64), minlength=8)
    if hist.sum() <= 1e-9:
        return 0.0
    p = hist / hist.sum()
    p = p[p > 0]
    return float(-np.sum(p * np.log(p)) / math.log(8))


def make_patch(img_bgr, cx, cy, w, h):
    H, W = img_bgr.shape[:2]
    x1 = (cx - w / 2) * W
    y1 = (cy - h / 2) * H
    x2 = (cx + w / 2) * W
    y2 = (cy + h / 2) * H
    pw, ph = x2 - x1, y2 - y1
    x1 -= pw * 0.2
    y1 -= ph * 0.2
    x2 += pw * 0.2
    y2 += ph * 0.2
    x1, y1 = max(0, int(x1)), max(0, int(y1))
    x2 = min(W, int(math.ceil(x2)))
    y2 = min(H, int(math.ceil(y2)))
    if x2 - x1 < 4 or y2 - y1 < 4:
        x2, y2 = min(W, x1 + 8), min(H, y1 + 8)
    return img_bgr[y1:y2, x1:x2]


def parse_labels(txt_path):
    boxes = []
    for ln in txt_path.read_text(encoding="utf-8", errors="ignore").splitlines():
        ln = ln.strip()
        if not ln:
            continue
        parts = ln.split()
        if len(parts) == 5:
            boxes.append((int(parts[0]), float(parts[1]), float(parts[2]), float(parts[3]), float(parts[4])))
    return boxes


def classify_box(old_cls, ar, area_px, neighbors):
    if old_cls == 1:
        return 3 if area_px < SPALLING_AREA_TH else 4
    if ar >= AR_EXTREME or ar <= 1.0 / AR_EXTREME:
        return 0
    if neighbors >= NEIGHBOR_TH:
        return 1
    return 2


def feature_boxes(img, boxes):
    """为一张图的所有框计算 features + 规则分类。返回 [(new_cls, cx, cy, w, h)]"""
    H, W = img.shape[:2]
    crack_boxes = [(cx, cy, nw, nh) for (c_, cx, cy, nw, nh) in boxes if c_ == 0]
    out = []
    for (c_, cx, cy, nw, nh) in boxes:
        area_px = nw * W * nh * H
        ar = (nw * W) / max(nh * H, 1e-6)
        neighbors = 0
        if c_ == 0:
            reach = 2.0 * max(nw, nh)
            for (ox, oy, ow, oh) in crack_boxes:
                if (ox, oy, ow, oh) == (cx, cy, nw, nh):
                    continue
                if math.hypot((ox - cx) * W, (oy - cy) * H) <= reach * W:
                    neighbors += 1
        out.append((classify_box(c_, ar, area_px, neighbors), cx, cy, nw, nh))
    return out


def load_reviewed_mapping():
    """src_stem + box_index -> new_class（人工审阅后的映射）"""
    m = {}
    if not MAPPING_CSV.exists():
        return m
    with MAPPING_CSV.open(encoding="utf-8") as f:
        for row in csv.DictReader(f):
            m[(row["src_stem"], int(row["box_index"]))] = int(row["new_class"])
    return m


def process_set_a():
    """A 集 4000 张：规则生成 5 子类"""
    img_dir = SET_A / "images"
    lbl_dir = SET_A / "labels" / "Yolo"
    records = []
    for txt in sorted(lbl_dir.glob("*.txt")):
        stem = txt.stem
        img_path = img_dir / f"{stem}.jpg"
        if not img_path.exists():
            continue
        img = cv2.imread(str(img_path))
        if img is None:
            continue
        boxes = parse_labels(txt)
        if not boxes:
            records.append((stem, img_path, txt, []))
            continue
        cls_boxes = feature_boxes(img, boxes)
        records.append((stem, img_path, txt, cls_boxes))
    return records


def process_set_b(reviewed):
    """B 集 1500 张：优先用 mapping.csv 人工审阅标签，缺失回退规则"""
    img_dir = SET_B_IMG
    lbl_dir = SET_B_LBL
    records = []
    for txt in sorted(lbl_dir.glob("*.txt")):
        stem = txt.stem
        img_path = img_dir / f"{stem}.jpg"
        if not img_path.exists():
            continue
        img = cv2.imread(str(img_path))
        if img is None:
            continue
        boxes = parse_labels(txt)
        if not boxes:
            records.append((stem, img_path, txt, []))
            continue
        cls_boxes = []
        for bi, (c_, cx, cy, nw, nh) in enumerate(boxes):
            nc = reviewed.get((stem, bi))
            if nc is None:
                H, W = img.shape[:2]
                ar = (nw * W) / max(nh * H, 1e-6)
                cls_boxes.append((classify_box(c_, ar, nw * W * nh * H, 0), cx, cy, nw, nh))
            else:
                cls_boxes.append((nc, cx, cy, nw, nh))
        records.append((stem, img_path, txt, cls_boxes))
    return records


def stratified_split(records, ratios=(0.7, 0.2, 0.1), seed=42):
    """按图像级类别组合分层抽样。返回 {stem: split}"""
    groups = defaultdict(list)
    for stem, img_path, txt, cls_boxes in records:
        key = frozenset(c for c, *_ in cls_boxes) or frozenset({"bg"})
        groups[key].append(stem)
    rng = random.Random(seed)
    split_of = {}
    for key, stems in groups.items():
        stems = sorted(stems)
        rng.shuffle(stems)
        n = len(stems)
        n_train = int(math.floor(n * ratios[0] + 0.5))
        n_val = int(math.floor(n * ratios[1] + 0.5))
        n_test = n - n_train - n_val
        if key == frozenset({"bg"}):
            for s in stems:
                split_of[s] = "train"
            continue
        for i, s in enumerate(stems):
            if i < n_train:
                split_of[s] = "train"
            elif i < n_train + n_val:
                split_of[s] = "val"
            else:
                split_of[s] = "test"
    return split_of


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true", help="只统计，不写输出")
    ap.add_argument("--out", default=str(OUT))
    args = ap.parse_args()
    out = Path(args.out)

    print("== 处理 Set A (A1-A4000, 规则映射) ==")
    rec_a = process_set_a()
    print(f"  A 集图像: {len(rec_a)}")
    print("== 处理 Set B (E/H/M x500, 人工审阅标签优先) ==")
    reviewed = load_reviewed_mapping()
    print(f"  mapping.csv 审阅记录: {len(reviewed)}")
    rec_b = process_set_b(reviewed)
    print(f"  B 集图像: {len(rec_b)}")

    all_records = rec_a + rec_b
    total_imgs = len(all_records)
    print(f"\n合并后图像总数: {total_imgs}")

    inst_per_cls = Counter()
    for _s, _p, _t, cls_boxes in all_records:
        for c, *_ in cls_boxes:
            inst_per_cls[NEW_CLASSES[c]] += 1
    print("\n合并后 5 子类实例分布（规则/审阅）:")
    for k in sorted(NEW_CLASSES.values()):
        print(f"  {k:<16} {inst_per_cls[k]:>7}")

    print("\n== 分层 7:2:1 划分 ==")
    split_of = stratified_split(all_records, SPLITS, SEED)
    per_split = Counter(split_of.values())
    print(f"  train/val/test = {per_split['train']}/{per_split['val']}/{per_split['test']}")
    per_split_cls_inst = defaultdict(Counter)
    for stem, img_path, txt, cls_boxes in all_records:
        sp = split_of[stem]
        for c, *_ in cls_boxes:
            per_split_cls_inst[sp][NEW_CLASSES[c]] += 1
    for sp in ("train", "val", "test"):
        print(f"  [{sp}] " + ", ".join(f"{k}:{v}" for k, v in sorted(per_split_cls_inst[sp].items())))

    if args.dry_run:
        print("\n[dry-run] 未写任何文件。")
        return

    # 写输出
    out.mkdir(parents=True, exist_ok=True)
    for sp in ("train", "val", "test"):
        (out / "images" / sp).mkdir(parents=True, exist_ok=True)
        (out / "labels" / sp).mkdir(parents=True, exist_ok=True)

    manifest_rows = []
    for i, (stem, img_path, txt, cls_boxes) in enumerate(all_records):
        sp = split_of[stem]
        new_stem = f"{stem.replace(' ', '_')}_{i:05d}"
        shutil.copy2(img_path, out / "images" / sp / f"{new_stem}.jpg")
        with (out / "labels" / sp / f"{new_stem}.txt").open("w", encoding="utf-8") as f:
            for (c, cx, cy, nw, nh) in cls_boxes:
                f.write(f"{c} {cx:.6f} {cy:.6f} {nw:.6f} {nh:.6f}\n")
        src_set = "A" if img_path.as_posix().startswith(SET_A.as_posix()) else "B"
        manifest_rows.append({"new_stem": new_stem, "src_set": src_set, "src_img": stem, "split": sp})

    with (out / "merge_manifest.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["new_stem", "src_set", "src_img", "split"])
        w.writeheader()
        w.writerows(manifest_rows)

    with (out / "data.yaml").open("w", encoding="utf-8") as f:
        f.write(f"path: {out.as_posix()}\n")
        f.write("train: images/train\nval: images/val\ntest: images/test\n\nnc: 5\nnames:\n")
        for c in range(5):
            f.write(f"  {c}: {NEW_CLASSES[c]}\n")

    summary = {
        "total_images": total_imgs,
        "splits": dict(per_split),
        "instances_per_class": dict(inst_per_cls),
        "instances_per_split_class": {sp: dict(per_split_cls_inst[sp]) for sp in ("train", "val", "test")},
        "seed": SEED,
        "ratios": "7:2:1",
        "rules": {"AR_EXTREME": AR_EXTREME, "NEIGHBOR_TH": NEIGHBOR_TH, "SPALLING_AREA_TH": SPALLING_AREA_TH},
    }
    with (out / "stats_summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(f"\n完成: {out}\n数据统计已保存 stats_summary.json")


if __name__ == "__main__":
    main()
