# -*- coding: utf-8 -*-
"""51_build_label_cache.py — 预建 YOLO 标签缓存（*.cache），规避受限运行时的多进程限制

背景：新建数据集首次训练时，ultralytics 会调用 cache_labels()，其中使用
ThreadPool → multiprocessing.Pipe；在受限沙箱中创建命名管道返回 WinError 5，训练直接失败。
本脚本用同一套校验函数（verify_image_label）串行预建缓存，之后训练直接命中缓存。

用法：
  python 51_build_label_cache.py                       # 默认处理 DSI 两个数据集
  python 51_build_label_cache.py --datasets datasets/DSI-Det-5cls
  python 51_build_label_cache.py --datasets a.yaml b.yaml --splits train,val,test
"""
import argparse
import sys
from pathlib import Path

import yaml

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ultralytics.cfg import get_cfg  # noqa: E402
from ultralytics.data.dataset import YOLODataset, _label_pool, _mp_pipes_available  # noqa: E402


def build_one(img_dir: Path, base: Path, names: dict, augment: bool) -> int:
    ds = YOLODataset(
        img_path=str(img_dir),
        imgsz=640,
        cache=False,
        augment=augment,
        hyp=get_cfg(),
        prefix="  ",
        rect=False,
        batch_size=16,
        stride=32,
        pad=0.0 if augment else 0.5,
        single_cls=False,
        classes=None,
        fraction=1.0,
        data={"path": str(base), "names": names, "channels": 3},
        task="detect",
    )
    return len(ds)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", nargs="*", default=["datasets/DSI-Det-2cls", "datasets/DSI-Det-5cls"])
    ap.add_argument("--splits", default="train,val,test")
    args = ap.parse_args()

    print(f"[cache] multiprocessing pipes available = {_mp_pipes_available()}; pool = {type(_label_pool()).__name__}")
    splits = [s.strip() for s in args.splits.split(",") if s.strip()]

    for ds_arg in args.datasets:
        p = Path(ds_arg)
        yaml_path = p if p.suffix in {".yaml", ".yml"} else (ROOT / p if not p.is_absolute() else p) / "data.yaml"
        if not yaml_path.exists():
            print(f"[cache] 跳过 {yaml_path}（不存在）")
            continue
        cfg = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
        base = Path(cfg.get("path", yaml_path.parent))
        names = cfg.get("names", {})
        print(f"[cache] {yaml_path} -> {base} (nc={cfg.get('nc')})")
        for split in splits:
            rel = cfg.get(split)
            if not rel:
                continue
            img_dir = (base / rel) if not Path(rel).is_absolute() else Path(rel)
            if not img_dir.is_dir():
                print(f"[cache]   {split}: 无目录 {img_dir}")
                continue
            n = build_one(img_dir, base, names, augment=(split == "train"))
            cache = (img_dir.parent / "labels" / split).with_suffix(".cache")
            print(f"[cache]   {split}: {n} 幅 -> {cache} (exists={cache.exists()})", flush=True)


if __name__ == "__main__":
    main()
