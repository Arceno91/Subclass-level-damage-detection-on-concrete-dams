# -*- coding: utf-8 -*-
"""45_build_dsi_dataset.py — DSI 坝面数据（爬壁机器人）转 YOLO 检测数据集（第二数据集）

用途：论文第二数据集（跨数据集验证 + 方法迁移验证）
数据来源：DSI (Dam surface inspection) — 爬壁机器人采集的混凝土坝面多类缺陷分割数据
          论文：Hong K, et al. Buildings, 2023, 13(2): 285（DOI: 10.3390/buildings13020285）
          GitHub：GITSHOHOKU/DSI-Data-set（含 CSSC 数据集）

输入：DSI_data/DSI_data/DSI-MultiClass/{Multi_Original,Multi_Label,Augment_*/{original,label}}
      DSI_data/DSI_data/DSI-LessClass/{Less_Original,Less_Label}
输出：
  datasets/DSI-Det-5cls/  原始数值类别（1,3,4,5,6 → id 0..4），用于管道验证
  datasets/DSI-Det-2cls/  语义映射：crack(3,5) vs spalling(4) —— 用于验证"裂缝更难"机制是否在第二坝体复现
                        （数值 1/6 为斑点/噪点类，按面积阈值过滤后剔除，见 --keep-others）
处理：掩码连通域 → 面积过滤（--min-area）→ 外接矩形 → YOLO 归一化 bbox；7:2:1 分层划分（seed 42）

用法：python 45_build_dsi_dataset.py [--min-area 24] [--dry-run]
"""
import argparse
import csv
import json
import os
import random
import shutil
from collections import Counter, defaultdict
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
DSI = ROOT / "DSI_data" / "DSI_data"
OUT5 = ROOT / "datasets" / "DSI-Det-5cls"
OUT2 = ROOT / "datasets" / "DSI-Det-2cls"

# 数值 → 类别名（依据公开说明的缺陷种类 + 本次形态统计推断；论文中需注明映射依据）
VALUE_NAMES = {1: "spot_small", 3: "crack_linear", 4: "spalling_area", 5: "crack_branch", 6: "noise_dot"}
# 语义归并：3/5 → crack；4 → spalling
SEMANTIC = {3: 0, 5: 0, 4: 1}
SEMANTIC_NAMES = {0: "crack", 1: "spalling"}


def collect_pairs():
    pairs = []
    m = DSI / "DSI-MultiClass"
    if (m / "Multi_Original").is_dir():
        for img in sorted((m / "Multi_Original").glob("*.png")):
            lbl = m / "Multi_Label" / f"{img.stem}_Label.png"
            if lbl.exists():
                pairs.append((img, lbl))
    for aug in sorted(m.glob("Augment_*")):
        o, l = aug / "original", aug / "label"
        if o.is_dir() and l.is_dir():
            for img in sorted(o.glob("*.png")):
                lbl = l / f"{img.stem}_Label.png"
                if lbl.exists():
                    pairs.append((img, lbl))
    b = DSI / "DSI-LessClass"
    if (b / "Less_Original").is_dir():
        for img in sorted((b / "Less_Original").glob("*.png")):
            lbl = b / "Less_Label" / f"{img.stem}_Label.png"
            if lbl.exists():
                pairs.append((img, lbl))
    return pairs


def mask_to_boxes(mask, min_area, keep_values):
    h, w = mask.shape[:2]
    out = []
    for v in sorted(int(x) for x in np.unique(mask) if int(x) != 0):
        if keep_values is not None and v not in keep_values:
            continue
        binary = (mask == v).astype(np.uint8)
        n, labels, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
        for i in range(1, n):
            x, y, bw, bh, area = stats[i]
            if area < min_area or bw < 2 or bh < 2:
                continue
            out.append((v, x, y, bw, bh, w, h))
    return out


def link_or_copy(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        return
    try:
        os.link(src, dst)
    except OSError:
        shutil.copy2(src, dst)


def write_split(records, out_dir, label_map, names, summary, min_area, tag):
    rng = random.Random(42)
    groups = defaultdict(list)
    for img, boxes in records:
        groups[frozenset(label_map[b[0]] for b in boxes)].append((img, boxes))
    split_of = {}
    for key, items in groups.items():
        items = sorted(items, key=lambda x: x[0].name)
        rng.shuffle(items)
        n = len(items)
        n_tr, n_va = int(n * 0.7), int(n * 0.2)
        for i, (p, _b) in enumerate(items):
            split_of[p] = "train" if i < n_tr else ("val" if i < n_tr + n_va else "test")
    counts = Counter(split_of.values())
    cls_cnt = Counter()
    for img, boxes in records:
        for b in boxes:
            cls_cnt[label_map[b[0]]] += 1
    manifest = []
    for img, boxes in records:
        sp = split_of[img]
        stem = f"dsi_{len(manifest):05d}"
        link_or_copy(img, out_dir / "images" / sp / f"{stem}.png")
        lbl_path = out_dir / "labels" / sp / f"{stem}.txt"
        lbl_path.parent.mkdir(parents=True, exist_ok=True)
        with lbl_path.open("w", encoding="utf-8") as f:
            for v, x, y, bw, bh, w, h in boxes:
                f.write(f"{label_map[v]} {(x + bw / 2) / w:.6f} {(y + bh / 2) / h:.6f} {bw / w:.6f} {bh / h:.6f}\n")
        manifest.append({"new_stem": stem, "src": img.relative_to(ROOT).as_posix(), "split": sp})
    with (out_dir / "manifest.csv").open("w", encoding="utf-8", newline="") as f:
        wtr = csv.DictWriter(f, fieldnames=["new_stem", "src", "split"])
        wtr.writeheader()
        wtr.writerows(manifest)
    with (out_dir / "data.yaml").open("w", encoding="utf-8") as f:
        f.write(f"path: {out_dir.as_posix()}\ntrain: images/train\nval: images/val\ntest: images/test\n\nnc: {len(names)}\nnames:\n")
        for i, n in names.items():
            f.write(f"  {i}: {n}\n")
    summary[tag] = {"images": len(records), "splits": dict(counts), "instances": dict(cls_cnt),
                    "min_area": min_area, "names": names}
    print(f"[{tag}] 图像 {len(records)} | 划分 {dict(counts)} | 实例 {dict(cls_cnt)}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--min-area", type=int, default=24)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    pairs = collect_pairs()
    print(f"发现 (image, mask) 对: {len(pairs)}")
    records = []
    for img_path, lbl_path in pairs:
        img = cv2.imread(str(img_path))
        mask = cv2.imread(str(lbl_path), cv2.IMREAD_GRAYSCALE)
        if img is None or mask is None:
            continue
        if mask.shape[:2] != img.shape[:2]:
            mask = cv2.resize(mask, (img.shape[1], img.shape[0]), interpolation=cv2.INTER_NEAREST)
        boxes = mask_to_boxes(mask, args.min_area, keep_values=set(VALUE_NAMES))
        if boxes:
            records.append((img_path, boxes))
    print(f"含缺陷图像: {len(records)}")
    if args.dry_run:
        cnt = Counter(v for _p, bs in records for v, *_ in bs)
        print("原始数值实例分布:", dict(sorted(cnt.items())))
        sem = Counter(SEMANTIC[v] for _p, bs in records for v, *_ in bs if v in SEMANTIC)
        print("语义归并（0=crack, 1=spalling）:", dict(sorted(sem.items())))
        return

    summary = {}
    # 数据集 A：保留原始数值类别（1,3,4,5,6 → 0..4）
    ids5 = {v: i for i, v in enumerate(sorted(VALUE_NAMES))}
    names5 = {ids5[v]: VALUE_NAMES[v] for v in sorted(VALUE_NAMES)}
    write_split(records, OUT5, ids5, names5, summary, args.min_area, "DSI-Det-5cls")
    # 数据集 B：语义映射 crack / spalling（仅保留 3/5/4）
    rec2 = [(p, [b for b in bs if b[0] in SEMANTIC]) for p, bs in records]
    rec2 = [(p, bs) for p, bs in rec2 if bs]
    write_split(rec2, OUT2, SEMANTIC, SEMANTIC_NAMES, summary, args.min_area, "DSI-Det-2cls")
    (ROOT / "datasets" / "DSI_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print("完成 ->", OUT5, "与", OUT2)


if __name__ == "__main__":
    main()
