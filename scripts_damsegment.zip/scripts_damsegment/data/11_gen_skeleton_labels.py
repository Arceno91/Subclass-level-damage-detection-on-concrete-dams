# -*- coding: utf-8 -*-
"""
11_gen_skeleton_labels.py — 方案D: 自动骨架伪标签生成（无需人工标注）

思路：裂缝是连续的线状结构，但检测框把线切成碎片。用 OpenCV LSD（直线段检测）
在 crack 类 bbox 内自动提取细线/骨架，生成二值掩码，作为"连续结构"监督信号
（将来供辅助分割分支使用，迫使网络学习线的结构而非矩形框）。

输出：dataset/skeleton/{train,val,test}/img_XXXXX.png   (1 通道, 0/255, 与原图同尺寸)
       dataset/skeleton/manifest.json （统计信息）

用法: python 11_gen_skeleton_labels.py
"""
import json
from pathlib import Path

import cv2
import numpy as np

DAMSEG_ROOT = Path(r"E:\Arceno\\harmess\\project\\YOLO-PEFT-main\\datasets\\DamSegment")
ROOT = DAMSEG_ROOT
DST = DAMSEG_ROOT
OUT = DAMSEG_ROOT / "skeleton"
SUBCLASSES = {0: "crack_fine", 1: "crack_network", 2: "crack_blocky", 3: "spalling_small", 4: "spalling_large"}
CRACK_CLASSES = (0, 1, 2)  # 只有裂缝类做骨架（剥落是块状，不做）
STD = 8  # LSD 最小线段长度阈值(像素)


def gen_skeleton(img_bgr, boxes):
    """boxes: list[(cls, x1, y1, x2, y2)] 像素坐标 -> (H,W) uint8 二值骨架图"""
    H, W = img_bgr.shape[:2]
    mask = np.zeros((H, W), dtype=np.uint8)
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    lsd = cv2.createLineSegmentDetector(cv2.LSD_REFINE_STD)
    for cls, x1, y1, x2, y2 in boxes:
        if cls not in CRACK_CLASSES:
            continue
        x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
        crop = gray[y1:y2, x1:x2]
        if crop.size < 16:
            continue
        lines = lsd.detect(crop)[0]
        if lines is None:
            continue
        for ln in lines:
            xa, ya, xb, yb = ln[0]
            if np.hypot(xb - xa, yb - ya) < STD:
                continue
            cv2.line(mask, (int(xa) + x1, int(ya) + y1), (int(xb) + x1, int(yb) + y1), 255, 1, cv2.LINE_8)
    return mask


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    stats = {}
    for split in ("train", "val", "test"):
        img_dir = DST / "images" / split
        lbl_dir = DST / "labels" / split
        out_dir = OUT / split
        out_dir.mkdir(parents=True, exist_ok=True)
        n_img = n_box = n_seg = 0
        for img_path in sorted(img_dir.glob("*.jpg")):
            txt = lbl_dir / f"{img_path.stem}.txt"
            if not txt.exists():
                continue
            img = cv2.imread(str(img_path))
            if img is None:
                continue
            H, W = img.shape[:2]
            boxes = []
            for ln in txt.read_text(encoding="utf-8").splitlines():
                ln = ln.strip()
                if not ln:
                    continue
                p = ln.split()
                c, cx, cy, nw, nh = int(p[0]), float(p[1]), float(p[2]), float(p[3]), float(p[4])
                x1, y1 = (cx - nw / 2) * W, (cy - nh / 2) * H
                x2, y2 = (cx + nw / 2) * W, (cy + nh / 2) * H
                boxes.append((c, x1, y1, x2, y2))
                if c in CRACK_CLASSES:
                    n_box += 1
            mask = gen_skeleton(img, boxes)
            n = int((mask > 0).sum())
            cv2.imwrite(str(out_dir / f"{img_path.stem}.png"), mask)
            n_img += 1
            n_seg += n
        stats[split] = {"images": n_img, "crack_boxes": n_box, "skeleton_pixels": n_seg}
        print(f"{split}: {n_img} 图, {n_box} 裂缝框, 骨架像素 {n_seg}")
    (OUT / "manifest.json").write_text(json.dumps(stats, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"\n[OK] 输出: {OUT}\n标记统计: {stats}")


if __name__ == "__main__":
    main()
