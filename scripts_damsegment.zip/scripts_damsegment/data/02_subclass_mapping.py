# -*- coding: utf-8 -*-
"""
02_subclass_mapping.py — 子类划分（几何 + 图像特征规则）

基于 Damage Detection/dataset/（已切分的镜像）为每个 bbox 分配子类：

  0: crack_fine      细长裂缝   | 宽高比 >=3 或 <=0.33（极端细长条）
  1: crack_network   网状裂缝   | 非细长 且 patch 梯度方向熵高（多方向交叉）
  2: crack_blocky    块状裂缝   | 非细长 且熵低（方向单一的短裂缝片）
  3: spalling_small  小型剥落   | spalling 且面积 < 阈值
  4: spalling_large  大型剥落   | spalling 且面积 >= 阈值

用法：
  python 02_subclass_mapping.py --dry-run   # 只打印分布统计，不写文件
  python 02_subclass_mapping.py             # 生成 mapping.csv 并重写 dataset 标签 + data.yaml

输出 mapping.csv 后，你可以人工修改 new_class 列，再运行
  python 02_subclass_mapping.py --apply-csv  # 按修订后的 csv 重新生成标签
"""
import argparse
import csv
import math
from pathlib import Path

import cv2
import numpy as np

DAMSEG_ROOT = Path(r"E:\Arceno\\harmess\\project\\YOLO-PEFT-main\\datasets\\DamSegment")
ROOT = DAMSEG_ROOT
DST = DAMSEG_ROOT
MAPPING = DAMSEG_ROOT / "metadata" / "mapping.csv"
SPLIT_MAP = DAMSEG_ROOT / "metadata" / "split_map.csv"
SRC_IMG = DAMSEG_ROOT / "raw" / "Images"
SRC_LBL = DAMSEG_ROOT / "raw" / "Labels" / "Yolo"

AR_EXTREME = 3.0           # 宽高比阈值：细长
NEIGHBOR_TH = 4            # 同图邻近框数 >= N 判为网状聚集
SPALLING_AREA_TH = 4096.0  # spalling 面积阈值(px^2, 640 基准): 64x64

NEW_CLASSES = {
    0: "crack_fine",
    1: "crack_network",
    2: "crack_blocky",
    3: "spalling_small",
    4: "spalling_large",
}


def gradient_entropy(patch_bgr):
    """计算 patch 的梯度方向直方图熵（8 bins，归一化到 [0,1]）。"""
    gray = cv2.cvtColor(patch_bgr, cv2.COLOR_BGR2GRAY)
    gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
    mag = np.sqrt(gx * gx + gy * gy)
    ang = (np.arctan2(gy, gx) + np.pi) / (2 * np.pi)  # [0,1)
    bins = (ang * 8).astype(int) % 8
    hist = np.bincount(bins.ravel(), weights=mag.ravel().astype(np.float64), minlength=8)
    if hist.sum() <= 1e-9:
        return 0.0
    p = hist / hist.sum()
    p = p[p > 0]
    ent = -np.sum(p * np.log(p)) / math.log(8)
    return float(ent)


def make_patch(img_bgr, cx, cy, w, h):
    """按归一化中心/宽高裁 patch，加 20% 上下文，clamp 到图内。"""
    H, W = img_bgr.shape[:2]
    x1 = (cx - w / 2) * W
    y1 = (cy - h / 2) * H
    x2 = (cx + w / 2) * W
    y2 = (cy + h / 2) * H
    # 20% 上下文
    pw, ph = x2 - x1, y2 - y1
    x1 -= pw * 0.2
    y1 -= ph * 0.2
    x2 += pw * 0.2
    y2 += ph * 0.2
    x1, y1 = max(0, int(x1)), max(0, int(y1))
    x2 = min(W, int(math.ceil(x2)))
    y2 = min(H, int(math.ceil(y2)))
    if x2 - x1 < 4 or y2 - y1 < 4:
        x2, y2 = min(W, x1 + 8), min(H, y1 + 8)
    return img_bgr[y1:y2, x1:x2]


def load_split_map():
    """new_stem -> (src_stem, split)"""
    m = {}
    with SPLIT_MAP.open(encoding="utf-8") as f:
        for row in csv.DictReader(f):
            m[row["new_stem"]] = (row["src_stem"], row["split"])
    return m


def collect_records(dry_run=False):
    """Collect all box records from SOURCE labels (idempotent); compute neighbor count."""
    split_map = load_split_map()
    records = []
    seen = set()
    for new_stem, (src_stem, split) in sorted(split_map.items()):
        key = (src_stem, split)
        if key in seen:
            continue
        seen.add(key)
        img_path = SRC_IMG / f"{src_stem}.jpg"
        txt_path = SRC_LBL / f"{src_stem}.txt"
        if not img_path.exists() or not txt_path.exists():
            continue
        img = cv2.imread(str(img_path))
        if img is None:
            continue
        H, W = img.shape[:2]
        boxes = []  # (old_cls, cx, cy, w, h, area_px, ar)
        for bi, ln in enumerate(txt_path.read_text(encoding="utf-8").splitlines()):
            ln = ln.strip()
            if not ln:
                continue
            parts = ln.split()
            if len(parts) != 5:
                continue
            old_cls = int(parts[0])
            cx, cy, nw, nh = [float(x) for x in parts[1:5]]
            area_px = nw * W * nh * H
            ar = (nw * W) / max(nh * H, 1e-6)
            boxes.append((old_cls, cx, cy, nw, nh, area_px, ar))
        # 邻居计数：与当前 crack 框中心距离 < 2*max(w,h) 的其他 crack 框
        crack_boxes = [(cx, cy, nw, nh) for (c_, cx, cy, nw, nh, _, _) in boxes if c_ == 0]
        for bi, (old_cls, cx, cy, nw, nh, area_px, ar) in enumerate(boxes):
            ent = 0.0
            neighbors = 0
            if old_cls == 0:
                patch = make_patch(img, cx, cy, nw, nh)
                ent = gradient_entropy(patch)
                reach = 2.0 * max(nw, nh)
                for (ox, oy, ow, oh) in crack_boxes:
                    if (ox, oy, ow, oh) == (cx, cy, nw, nh):
                        continue
                    if math.hypot((ox - cx) * W, (oy - cy) * H) <= reach * W:
                        neighbors += 1
            records.append({
                "split": split, "image": f"{new_stem}.jpg", "box_index": bi,
                "src_stem": src_stem,
                "old_class": old_cls,
                "cx": round(cx, 6), "cy": round(cy, 6),
                "w": round(nw, 6), "h": round(nh, 6),
                "area_px": round(area_px, 1), "aspect_ratio": round(ar, 3),
                "entropy": round(ent, 4), "neighbors": neighbors,
            })
    return records


def classify(r):
    old = r["old_class"]
    ar = r["aspect_ratio"]
    area = r["area_px"]
    if old == 1:  # spalling
        return 3 if area < SPALLING_AREA_TH else 4
    # crack
    if ar >= AR_EXTREME or ar <= 1.0 / AR_EXTREME:
        return 0  # crack_fine 细长
    if r["neighbors"] >= NEIGHBOR_TH:
        return 1  # crack_network 网状聚集
    return 2  # crack_blocky 块状


def print_stats(records):
    import collections
    cnt = collections.Counter()
    ar_vals = []
    ent_vals = [r["entropy"] for r in records if r["old_class"] == 0]
    sp_area = [r["area_px"] for r in records if r["old_class"] == 1]
    for r in records:
        cls = classify(r)
        cnt[NEW_CLASSES[cls]] += 1
        if r["old_class"] == 0:
            ar_vals.append(r["aspect_ratio"])
    print(f"总框数: {len(records)}")
    print("\n子类分布（自动规则）:")
    for k in sorted(NEW_CLASSES.values()):
        print(f"  {k:<16} {cnt[k]:>7}  ({cnt[k]/len(records)*100:.1f}%)")
    print(f"\ncrack 宽高比: 均值 {np.mean(ar_vals):.2f} 中位 {np.median(ar_vals):.2f} 极值<1/3或>3: "
          f"{sum(1 for a in ar_vals if a>=3 or a<=1/3)} ({sum(1 for a in ar_vals if a>=3 or a<=1/3)/len(ar_vals)*100:.1f}%)" if ar_vals else "")
    if ent_vals:
        print(f"crack 熵(参考)分布: 均值 {np.mean(ent_vals):.3f} 中位 {np.median(ent_vals):.3f} "
              f"p25 {np.percentile(ent_vals,25):.3f} p75 {np.percentile(ent_vals,75):.3f}")
    nb = [r["neighbors"] for r in records if r["old_class"] == 0]
    if nb:
        print(f"crack 邻居框数: 均值 {np.mean(nb):.1f} 中位 {np.median(nb):.0f} "
              f">=4: {sum(1 for n in nb if n>=4)} ({sum(1 for n in nb if n>=4)/len(nb)*100:.1f}%)")
    if sp_area:
        print(f"spalling 面积(px^2): 均值 {np.mean(sp_area):.0f} 中位 {np.median(sp_area):.0f} "
              f"p25 {np.percentile(sp_area,25):.0f} p75 {np.percentile(sp_area,75):.0f}")
    print(f"spalling <{SPALLING_AREA_TH}px^2: {sum(1 for a in sp_area if a<SPALLING_AREA_TH)} | "
          f">={SPALLING_AREA_TH}px^2: {sum(1 for a in sp_area if a>=SPALLING_AREA_TH)}")


def apply_csv():
    """按用户修订后的 mapping.csv 重新生成 dataset 标签。"""
    img_boxes = {}
    with MAPPING.open(encoding="utf-8") as f:
        for row in csv.DictReader(f):
            key = (row["split"], row["image"])
            img_boxes.setdefault(key, []).append((int(row["box_index"]), int(row["new_class"])))
    n_upd = 0
    for (split, image), boxes in img_boxes.items():
        txt = DST / "labels" / split / (Path(image).stem + ".txt")
        if not txt.exists():
            continue
        lines = txt.read_text(encoding="utf-8").splitlines()
        new_lines = []
        for bi, ln in enumerate(lines):
            ln = ln.strip()
            if not ln:
                continue
            parts = ln.split()
            # 按 box_index 还原行序（csv 的 box_index 是原始非空行序号）
            new_cls = None
            for idx, nc in boxes:
                if idx == bi:
                    new_cls = nc
                    break
            if new_cls is None:
                # 保留原类别（未在 csv 中，理论上不发生）
                new_lines.append(ln)
            else:
                parts[0] = str(new_cls)
                new_lines.append(" ".join(parts))
                n_upd += 1
        txt.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
    # 更新 data.yaml
    names_block = "\n".join(f"  {i}: {v}" for i, v in sorted(NEW_CLASSES.items()))
    yaml_text = f"""# DamSegment 子类数据集配置（N-way=5）
path: {DST.as_posix()}
train: images/train
val: images/val
test: images/test

nc: 5
names:
{names_block}
"""
    (DST / "data.yaml").write_text(yaml_text, encoding="utf-8")
    print(f"[OK] 已更新 {n_upd} 个框的类别，data.yaml 已写为 5 类。")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--apply-csv", action="store_true")
    args = ap.parse_args()

    if args.apply_csv:
        apply_csv()
        return

    records = collect_records()
    print_stats(records)

    if args.dry_run:
        return

    with MAPPING.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=[
            "split", "image", "box_index", "old_class", "new_class",
            "src_stem", "cx", "cy", "w", "h", "area_px", "aspect_ratio", "entropy", "neighbors",
        ])
        w.writeheader()
        for r in records:
            w.writerow({**r, "new_class": classify(r)})
    print(f"\n[OK] mapping.csv 已写入: {MAPPING}")
    print("     你可以人工修改 new_class 列后运行: python 02_subclass_mapping.py --apply-csv")


if __name__ == "__main__":
    main()
