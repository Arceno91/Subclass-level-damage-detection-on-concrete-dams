# -*- coding: utf-8 -*-
"""
01_split_dataset.py — 数据切分脚本（8:1:1，分层抽样）

- 源数据：Damage Detection/Images/*.jpg + Damage Detection/Labels/Yolo/*.txt
- 输出：  Damage Detection/dataset/{images,labels}/{train,val,test}
- 分层策略：按"是否含 spalling 框"把图分成两层，每层按 8:1:1 抽样，
  保证 spalling 图在 val/test 中的比例与 train 一致（避免验证集无剥落）；
  3 张背景图全部放入 train 作负样本。
- 重命名：E (1).jpg -> img_00001.jpg（去掉空格/括号，兼容 Linux/脚本）
- 原始数据不动，仅复制。
"""
import random
import shutil
import sys
from pathlib import Path

SEED = 42
SPLITS = {"train": 0.8, "val": 0.1, "test": 0.1}

DAMSEG_ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main\datasets\DamSegment")
ROOT = DAMSEG_ROOT  # 数据根（raw/ 为原始数据）
SRC_IMG = DAMSEG_ROOT / "raw" / "Images"
SRC_LBL = DAMSEG_ROOT / "raw" / "Labels" / "Yolo"
DST = DAMSEG_ROOT


def read_boxes(txt_path: Path):
    """读取 YOLO txt -> list[line]"""
    if not txt_path.exists():
        return []
    lines = []
    for ln in txt_path.read_text(encoding="utf-8", errors="ignore").splitlines():
        ln = ln.strip()
        if ln:
            lines.append(ln)
    return lines


def build_pool():
    """
    Return: dict[str, list[Path]]  key in {"pure_crack", "has_spalling", "bg"}
    """
    pool = {"pure_crack": [], "has_spalling": [], "bg": []}
    for img_path in sorted(SRC_IMG.glob("*.jpg")):
        stem = img_path.stem
        lbl_path = SRC_LBL / f"{stem}.txt"
        boxes = read_boxes(lbl_path)
        if not boxes:
            pool["bg"].append(img_path)
            continue
        has_sp = any((ln.split() or ["0"])[0] == "1" for ln in boxes)
        pool["has_spalling" if has_sp else "pure_crack"].append(img_path)
    return pool


def split_layer(items, ratios):
    """把一层列表按 ratios 顺序切分成 3 份（随机打乱后）"""
    items = sorted(items)  # 确定性顺序
    random.Random(SEED).shuffle(items)
    n = len(items)
    n_train = int(n * ratios["train"])
    n_val = int(n * ratios["val"])
    n_test = n - n_train - n_val
    return items[:n_train], items[n_train:n_train + n_val], items[n_train + n_val:]


def sanitize_stem(idx: int) -> str:
    return f"img_{idx:05d}"


def main():
    assert SRC_IMG.is_dir() and SRC_LBL.is_dir(), "源目录不存在"
    if DST.exists():
        print(f"[WARN] {DST} 已存在，先清空重新生成")
        shutil.rmtree(DST)

    pool = build_pool()
    print(f"分层：纯 crack 图 {len(pool['pure_crack'])} | 含 spalling 图 {len(pool['has_spalling'])} | 背景图 {len(pool['bg'])}")

    assign = {"train": [], "val": [], "test": []}
    # 背景图全部进 train
    assign["train"].extend(pool["bg"])
    # 含 spalling 的和纯 crack 的分别按 8:1:1 切
    for key in ("has_spalling", "pure_crack"):
        tr, va, te = split_layer(pool[key], SPLITS)
        assign["train"].extend(tr)
        assign["val"].extend(va)
        assign["test"].extend(te)

    # 全局唯一重命名（避免 train/val/test 之间重名冲突）
    counter = 0
    plan = []  # (img_src, label_src, dst_img, dst_label)
    for split in ("train", "val", "test"):
        for img in sorted(assign[split]):
            counter += 1
            new_stem = sanitize_stem(counter)
            lbl = SRC_LBL / f"{img.stem}.txt"
            plan.append((img, lbl, split, new_stem))
    # 打乱重命名顺序无必要；保留排序即可

    for split in ("train", "val", "test"):
        (DST / "images" / split).mkdir(parents=True, exist_ok=True)
        (DST / "labels" / split).mkdir(parents=True, exist_ok=True)

    for img, lbl, split, new_stem in plan:
        dst_img = DST / "images" / split / f"{new_stem}.jpg"
        dst_lbl = DST / "labels" / split / f"{new_stem}.txt"
        shutil.copyfile(img, dst_img)
        if lbl.exists():
            shutil.copyfile(lbl, dst_lbl)
        else:
            dst_lbl.write_text("", encoding="utf-8")

    # 生成 原始文件名 -> 新文件名 映射（供后续脚本从源数据幂等读取）
    map_dir = DAMSEG_ROOT / "metadata"
    map_dir.mkdir(exist_ok=True)
    with (map_dir / "split_map.csv").open("w", encoding="utf-8", newline="") as f:
        import csv
        w = csv.DictWriter(f, fieldnames=["new_stem", "src_stem", "split"])
        w.writeheader()
        for img, lbl, split, new_stem in plan:
            w.writerow({"new_stem": new_stem, "src_stem": img.stem, "split": split})
    print(f"[OK] 映射表: {map_dir / 'split_map.csv'}")

    print(f"切分完成：train {len(assign['train'])} | val {len(assign['val'])} | test {len(assign['test'])}")
    # 统计准确性
    for split in ("train", "val", "test"):
        n_img = len(list((DST / "images" / split).glob("*.jpg")))
        n_lbl = len(list((DST / "labels" / split).glob("*.txt")))
        n_sp = 0
        for p in (DST / "labels" / split).glob("*.txt"):
            for ln in p.read_text(encoding="utf-8").splitlines():
                if ln.strip() and ln.split()[0] == "1":
                    n_sp += 1
                    break
        print(f"  {split}: 图 {n_img} | 标签 {n_lbl} | 含 spalling 图 {n_sp}")

    # 生成 data.yaml
    yaml_text = f"""# DamSegment 数据集配置（由 01_split_dataset.py 生成）
path: {DST.as_posix()}
train: images/train
val: images/val
test: images/test

nc: 2
names:
  0: crack
  1: spalling
"""
    (DST / "data.yaml").write_text(yaml_text, encoding="utf-8")
    print(f"[OK] data.yaml 已生成: {DST / 'data.yaml'}")
    print(f"[OK] 完成，输出目录: {DST}")


if __name__ == "__main__":
    main()
