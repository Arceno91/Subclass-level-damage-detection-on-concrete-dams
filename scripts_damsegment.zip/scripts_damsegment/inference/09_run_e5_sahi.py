# -*- coding: utf-8 -*-
"""
08_sahi_experiment.py — E5：高分辨率场景切片推理对比（模拟 UAV 巡检图）

场景：
  坝面巡检图像实际分辨率远高于训练图。将 test 集上采样 2x -> 1280x1280 模拟真实巡检图，
  对比两种推理方式：
    A. 直接推理   : 1280 图直接送模型（letterbox 到 imgsz=640）-> 小目标特征丢失
    B. SAHI 切片  : 1280 图切 640 窗口（overlap=0.2）逐窗推理 + NMS 合并 -> 保留细节

指标：DetMetrics (mAP50/mAP50-95/per-class) + <32px 小目标召回率
用法：
  python 08_sahi_experiment.py --weights <best.pt> --name main
"""
import argparse
import json
from pathlib import Path

import cv2
import numpy as np
import torch

import sys
YOLO_PEFT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
sys.path.insert(0, str(YOLO_PEFT))

from ultralytics import YOLO  # noqa: E402
from ultralytics.utils.metrics import DetMetrics, box_iou  # noqa: E402

DAMSEG_ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main\datasets\DamSegment")
DATA_YAML = DAMSEG_ROOT / "data.yaml"
TEST_IMG = DAMSEG_ROOT / "images" / "test"
TEST_LBL = DAMSEG_ROOT / "labels" / "test"
RUNS = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main\runs\damsegment") / "E5_sahi"
NAMES = {0: "crack_fine", 1: "crack_network", 2: "crack_blocky", 3: "spalling_small", 4: "spalling_large"}
IOUV = torch.linspace(0.5, 0.95, 10)

WIN = 640
OVERLAP = 0.2
CONF = 0.25
IOU_TH = 0.45


def load_gt(img_path):
    txt = TEST_LBL / f"{img_path.stem}.txt"
    if not txt.exists():
        return np.zeros((0, 4), dtype=np.float32), np.zeros((0,), dtype=np.int64)
    W, H = 1280, 1280  # 上采样后的尺寸基准
    boxes, cls = [], []
    for ln in txt.read_text(encoding="utf-8").splitlines():
        ln = ln.strip()
        if not ln:
            continue
        p = ln.split()
        c, cx, cy, nw, nh = int(p[0]), float(p[1]), float(p[2]), float(p[3]), float(p[4])
        x1, y1 = (cx - nw / 2) * W, (cy - nh / 2) * H
        x2, y2 = (cx + nw / 2) * W, (cy + nh / 2) * H
        boxes.append([x1, y1, x2, y2])
        cls.append(c)
    return np.array(boxes, dtype=np.float32), np.array(cls, dtype=np.int64)


def match_tp(pred_boxes, pred_conf, pred_cls, gt_boxes, gt_cls):
    """贪心匹配：按 conf 降序，每 GT 最多匹配一个预测（IoU>=th 且类别一致）生成 (Npred,10) tp"""
    tp = np.zeros((len(pred_boxes), 10), dtype=bool)
    if len(pred_boxes) == 0 or len(gt_boxes) == 0:
        return tp
    pb = torch.tensor(pred_boxes, dtype=torch.float32)
    gb = torch.tensor(gt_boxes, dtype=torch.float32)
    iou = box_iou(pb, gb).numpy()  # (N, M)
    order = np.argsort(-pred_conf)  # 高置信度优先
    used_gt = set()
    for p in order:
        cls_ok = pred_cls[p] == gt_cls
        cand = [g for g in range(len(gt_boxes))
                if cls_ok[g] and g not in used_gt and iou[p, g] >= 0.5]
        if not cand:
            continue
        g = max(cand, key=lambda g: iou[p, g])
        used_gt.add(g)
        for i, th in enumerate(IOUV.tolist()):
            if iou[p, g] >= th:
                tp[p, i] = True
    return tp


def run_metrics(all_stats):
    dm = DetMetrics(names=NAMES)
    for st in all_stats:
        dm.update_stats(st)
    dm.process()
    out = {
        "mAP50-95": float(dm.box.map),
        "mAP50": float(dm.box.map50),
    }
    pc = {}
    ap_cls = dm.box.ap_class_index
    ap = dm.box.ap
    ap50 = dm.box.ap50
    for i, idx in enumerate(ap_cls):
        pc[NAMES[int(idx)]] = {"ap": float(ap[i]), "ap50": float(ap50[i])}
    out["per_class"] = pc
    return out


def infer_direct(model, img):
    res = model.predict(source=img, imgsz=640, conf=CONF, iou=IOU_TH, verbose=False)[0]
    return res.boxes.xyxy.cpu().numpy(), res.boxes.conf.cpu().numpy(), res.boxes.cls.cpu().numpy()


def infer_sahi(model, img):
    """1280 图切 640 窗口（overlap 0.2）推理 + 坐标映射 + NMS 合并"""
    H, W = img.shape[:2]
    stride = int(WIN * (1 - OVERLAP))
    xs = list(range(0, W - WIN + 1, stride))
    ys = list(range(0, H - WIN + 1, stride))
    if (W - WIN) % stride != 0:
        xs.append(W - WIN)
    if (H - WIN) % stride != 0:
        ys.append(H - WIN)
    boxes, confs, clss = [], [], []
    img_bgr = img[:, :, ::-1]  # 模型内部是 BGR PIL? predict 接受 BGR ndarray
    for y0 in ys:
        for x0 in xs:
            win = img_bgr[y0:y0 + WIN, x0:x0 + WIN]
            res = model.predict(source=win, imgsz=WIN, conf=CONF, iou=IOU_TH, verbose=False)[0]
            if res.boxes is None or len(res.boxes) == 0:
                continue
            xyxy = res.boxes.xyxy.cpu().numpy() + np.array([x0, y0, x0, y0])
            boxes.append(xyxy)
            confs.append(res.boxes.conf.cpu().numpy())
            clss.append(res.boxes.cls.cpu().numpy())
    if not boxes:
        return np.zeros((0, 4)), np.zeros((0,)), np.zeros((0,))
    boxes = np.concatenate(boxes)
    confs = np.concatenate(confs)
    clss = np.concatenate(clss)
    # NMS 合并（显式 float32，避免 CPU numpy 类型不一致）
    keep = torch.ops.torchvision.nms(
        torch.as_tensor(boxes, dtype=torch.float32),
        torch.as_tensor(confs, dtype=torch.float32), IOU_TH)
    keep = keep.numpy()
    return boxes[keep], confs[keep], clss[keep]


def small_object_recall(gt_boxes, gt_cls, pred_boxes, pred_cls):
    """小目标 GT 召回率（IoU>0.5 匹配）。口径: 1280 尺度下 <64x64px（=640 训练尺度 <32px）"""
    small_idx = [i for i, (x1, y1, x2, y2) in enumerate(gt_boxes) if (x2 - x1) * (y2 - y1) < 4096]
    if not small_idx:
        return None, 0
    n_small = len(small_idx)
    if len(pred_boxes) == 0:
        return 0.0, n_small
    pb = torch.tensor(pred_boxes)
    gb = torch.tensor(gt_boxes[small_idx])
    iou = box_iou(pb, gb)
    pc = np.array(pred_cls)[:, None] == np.array(gt_cls[small_idx])[None, :]
    matched = (iou.numpy() * pc).max(axis=0) >= 0.5
    return float(matched.mean()), n_small


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", required=True)
    ap.add_argument("--name", default="main")
    ap.add_argument("--max-imgs", type=int, default=0)
    args = ap.parse_args()

    model = YOLO(str(args.weights))
    RUNS.mkdir(parents=True, exist_ok=True)
    img_files = sorted(TEST_IMG.glob("*.jpg"))
    if args.max_imgs:
        img_files = img_files[:args.max_imgs]

    stats_direct, stats_sahi = [], []
    small_recall = {"direct": [], "sahi": []}
    print(f"测试图片: {len(img_files)} 张 (1280x1280 上采样模拟)")

    for i, img_path in enumerate(img_files):
        img = cv2.imread(str(img_path))
        img = cv2.resize(img, (1280, 1280), interpolation=cv2.INTER_LINEAR)  # 上采样模拟高分辨率
        img_rgb = img[:, :, ::-1]
        gt_box, gt_cls = load_gt(img_path)

        for mode, fn in (("direct", infer_direct), ("sahi", infer_sahi)):
            pb, conf, pc = fn(model, img_rgb if mode == "direct" else img)
            tp = match_tp(pb, conf, pc, gt_box, gt_cls)
            st = {
                "tp": tp, "target_cls": gt_cls,
                "target_img": np.unique(gt_cls), "im_name": img_path.name,
                "conf": conf if len(conf) else np.zeros(0),
                "pred_cls": pc if len(pc) else np.zeros(0),
            }
            if mode == "direct":
                stats_direct.append(st)
            else:
                stats_sahi.append(st)
            rec, n = small_object_recall(gt_box, gt_cls, pb, pc)
            if rec is not None:
                small_recall[mode].append(rec)
        if (i + 1) % 20 == 0:
            print(f"  {i+1}/{len(img_files)}")

    out = {
        "name": args.name, "weights": str(args.weights),
        "direct": run_metrics([s for s in stats_direct]),
        "sahi": run_metrics([s for s in stats_sahi]),
        "small_recall": {
            "direct": round(float(np.mean(small_recall["direct"])), 4) if small_recall["direct"] else None,
            "sahi": round(float(np.mean(small_recall["sahi"])), 4) if small_recall["sahi"] else None,
            "n_gt_small": None,
        },
    }
    # 小目标 GT 数
    n_small_all = sum(len([1 for b in load_gt(p)[0] if (b[2]-b[0])*(b[3]-b[1]) < 4096]) for p in img_files)
    out["small_recall"]["n_gt_small"] = n_small_all

    rst = RUNS / f"{args.name}_sahi_result.json"
    rst.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(out, indent=2, ensure_ascii=False))
    print(f"[OK] {rst}")


if __name__ == "__main__":
    main()
