# -*- coding: utf-8 -*-
"""19_full_seeds.py — 全量主实验多种子定版 runner（选项C 主表）

用法:
  # 纯基线补种子
  python 19_full_seeds.py --seeds 123,456 --name e6full
  # 增强组合补种子（--aug 里给开关，逗号分隔 k=v）
  python 19_full_seeds.py --seeds 123,456 --name e7best --aug "copy_paste=0.5,skeleton_aux=0.5"

每组: yolo11n COCO 预训练, 80ep, batch16, imgsz640, close_mosaic=10,
      训练后自动在 DamCrack-Sub5 test 上评估并存 runs/e8_multi/results_multi.json
"""
import argparse
import ast
import json
import sys
from pathlib import Path

YOLO_PEFT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(YOLO_PEFT) not in sys.path:
    sys.path.insert(0, str(YOLO_PEFT))

from ultralytics import YOLO  # noqa: E402

DATA_YAML = YOLO_PEFT / "datasets/DamCrack-Sub5/data.yaml"
RUNS = YOLO_PEFT / "runs/e8_multi"
PT = YOLO_PEFT / "yolo11n.pt"


def parse_aug(s):
    """解析增强参数串。分隔符用 ';'（避免与列表语法 [3,4] 的逗号冲突）；无 ';' 时才退回 ','"""
    sep = ";" if ";" in s else ","
    out = {}
    for item in s.split(sep):
        item = item.strip()
        if not item:
            continue
        k, v = item.split("=", 1)
        if v.startswith("[") or v.startswith("("):
            out[k] = ast.literal_eval(v)
            continue
        try:
            out[k] = float(v)
        except ValueError:
            out[k] = v
    return out


def run_is_complete(out_dir: Path, epochs: int) -> bool:
    """best.pt + results.csv 末轮 >= epochs 才算完成（防半成品）。"""
    csv = out_dir / "results.csv"
    if not (out_dir / "weights/best.pt").exists() or not csv.exists():
        return False
    try:
        rows = [l for l in csv.read_text(encoding="utf-8").splitlines() if l.strip()]
        return int(float(rows[-1].split(",")[0])) >= epochs
    except Exception:
        return False


def strip_scaler(weights):
    """修复 resume 的 GradScaler 空状态 bug：续训前删除 checkpoint 中的 scaler。"""
    import torch
    ck = torch.load(str(weights), map_location="cpu")
    if "scaler" in ck:
        ck.pop("scaler")
        torch.save(ck, str(weights))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", default="123,456")
    ap.add_argument("--name", default="e6full")
    ap.add_argument("--aug", default="", help='如 "copy_paste=0.5,skeleton_aux=0.5"')
    ap.add_argument("--epochs", type=int, default=80)
    ap.add_argument("--batch", type=int, default=16)
    args = ap.parse_args()
    aug = parse_aug(args.aug)
    RUNS.mkdir(parents=True, exist_ok=True)
    prev = []
    rfile = RUNS / "results_multi.json"
    if rfile.exists():
        try:
            prev = json.loads(rfile.read_text(encoding="utf-8"))
        except Exception:
            prev = []
    prev_names = {r.get("name") for r in prev if isinstance(r, dict)}
    results = []
    for s in [int(x) for x in args.seeds.split(",") if x.strip()]:
        name = f"{args.name}_s{s}"
        out_dir = RUNS / name
        if run_is_complete(out_dir, args.epochs):
            print(f"[{name}] 已完成 {args.epochs} 轮，跳过")
            continue
        print(f"\n===== seed {s}: {name} aug={aug} =====")
        last = out_dir / "weights" / "last.pt"
        if last.exists() and (out_dir / "args.yaml").exists():
            print(f"[{name}] 发现未完成残档，从 last.pt 断点续训")
            strip_scaler(last)
            YOLO(str(last)).train(resume=True)
        else:
            model = YOLO(str(PT))
            model.train(
                data=str(DATA_YAML), epochs=args.epochs, batch=args.batch, imgsz=640, workers=2,
                seed=s, project=str(RUNS), name=name, exist_ok=True, cache=False, plots=False,
                close_mosaic=10, verbose=True, **aug,
            )
        m2 = YOLO(str(out_dir / "weights/best.pt"))
        res = m2.val(data=str(DATA_YAML), split="test", imgsz=640, batch=16, workers=2,
                     project=str(RUNS), name=f"{name}_test", exist_ok=True, verbose=False)
        pc = {}
        names = res.names
        for c in range(5):
            pc[names[c]] = {"ap50_95": float(res.box.ap[c]), "ap50": float(res.box.ap50[c])}
        rec = {"seed": s, "name": name, "aug": aug,
               "mAP50_95": float(res.box.map), "mAP50": float(res.box.map50), "per_class": pc}
        results.append(rec)
        merged = [r for r in prev if isinstance(r, dict) and r.get("name") and r["name"] not in {x["name"] for x in results}] + results
        with rfile.open("w", encoding="utf-8") as f:
            json.dump(merged, f, ensure_ascii=False, indent=2)
    print("\n===== 汇总 (test mAP50-95) =====")
    for r in results:
        print(f"  {r['name']}: {r['mAP50_95']*100:.2f}%  (per-class: "
              + ", ".join(f"{k.split('_')[0]}_{k.split('_')[1] if '_' in k else ''}={v['ap50_95']*100:.1f}" for k, v in r['per_class'].items()) + ")")


if __name__ == "__main__":
    main()
