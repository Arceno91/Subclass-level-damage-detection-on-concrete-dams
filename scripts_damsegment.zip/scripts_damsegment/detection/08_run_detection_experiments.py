# -*- coding: utf-8 -*-
"""
07_detection_experiments.py — 方向A+C+D 检测级对比实验（YOLO-PEFT）

实验矩阵:
  E1 baseline   : yolo11n.pt        全量微调            （传统做法对照）
  E2 peft       : yolo11n.pt        + MoLoRA few-shot   （方向A）
  E3 p2         : yolo26-p2.yaml    全量微调            （方向C 结构）
  E4 main       : yolo26-p2.yaml    + MoLoRA few-shot   （A+C 主线）
  E5 sahi       : 最佳权重 test 集 Sparse SAHI 推理对比 （方向C 推理）

用法:
  python 07_detection_experiments.py --exp E1 --epochs 2          # smoke
  python 07_detection_experiments.py --exp all --epochs 80        # full
"""
import argparse
import json
import sys
from pathlib import Path

# ---- 确保导入本地 YOLO-PEFT 源码 ----
YOLO_PEFT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(YOLO_PEFT) not in sys.path:
    sys.path.insert(0, str(YOLO_PEFT))

YOLO11N_PT = Path(r"E:/Arceno/harmess/project/YOLO-PEFT-main/datasets/DamSegment/pretrained/yolo11n.pt")          # COCO 预训练（E1/E2 用）
YOLO26N_PT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main\datasets\DamSegment\pretrained\yolo26n.pt")  # 用户提供 YOLO26 权重（E3 用）
RUNS2 = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main\runs\damsegment")
E3_BEST = RUNS2 / "E3_p2_fullft" / "weights" / "best.pt"  # E3 域内预训练权重（E4 用）

from ultralytics import YOLO  # noqa: E402

DAMSEG_ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main\datasets\DamSegment")
ROOT = DAMSEG_ROOT
DATA_YAML = DAMSEG_ROOT / "data.yaml"      # 5子类 YAML
RUNS = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main\runs\damsegment")
SEED = 42

EXPS = {
    "E1": dict(model=str(YOLO11N_PT), load=None, peft=False, amp=True, batch=16, name="E1_baseline_fullft"),
    "E2": dict(model=str(YOLO11N_PT), load=None, peft=True, amp=False, batch=16, name="E2_peft_molora",
               peft_args=dict(molora_num_experts=4, molora_top_k=2, molora_r=8,
                              molora_alpha=16, molora_router_type="linear",
                              molora_balance_loss=0.01, molora_use_rslora=True,
                              lora_include_head=True)),
    "E3": dict(model="ultralytics/cfg/models/26/yolo26-p2.yaml",
               load=str(YOLO26N_PT), peft=False, amp=True, batch=16, name="E3_p2_fullft"),
    "E4": dict(model=str(E3_BEST), load=None, peft=True, amp=False, batch=8, name="E4b_p2_molora_pretrained",
               peft_args=dict(molora_num_experts=4, molora_top_k=2, molora_r=8,
                              molora_alpha=16, molora_router_type="linear",
                              molora_balance_loss=0.01, molora_use_rslora=True,
                              lora_include_head=True)),
}


def train_one(exp_id, epochs, batch=16, imgsz=640, workers=2, resume=False):
    cfg = EXPS[exp_id]
    run_dir = RUNS / cfg["name"]
    last_pt = run_dir / "weights" / "last.pt"
    if resume and last_pt.exists():
        print(f"[{exp_id}] 断点续训: {last_pt}")
        model = YOLO(str(last_pt))
        model.train(resume=True)  # 恢复权重+优化器+EMA+epoch+LR调度
        return model
    model_path = cfg["model"]
    if Path(model_path).suffix == ".yaml":
        model = YOLO(str(YOLO_PEFT / model_path))
        if cfg.get("load"):
            # 部分权重迁移（匹配层加载，P2 新增层随机初始化）
            model.load(str(cfg["load"]))
    else:
        model = YOLO(model_path)
    print(f"[{exp_id}] 模型: {model_path} | 预训练: {cfg.get('load') or model_path} | PEFT: {cfg['peft']}")

    args = dict(
        data=str(DATA_YAML),
        epochs=epochs,
        batch=cfg.get("batch", batch),
        imgsz=imgsz,
        workers=workers,
        seed=SEED,
        project=str(RUNS),
        name=cfg["name"],
        exist_ok=True,
        plots=False,
        amp=cfg.get("amp", True),
        cache=False,
        verbose=True,
        save=True,
    )
    if cfg["peft"]:
        args.update(cfg["peft_args"])
    model.train(**args)
    return model


def evaluate(exp_id, best_pt, split="test", imgsz=640, batch=16):
    """val 评估 + per-class AP 提取"""
    from ultralytics import YOLO
    model = YOLO(str(best_pt))
    results = model.val(data=str(DATA_YAML), split=split, imgsz=imgsz, batch=batch,
                        workers=2, project=str(RUNS), name=f"{exp_id}_val_{split}", exist_ok=True)
    out = {"exp": exp_id, "split": split}
    if results.box is not None:
        # per-class AP50-95 / AP50
        names = results.names
        ap_cls = results.box.ap_class_index
        ap = results.box.ap  # (num_classes,) AP50-95-95? ultralytics box.ap: per-class AP
        ap50 = results.box.ap50
        pc = {}
        for i, idx in enumerate(ap_cls):
            pc[names[idx]] = {"ap": float(ap[i]), "ap50": float(ap50[i])}
        out["per_class"] = pc
    out["mAP50-95"] = float(results.box.map)
    out["mAP50"] = float(results.box.mp50) if hasattr(results.box, "mp50") else None
    # AP small/medium/large (有的话)
    try:
        out["AP_small"] = float(results.box.small)
        out["AP_medium"] = float(results.box.medium)
        out["AP_large"] = float(results.box.large)
    except Exception:
        pass
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--exp", default="all", help="E1/E2/E3/E4/all 或逗号分隔如 'E2,E4'")
    ap.add_argument("--epochs", type=int, default=80)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--force", action="store_true", help="忽略 summary 中已完成的记录，强制重跑")
    ap.add_argument("--resume", action="store_true", help="从 last.pt 断点续训（存在时自动续，否则从头）")
    args = ap.parse_args()

    RUNS.mkdir(exist_ok=True)
    if args.exp == "all":
        order = ["E1", "E2", "E3", "E4"]
    else:
        order = [e.strip() for e in args.exp.split(",") if e.strip()]
    # 默认跳过已完成的实验（summary 中已有非 error 结果）
    summary_path = RUNS / "summary.json"
    summary = {}
    if summary_path.exists():
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
    if args.force or args.resume:
        to_run = order
    else:
        to_run = [e for e in order if e not in summary or "error" in summary[e]]
    if not to_run:
        print("所有指定实验已完成，跳过。")
        return
    print(f"将运行: {to_run}")

    for exp_id in to_run:
        try:
            model = train_one(exp_id, args.epochs, args.batch, args.imgsz, resume=args.resume)
            best = RUNS / EXPS[exp_id]["name"] / "weights" / "best.pt"
            if not best.exists():
                # 从实际目录找
                cands = list((RUNS / EXPS[exp_id]["name"] / "weights").glob("best.pt"))
                best = cands[0] if cands else None
            if best:
                res = evaluate(exp_id, best)
                summary[exp_id] = res
                with summary_path.open("w", encoding="utf-8") as f:
                    json.dump(summary, f, indent=2, ensure_ascii=False)
                print(f"[{exp_id}] eval OK: mAP50-95={res.get('mAP50-95')}, AP_small={res.get('AP_small')}")
        except Exception as e:
            import traceback
            traceback.print_exc()
            summary[exp_id] = {"error": str(e)}
    print("DONE")


if __name__ == "__main__":
    main()
