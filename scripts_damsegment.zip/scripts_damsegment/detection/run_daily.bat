@echo off
rem 每日 GPU 队列启动器（Windows 计划任务调用）
rem 窗口：08:00 - 18:00（每天 10 小时）；超出窗口不启动新步骤，中断的训练自动断点续训
cd /d E:\Arceno\harmess\project\YOLO-PEFT-main
E:\Arceno\hj\envs\yolov11\python.exe scripts\damsegment\detection\60_backlog_queue.py --window-start 08:00 --window-hours 10 >> runs\queue_logs\backlog_daily_launch.log 2>&1
