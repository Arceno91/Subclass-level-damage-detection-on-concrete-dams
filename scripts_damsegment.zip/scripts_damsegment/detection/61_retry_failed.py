# -*- coding: utf-8 -*-
"""61_retry_failed.py — 主队列结束后自动重跑失败步骤（自愈守护）

用法：python 61_retry_failed.py
行为：每 10 分钟轮询 runs/queue_logs/backlog_status.json；
      当主队列出现 "finished" 或 "stopped_by_file" 后，
      重跑一次 60_backlog_queue.py（已完成步骤自动跳过，失败的 c4_896 等重新执行）。
      只重跑一轮（用 backlog.RETRIED 标记防重复）。
"""
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
PY = r"E:\Arceno\hj\envs\yolov11\python.exe"
STATUS = ROOT / "runs/queue_logs/backlog_status.json"
MARKER = ROOT / "runs/queue_logs/backlog.RETRIED"
DRIVER = ROOT / "scripts/damsegment/detection/60_backlog_queue.py"
STOP = ROOT / "runs/queue_logs/backlog.STOP"


def main():
    print("[retry] 守护启动，等待主队列结束 ...", flush=True)
    while True:
        time.sleep(600)
        if not STATUS.exists():
            continue
        try:
            d = json.loads(STATUS.read_text(encoding="utf-8"))
        except Exception:
            continue
        if d.get("finished") or d.get("stopped_by_file"):
            break
    if MARKER.exists():
        print("[retry] 已重跑过一轮，退出", flush=True)
        return
    if STOP.exists():
        print("[retry] 检测到 STOP 文件，不重跑（用户主动中止）", flush=True)
        return
    MARKER.write_text("retried", encoding="utf-8")
    print("[retry] 主队列结束，重跑一遍（跳过已完成步骤）", flush=True)
    r = subprocess.run([PY, str(DRIVER)], cwd=str(ROOT))
    print(f"[retry] 重跑结束 rc={r.returncode}", flush=True)


if __name__ == "__main__":
    main()
