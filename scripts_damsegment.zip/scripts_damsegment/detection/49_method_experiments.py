# -*- coding: utf-8 -*-
"""49_method_experiments.py — 方法贡献实验套件（三组件）

组件（论文"方法贡献"一节）：
  M1 DACW  难度感知类别加权：用上一轮 per-class AP 反推权重 w_c ∝ 1/AP_c（而非频率 1/n_c），
           经损失层类别加权实现；对照 = 基线（无加权）与 cls_pw（频率加权，已知有害）
  M2 DAAA  难度感知标注分配：固定标注预算 25 幅下对比三种分配策略（均匀 / 频率比例 / 难度比例）
  M3 DBJT  域平衡联合训练：多批次/多数据集联合训练时按域规模反向采样（小域上采样），
           对比自然比例合并；在 A/B 批次与 DamCrack+DSI 跨数据集两个场景验证

输出：runs/e16_method/{results.json, fig_method.png} + paper/方法实验.md
用法：python 49_method_experiments.py --device 0 [--only M1]
"""
import argparse
import json
import os
import shutil
from pathlib import Path

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

import sys

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ultralytics import YOLO  # noqa: E402

DATA5 = ROOT / "datasets/DamCrack-Sub5/data.yaml"
BATCHES = ROOT / "datasets/DamCrack-Batches"
DSI2 = ROOT / "datasets/DSI-Det-2cls"
RUNS = ROOT / "runs/e16_method"
NAMES = ["crack_fine", "crack_network", "crack_blocky", "spalling_small", "spalling_large"]
SEED = 42  # 由 --seed 覆盖（多种子重复用）


def strip_scaler(weights):
    """修复 resume 的 GradScaler 空状态 bug：续训前删除 checkpoint 中的 scaler。"""
    import torch
    ck = torch.load(str(weights), map_location="cpu")
    if "scaler" in ck:
        ck.pop("scaler")
        torch.save(ck, str(weights))

# 基线 per-class AP（种子 42，来自 paper/指标汇总.md）→ 难度权重（练习：逆 AP 归一化到均值 1）
BASE_AP = np.array([29.17, 29.75, 29.46, 39.28, 44.04], dtype=np.float32) / 100.0
W_B1 = (1.0 / BASE_AP) / (1.0 / BASE_AP).mean()                    # β=1 温和
W_B2 = (1.0 / BASE_AP ** 2) / (1.0 / BASE_AP ** 2).mean()          # β=2 强化
# 标注分配（预算 25 幅）
ALLOC = {
    "uniform": [5, 5, 5, 5, 5],
    "frequency": [8, 5, 9, 2, 1],
    "difficulty": [6, 6, 6, 4, 3],
}


def link_or_copy(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        return
    try:
        os.link(src, dst)
    except OSError:
        shutil.copy2(src, dst)


def run_is_complete(out: Path, epochs: int, weight: str = "best.pt") -> bool:
    """判断一次训练是否真的跑完了（不能只看 best.pt：中断的运行也会留下 best.pt/last.pt）。"""
    csv = out / "results.csv"
    if not (out / "weights" / weight).exists() or not csv.exists():
        return False
    try:
        rows = [r for r in csv.read_text(encoding="utf-8").splitlines() if r.strip()]
        done = int(float(rows[-1].split(",")[0]))
    except Exception:
        return False
    return done >= epochs


WORKERS = 0  # 由 --workers 覆盖：沙箱内必须为 0，放开沙箱后可设 2 提速约 2 倍


def train_one(name, data_yaml, extra=None, epochs=80, batch=16, workers=0, no_val=False):
    """训练一次。no_val=True 关闭训练期验证，评估统一用末轮权重（用于小样本预算实验）。"""
    weight = "last.pt" if no_val else "best.pt"
    out = RUNS / name
    if run_is_complete(out, epochs, weight):
        print(f"[{name}] 已完成 {epochs} 轮，跳过")
        return out / "weights" / weight
    if out.exists():  # 中断残档：有 last.pt 则断点续训，否则清掉重训
        last = out / "weights" / "last.pt"
        if last.exists() and (out / "args.yaml").exists():
            print(f"[{name}] 发现未完成残档，从 last.pt 断点续训")
            strip_scaler(last)
            YOLO(str(last)).train(resume=True)
            return out / "weights" / weight
        print(f"[{name}] 无可续训残档，清除后重训")
        shutil.rmtree(out, ignore_errors=True)
    m = YOLO(str(ROOT / "yolo11n.pt"))
    kw = dict(data=str(data_yaml), epochs=epochs, batch=batch, imgsz=640, workers=workers, seed=SEED,
              device="0", project=str(RUNS), name=name, exist_ok=True, cache=False, plots=False,
              close_mosaic=10, verbose=True, val=not no_val)
    if extra:
        kw.update(extra)
    m.train(**kw)
    return out / "weights" / weight


def evaluate(tag, weights, data_yaml, split="test", names=None):
    m = YOLO(str(weights))
    r = m.val(data=str(data_yaml), split=split, imgsz=640, batch=16, workers=WORKERS, device="0",
              project=str(RUNS), name=f"eval_{tag}", exist_ok=True, verbose=False)
    ap = np.asarray(r.box.all_ap).mean(1)
    nm = names or NAMES
    rec = {"tag": tag, "mAP50_95": float(r.box.map), "mAP50": float(r.box.map50),
           "per_class": {nm[i]: float(ap[i]) for i in range(len(nm))}}
    print(f"[eval] {tag}: mAP50-95={rec['mAP50_95']*100:.2f}% mAP50={rec['mAP50']*100:.2f}%", flush=True)
    return rec


# ---------------- M1: 难度感知类别加权 ----------------
def m1_dacw(results):
    for tag, w in (("dacw_b1", W_B1), ("dacw_b2", W_B2)):
        print(f"\n===== M1 {tag}: cls_weights={np.round(w, 3).tolist()} =====", flush=True)
        pt = train_one(tag, DATA5, {"cls_weights": [float(x) for x in w]}, workers=WORKERS)
        results.append(evaluate(tag, pt, DATA5))


# ---------------- M2: 难度感知标注分配 ----------------
def m2_daaa(results):
    src_img = ROOT / "datasets/DamCrack-Sub5/images/train"
    src_lbl = ROOT / "datasets/DamCrack-Sub5/labels/train"
    by_class = {c: [] for c in range(5)}
    for lp in sorted(src_lbl.glob("*.txt")):
        cls = {int(l.split()[0]) for l in lp.read_text(encoding="utf-8").splitlines() if l.strip()}
        for c in cls:
            by_class[c].append(lp.stem)
    rng = np.random.RandomState(SEED)
    for policy, alloc in ALLOC.items():
        picked = []
        for c, k in enumerate(alloc):
            pool = sorted(by_class[c])
            rng.shuffle(pool)
            picked += pool[:k]
        picked = sorted(set(picked))
        d = RUNS / f"data_{policy}"
        for s in picked:
            link_or_copy(src_img / f"{s}.jpg", d / "images" / f"{s}.jpg")
            (d / "labels").mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_lbl / f"{s}.txt", d / "labels" / f"{s}.txt")
        (d / "data.yaml").write_text(
            f"path: {d.as_posix()}\ntrain: images\nval: {(ROOT/'datasets/DamCrack-Sub5/images/val').as_posix()}\n"
            f"test: {(ROOT/'datasets/DamCrack-Sub5/images/test').as_posix()}\n\nnc: 5\nnames:\n"
            + "".join(f"  {c}: {NAMES[c]}\n" for c in range(5)), encoding="utf-8")
        print(f"\n===== M2 {policy}: 分配 {alloc} → {len(picked)} 幅 =====", flush=True)
        pt = train_one(f"daaa_{policy}", d / "data.yaml", epochs=50, batch=8, workers=WORKERS, no_val=True)
        results.append(evaluate(f"daaa_{policy}", pt, DATA5))


# ---------------- M3: 域平衡联合训练 ----------------
def build_domain_balanced(src_yamls, out_dir, dup_small=3):
    """把小域（样本最少的域）重复 dup_small 份后与其它域合并（域平衡采样）。

    注意：域必须按 data.yaml 区分（batchA/batchB 的 yaml 与图像同在一个父目录，
    用 base.name 会把两个域误判成一个域，导致"全部图像都重复 3 份"的无效实验）。
    输出文件名统一带域前缀，避免不同域出现同名 stem 时互相覆盖。
    """
    recs = []
    for y in src_yamls:
        base, dom = y.parent, y.stem  # dom: batchA / batchB
        train_rel = y.read_text(encoding="utf-8").split("train:")[1].splitlines()[0].strip()
        img_dir = base / train_rel
        for p in sorted(img_dir.glob("*.jpg")):
            recs.append((p, base, train_rel, dom))
    (out_dir / "images").mkdir(parents=True, exist_ok=True)
    (out_dir / "labels").mkdir(parents=True, exist_ok=True)

    counts = {}
    for _, _, _, dom in recs:
        counts[dom] = counts.get(dom, 0) + 1
    small = min(counts, key=counts.get) if counts else None
    assert small is not None and len(counts) == len(src_yamls), f"域划分异常: {counts}"

    n = 0
    for img, base, train_rel, dom in recs:
        lbl = base / train_rel.replace("images", "labels") / f"{img.stem}.txt"
        if not lbl.exists():
            continue
        link_or_copy(img, out_dir / "images" / f"{dom}__{img.stem}.jpg")
        shutil.copy2(lbl, out_dir / "labels" / f"{dom}__{img.stem}.txt")
        n += 1
        if dom != small:
            continue
        for k in range(1, dup_small):  # 小域额外复制 dup_small-1 份
            link_or_copy(img, out_dir / "images" / f"{dom}__{img.stem}_dup{k}.jpg")
            shutil.copy2(lbl, out_dir / "labels" / f"{dom}__{img.stem}_dup{k}.txt")
            n += 1
    (out_dir / "data.yaml").write_text(
        f"path: {out_dir.as_posix()}\ntrain: images\nval: {(ROOT/'datasets/DamCrack-Sub5/images/val').as_posix()}\n"
        f"test: {(ROOT/'datasets/DamCrack-Sub5/images/test').as_posix()}\n\nnc: 5\nnames:\n"
        + "".join(f"  {c}: {NAMES[c]}\n" for c in range(5)), encoding="utf-8")
    eff = {d: (c * dup_small if d == small else c) for d, c in counts.items()}
    print(f"[DBJT] 域规模 {counts} → 平衡后 {eff}（小域 {small} 上采样 ×{dup_small}），合计 {n} 幅", flush=True)
    return out_dir / "data.yaml"


def m3_dbjt(results):
    d = RUNS / "data_balanced_AB"
    yaml = build_domain_balanced([BATCHES / "batchA.yaml", BATCHES / "batchB.yaml"], d)
    print("\n===== M3 DBJT（跨批次域平衡）=====", flush=True)
    pt = train_one("dbjt_batch", yaml, epochs=80, batch=16, workers=WORKERS)
    results.append(evaluate("dbjt_batch→A", pt, BATCHES / "batchA.yaml", "test"))
    results.append(evaluate("dbjt_batch→B", pt, BATCHES / "batchB.yaml", "test"))


def report(results):
    lines = ["# 方法实验（难度感知检测框架）", "",
             "## M1 难度感知类别加权（DACW）", "",
             "| 配置 | 类别权重 | mAP50-95 | mAP50 |", "|---|---|---|---|",
             "| 基线（无加权） | 全部 1.0 | 34.34 | 57.08 |",
             "| 频率加权 cls_pw=0.5（对照） | 逆频率 | 33.59 | — |"]
    for r in results:
        if r["tag"].startswith("dacw"):
            w = np.round(W_B1 if r["tag"].endswith("b1") else W_B2, 3).tolist()
            lines.append(f"| 难度加权 {r['tag']} | {w} | {r['mAP50_95']*100:.2f} | {r['mAP50']*100:.2f} |")
    lines += ["", "## M2 难度感知标注分配（DAAA，预算 25 幅）", "",
              "| 分配策略 | 每类张数 | mAP50-95 | mAP50 |", "|---|---|---|---|"]
    for pol, alloc in ALLOC.items():
        hit = [r for r in results if r["tag"] == f"daaa_{pol}"]
        if hit:
            lines.append(f"| {pol} | {alloc} | {hit[0]['mAP50_95']*100:.2f} | {hit[0]['mAP50']*100:.2f} |")
    lines += ["", "## M3 域平衡联合训练（DBJT，跨批次）", "",
              "| 评估集 | 域平衡联合 | 自然比例合并（主基线） |", "|---|---|---|"]
    a = [r for r in results if r["tag"].endswith("→A")]
    b = [r for r in results if r["tag"].endswith("→B")]
    lines.append(f"| A 批次测试集 | {a[0]['mAP50_95']*100:.2f} | 37.76 |" if a else "| A 批次测试集 | — | 37.76 |")
    lines.append(f"| B 批次测试集 | {b[0]['mAP50_95']*100:.2f} | 27.61 |" if b else "| B 批次测试集 | — | 27.61 |")
    (ROOT / (f"paper/方法实验_seed{SEED}.md" if SEED != 42 else "paper/方法实验.md")).write_text("\n".join(lines), encoding="utf-8")
    (RUNS / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[report] -> paper/方法实验{'_seed' + str(SEED) if SEED != 42 else ''}.md", flush=True)


def load_previous():
    """读取上一次调用留下的结果，按 tag 去重合并（支持分次 --only 运行）。"""
    p = RUNS / "results.json"
    if not p.exists():
        return []
    try:
        old = json.loads(p.read_text(encoding="utf-8"))
        return [r for r in old if isinstance(r, dict) and r.get("tag")]
    except Exception:
        return []


def merge(previous, fresh):
    tags = {r["tag"] for r in fresh}
    return [r for r in previous if r["tag"] not in tags] + fresh


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="M1,M2,M3")
    ap.add_argument("--workers", type=int, default=0)
    ap.add_argument("--seed", type=int, default=42, help="随机种子（多种子重复用；seed=42 保持原输出目录）")
    args = ap.parse_args()
    global SEED, RUNS
    SEED = args.seed
    RUNS = ROOT / "runs/e16_method" if SEED == 42 else ROOT / f"runs/e16_method/seed{SEED}"
    RUNS.mkdir(parents=True, exist_ok=True)
    global WORKERS
    WORKERS = args.workers
    only = args.only.split(",")
    prev = load_previous()
    results = []
    if "M1" in only:
        m1_dacw(results)
    if "M2" in only:
        m2_daaa(results)
    if "M3" in only:
        m3_dbjt(results)
    results = merge(prev, results)
    report(results)
    print("\n===== 汇总 =====")
    for r in results:
        print(f"  {r['tag']}: mAP50-95={r['mAP50_95']*100:.2f}%")


if __name__ == "__main__":
    main()
