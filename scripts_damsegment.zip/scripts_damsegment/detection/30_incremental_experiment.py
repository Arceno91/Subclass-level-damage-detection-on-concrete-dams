# -*- coding: utf-8 -*-
"""30_incremental_experiment.py — 增量缺陷检测协议（建议②）：base→novel 少样本适配与遗忘缓解

协议：
  阶段1  base 训练：裂缝类（0/1/2）全量标注训练 → base 模型
  阶段2  novel 适配：用剥落类（3/4）K=5 张/类 微调，三种策略对照：
         a) naive   ：朴素微调（全参数）
         b) replay  ：Replay 回放（novel 10 图 + 50 张基类图）
         c) lora    ：参数隔离（冻结基类特征，仅训练 LoRA 适配器）
  评测：在完整 5 类 test 集上分别统计 Base 组 AP（裂缝 0-2）、Novel 组 AP（剥落 3-4）与 HM
        → 得到 FSOD 口径的 bAP / nAP / HM，并量化「遗忘」与「缓解效果」

输出：runs/e10_inc/{...} + runs/e10_inc/incremental_results.json + paper/增量检测.md
用法：python 30_incremental_experiment.py --device 0 [--skip-base]
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ultralytics import YOLO  # noqa: E402

INC = ROOT / "datasets/DamCrack-Incremental"
RUNS = ROOT / "runs/e10_inc"
PT = ROOT / "yolo11n.pt"
NAMES = ["crack_fine", "crack_network", "crack_blocky", "spalling_small", "spalling_large"]
BASE_IDX, NOVEL_IDX = [0, 1, 2], [3, 4]


def evaluate(tag, weights, device):
    m = YOLO(str(weights))
    r = m.val(data=str(INC / "eval5.yaml"), split="val", imgsz=640, batch=16, workers=0,
              device=device, project=str(RUNS), name=f"eval_{tag}", exist_ok=True, verbose=False)
    all_ap = np.asarray(r.box.all_ap)
    ap5095 = all_ap.mean(1)
    base_ap = float(ap5095[BASE_IDX].mean())
    novel_ap = float(ap5095[NOVEL_IDX].mean())
    hm = 2 * base_ap * novel_ap / (base_ap + novel_ap) if (base_ap + novel_ap) > 0 else 0.0
    rec = {"tag": tag, "mAP50_95": float(r.box.map), "mAP50": float(r.box.map50),
           "base_AP": base_ap, "novel_AP": novel_ap, "HM": hm,
           "per_class": {NAMES[i]: float(ap5095[i]) for i in range(5)}}
    print(f"[eval] {tag}: mAP={rec['mAP50_95']*100:.2f}% | Base AP={base_ap*100:.2f}% | "
          f"Novel AP={novel_ap*100:.2f}% | HM={hm*100:.2f}%", flush=True)
    return rec


def train_stage1(device, epochs=80):
    out = RUNS / "stage1_base"
    if (out / "weights/best.pt").exists():
        print("[stage1] 已存在，跳过训练")
        return out / "weights/best.pt"
    m = YOLO(str(PT))
    m.train(data=str(INC / "base.yaml"), epochs=epochs, batch=16, imgsz=640, workers=2, seed=42,
            device=device, project=str(RUNS), name="stage1_base", exist_ok=True, cache=False,
            plots=False, close_mosaic=10, verbose=True)
    return out / "weights/best.pt"


def train_arm(name, data_yaml, base_pt, device, epochs=50, extra=None, lr0=None):
    out = RUNS / name
    if (out / "weights/best.pt").exists():
        print(f"[{name}] 已存在，跳过训练")
        return out / "weights/best.pt"
    m = YOLO(str(base_pt))
    kwargs = dict(data=str(data_yaml), epochs=epochs, batch=8, imgsz=640, workers=2, seed=42,
                  device=device, project=str(RUNS), name=name, exist_ok=True, cache=False,
                  plots=False, close_mosaic=10, verbose=True, patience=15)
    if lr0 is not None:
        kwargs["lr0"] = lr0
    if extra:
        kwargs.update(extra)
    m.train(**kwargs)
    return out / "weights/best.pt"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="0")
    ap.add_argument("--skip-base", action="store_true")
    ap.add_argument("--epochs-base", type=int, default=80)
    ap.add_argument("--epochs-arm", type=int, default=30)
    ap.add_argument("--lr0-arm", type=float, default=0.0005, help="微调学习率（小样本需更小，防 cls 崩溃）")
    args = ap.parse_args()
    RUNS.mkdir(parents=True, exist_ok=True)

    base_pt = RUNS / "stage1_base/weights/best.pt"
    if not args.skip_base:
        print("===== 阶段1：base（裂缝类）训练 =====", flush=True)
        base_pt = train_stage1(args.device, args.epochs_base)

    results = []
    if base_pt.exists():
        results.append(evaluate("stage1_base(未适配)", base_pt, args.device))

    arms = [
        ("arm_naive", INC / "novel_ft.yaml", None),
        ("arm_replay", INC / "novel_replay.yaml", None),
        ("arm_lora", INC / "novel_ft.yaml",
         dict(lora_type="lora", lora_backend="fallback", lora_r=8, lora_alpha=16)),
    ]
    for name, data_yaml, extra in arms:
        if not base_pt.exists():
            print(f"[{name}] 缺少 base 权重，跳过")
            continue
        print(f"===== 阶段2：{name} =====", flush=True)
        pt = train_arm(name, data_yaml, base_pt, args.device, args.epochs_arm, extra, args.lr0_arm)
        results.append(evaluate(name, pt, args.device))
        (RUNS / "incremental_results.json").write_text(
            json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")

    # 报告
    lines = ["# 增量缺陷检测实验（base=裂缝组 → novel=剥落组，K=5/类）", "",
             "| 方案 | mAP50-95 | Base 组 AP（裂缝） | Novel 组 AP（剥落） | HM |",
             "|---|---|---|---|---|"]
    for r in results:
        lines.append(f"| {r['tag']} | {r['mAP50_95']*100:.2f} | {r['base_AP']*100:.2f} | "
                     f"{r['novel_AP']*100:.2f} | {r['HM']*100:.2f} |")
    lines += ["", "> Base 组 AP 的下降幅度即「遗忘量」；Replay / LoRA 参数隔离用于缓解遗忘。"]
    (ROOT / "paper/增量检测.md").write_text("\n".join(lines), encoding="utf-8")
    print("\n===== 汇总 =====")
    for r in results:
        print(f"  {r['tag']}: Base={r['base_AP']*100:.2f}% Novel={r['novel_AP']*100:.2f}% HM={r['HM']*100:.2f}%")


if __name__ == "__main__":
    main()
