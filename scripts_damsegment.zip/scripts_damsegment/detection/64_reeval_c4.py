# -*- coding: utf-8 -*-
"""64_reeval_c4.py — 重建分辨率实验（C4）的评测记录

起因：2026-09-21 12:15 一次误配的 `--imgsz 960` 调用复用了 c4_res896 的完成检查，
把 results.json 中 c4_res896 的“896@896”记录覆盖成了 960 推理评测。
本脚本用固定权重重新评测，恢复并补全记录：
  - c4_res896/best.pt   @ 896 / 640 / 960
  - c4_res960/best.pt   @ 960 / 640（若 960 训练已存在）
结果写回 runs/e17_resolution/results.json + paper/分辨率实验.md，并留标记文件。
"""
import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

_spec = importlib.util.spec_from_file_location(
    "r57", ROOT / "scripts/damsegment/detection/57_resolution_experiment.py")
r57 = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(r57)

RUNS = ROOT / "runs/e17_resolution"


def main():
    res = []
    pt896 = RUNS / "c4_res896/weights/best.pt"
    if pt896.exists():
        for tag, sz in (("c4_res896", 896), ("c4_res896_infer640", 640), ("c4_res896_infer960", 960)):
            res.append(r57.evaluate(tag, pt896, r57.DATA5, sz, 2, "0"))
    pt960 = RUNS / "c4_res960/weights/best.pt"
    if pt960.exists():
        for tag, sz in (("c4_res960", 960), ("c4_res960_infer640", 640)):
            res.append(r57.evaluate(tag, pt960, r57.DATA5, sz, 2, "0"))
    r57.report(res)
    (RUNS / "reeval_done.json").write_text(
        json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[64] 完成，{len(res)} 条评测记录已重建", flush=True)


if __name__ == "__main__":
    main()
