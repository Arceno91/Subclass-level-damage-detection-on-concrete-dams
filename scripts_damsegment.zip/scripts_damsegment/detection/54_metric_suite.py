# -*- coding: utf-8 -*-
"""54_metric_suite.py — 统一指标套件（纯推理，不训练）

对给定的权重列表，在各自测试集上计算：
  mAP50 / mAP75 / mAP50-95、逐类 AP50 / AP75 / AP50-95，
  以及类组指标 Base AP（裂缝组）/ Novel AP（剥落组）/ HM（调和平均）。

输出：runs/metrics_suite/suite_<日期>.json + paper/指标套件.md
用法：python 54_metric_suite.py [--device 0] [--only baseline,dacw_b1]
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ultralytics import YOLO  # noqa: E402

D5 = ROOT / "datasets/DamCrack-Sub5/data.yaml"
BATCHES = ROOT / "datasets/DamCrack-Batches"
OUT_JSON = ROOT / "runs/metrics_suite/suite_20260915.json"
OUT_MD = ROOT / "paper/指标套件.md"

NAMES5 = ["crack_fine", "crack_network", "crack_blocky", "spalling_small", "spalling_large"]
NAMES_DSI5 = ["spot_small", "crack_linear", "spalling_area", "crack_branch", "noise_dot"]
NAMES_DSI2 = ["crack", "spalling"]

# (tag, 权重, 数据 yaml, split, 类名, 类组 {组名: 类别下标})
MODELS = [
    ("merged_A", ROOT / "runs/e6_full/fullft_baseline/weights/best.pt", BATCHES / "batchA.yaml", "test", NAMES5, {"裂缝组": [0, 1, 2], "剥落组": [3, 4]}),
    ("merged_B", ROOT / "runs/e6_full/fullft_baseline/weights/best.pt", BATCHES / "batchB.yaml", "test", NAMES5, {"裂缝组": [0, 1, 2], "剥落组": [3, 4]}),
    ("dbjt→A", ROOT / "runs/e16_method/dbjt_batch/weights/best.pt", BATCHES / "batchA.yaml", "test", NAMES5, {"裂缝组": [0, 1, 2], "剥落组": [3, 4]}),
    ("dbjt→B", ROOT / "runs/e16_method/dbjt_batch/weights/best.pt", BATCHES / "batchB.yaml", "test", NAMES5, {"裂缝组": [0, 1, 2], "剥落组": [3, 4]}),
    ("dacw_b1", ROOT / "runs/e16_method/dacw_b1/weights/best.pt", D5, "test", NAMES5, {"裂缝组": [0, 1, 2], "剥落组": [3, 4]}),
    ("dacw_b2", ROOT / "runs/e16_method/dacw_b2/weights/best.pt", D5, "test", NAMES5, {"裂缝组": [0, 1, 2], "剥落组": [3, 4]}),
    ("dsi2_yolo11n", ROOT / "runs/e15_dsi/dsi2_yolo11n/weights/best.pt", ROOT / "datasets/DSI-Det-2cls/data.yaml", "test", NAMES_DSI2, {"裂缝组": [0], "剥落组": [1]}),
    ("dsi5_yolo11n", ROOT / "runs/e15_dsi/dsi5_yolo11n/weights/best.pt", ROOT / "datasets/DSI-Det-5cls/data.yaml", "test", NAMES_DSI5, {}),
    ("baseline", ROOT / "runs/e6_full/fullft_baseline/weights/best.pt", D5, "test", NAMES5, {"裂缝组": [0, 1, 2], "剥落组": [3, 4]}),
]


def evaluate(tag, weights, data_yaml, split, names, groups, device="0", workers=2):
    m = YOLO(str(weights))
    r = m.val(data=str(data_yaml), split=split, imgsz=640, batch=16, workers=workers, device=device,
              project=str(ROOT / "runs/metrics_suite"), name=f"suite_{tag}", exist_ok=True, verbose=False)
    ap = np.asarray(r.box.all_ap, dtype=float)  # (nc, 10) → 列: AP50, 55, ..., 95
    ap50 = ap[:, 0].tolist() if ap.ndim == 2 else []
    ap75 = ap[:, 5].tolist() if ap.ndim == 2 else []
    ap5095 = ap.mean(1).tolist() if ap.ndim == 2 else []
    rec = {
        "tag": tag, "weights": str(weights), "data": str(data_yaml), "split": split,
        "mAP50": float(r.box.map50), "mAP75": float(r.box.map75), "mAP50_95": float(r.box.map),
        "names": names,
        "per_class": [{"name": names[i] if i < len(names) else str(i),
                       "AP50": ap50[i] if i < len(ap50) else None,
                       "AP75": ap75[i] if i < len(ap75) else None,
                       "AP50_95": ap5095[i] if i < len(ap5095) else None} for i in range(len(ap5095))],
        "groups": {},
    }
    for gname, idx in groups.items():
        vals = [ap5095[i] for i in idx if i < len(ap5095)]
        rec["groups"][gname] = float(np.mean(vals)) if vals else None
    g = rec["groups"]
    if len(g) == 2:
        a, b = list(g.values())
        rec["HM"] = float(2 * a * b / (a + b)) if a and b else None
    print(f"[suite] {tag}: mAP50-95={rec['mAP50_95']*100:.2f}% mAP50={rec['mAP50']*100:.2f}% "
          f"mAP75={rec['mAP75']*100:.2f}%" + "".join(f" | {k}={v*100:.2f}%" for k, v in g.items()),
          flush=True)
    return rec


def write_md(results):
    L = ["# 统一指标套件（2026-09-15）", "",
         "全部指标均在各自数据集的 test 划分上、以 640 分辨率、batch 16 复算得到；",
         "Base/Novel 分组沿用子类语义：裂缝组 = 细长/网状/块状裂缝，剥落组 = 小型/大型剥落。", "",
         "| 模型 | mAP50 | mAP75 | mAP50-95 | Base AP | Novel AP | HM |", "|---|---|---|---|---|---|---|"]
    for r in results:
        g = r.get("groups", {})
        vals = list(g.values())
        base = f"{vals[0]*100:.2f}" if len(vals) > 0 and vals[0] else "—"
        novel = f"{vals[1]*100:.2f}" if len(vals) > 1 and vals[1] else "—"
        hm = f"{r['HM']*100:.2f}" if r.get("HM") else "—"
        L.append(f"| {r['tag']} | {r['mAP50']*100:.2f} | {r['mAP75']*100:.2f} | {r['mAP50_95']*100:.2f} | "
                 f"{base} | {novel} | {hm} |")
    for r in results:
        L += ["", f"## {r['tag']} 逐类指标", "", "| 类别 | AP50 | AP75 | AP50-95 |", "|---|---|---|---|"]
        for c in r["per_class"]:
            f = lambda v: "—" if v is None else f"{v*100:.2f}"  # noqa: E731
            L.append(f"| {c['name']} | {f(c['AP50'])} | {f(c['AP75'])} | {f(c['AP50_95'])} |")
    OUT_MD.write_text("\n".join(L), encoding="utf-8")
    return OUT_MD


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="0")
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--only", default="")
    args = ap.parse_args()

    todo = MODELS
    if args.only:
        keep = {s.strip() for s in args.only.split(",")}
        todo = [m for m in MODELS if m[0] in keep]

    results = []
    OUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    if OUT_JSON.exists():  # 分次运行时合并已有结果（按 tag 去重）
        try:
            results = json.loads(OUT_JSON.read_text(encoding="utf-8"))
        except Exception:
            results = []
    for tag, w, d, split, names, groups in todo:
        if not Path(w).exists():
            print(f"[suite] 跳过 {tag}：权重不存在 {w}", flush=True)
            continue
        try:
            rec = evaluate(tag, w, d, split, names, groups, device=args.device, workers=args.workers)
        except Exception as exc:  # noqa: BLE001
            print(f"[suite] {tag} 失败: {type(exc).__name__}: {exc}", flush=True)
            continue
        results = [r for r in results if r.get("tag") != tag] + [rec]
        # 增量落盘：即便后续被硬停止打断，已完成模型的结果也不丢
        OUT_JSON.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
        write_md(results)

    md = OUT_MD
    print(f"[suite] {len(results)} 个模型 -> {OUT_JSON} / {md}", flush=True)


if __name__ == "__main__":
    main()
