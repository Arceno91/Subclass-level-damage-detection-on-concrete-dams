# -*- coding: utf-8 -*-
"""31_novel_probe.py — 新类适配最小可行条件探测（决定是否值得铺 K 扫描）

背景：K=5/类（10 图、15 框）时三种适配策略 Novel AP 均为 0，best 权重停在 epoch 1-2。
本脚本做单组快速判定：K=10 图/类，关闭 Mosaic（小样本下 Mosaic 会破坏语义），
学习率 2e-4，epoch 25，验证集=完整 5 类 val。若 Novel AP > 0 → 值得铺 K 扫描。

用法：python 31_novel_probe.py --kshots 10 --epochs 25 --lr0 0.0002
"""
import argparse
import json
import os
import random
import shutil
import sys
from pathlib import Path

import numpy as np

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ultralytics import YOLO  # noqa: E402

SRC = ROOT / "datasets/DamCrack-Sub5"
RUNS = ROOT / "runs/e11_novel_probe"
NAMES = ["crack_fine", "crack_network", "crack_blocky", "spalling_small", "spalling_large"]
BASE_IDX, NOVEL_IDX = [0, 1, 2], [3, 4]
NOVEL_CLS = {3, 4}


def link_or_copy(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        return
    try:
        os.link(src, dst)
    except OSError:
        shutil.copy2(src, dst)


def build_novel(k, seed):
    """每 novel 类抽 k 张图（仅保留 novel 类框）"""
    rng = random.Random(seed)
    picked = []
    for c in sorted(NOVEL_CLS):
        cands = []
        for txt in sorted((SRC / "labels/train").glob("*.txt")):
            cls = {int(l.split()[0]) for l in txt.read_text(encoding="utf-8").splitlines() if l.strip()}
            if c in cls:
                cands.append(txt.stem)
        picked += rng.sample(cands, min(k, len(cands)))
    picked = sorted(set(picked))
    d = RUNS / f"data_k{k}"
    n_box = 0
    for stem in picked:
        img = SRC / "images/train" / f"{stem}.jpg"
        link_or_copy(img, d / "images" / img.name)
        lines = [ln for ln in (SRC / "labels/train" / f"{stem}.txt").read_text(encoding="utf-8").splitlines()
                 if ln.strip() and int(ln.split()[0]) in NOVEL_CLS]
        n_box += len(lines)
        (d / "labels").mkdir(parents=True, exist_ok=True)
        (d / "labels" / f"{stem}.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (d / "data.yaml").write_text(
        f"path: {d.as_posix()}\ntrain: images\nval: {(SRC/'images/val').as_posix()}\n\nnc: 5\nnames:\n"
        + "".join(f"  {c}: {NAMES[c]}\n" for c in range(5)), encoding="utf-8")
    print(f"[data] K={k}: {len(picked)} 图 / {n_box} 个剥落框")
    return d / "data.yaml", len(picked), n_box


def evaluate(tag, weights):
    m = YOLO(str(weights))
    r = m.val(data=str(SRC / "data.yaml"), split="test", imgsz=640, batch=16, workers=0,
              project=str(RUNS), name=f"eval_{tag}", exist_ok=True, verbose=False)
    ap = np.asarray(r.box.all_ap).mean(1)
    base_ap, novel_ap = float(ap[BASE_IDX].mean()), float(ap[NOVEL_IDX].mean())
    hm = 2 * base_ap * novel_ap / (base_ap + novel_ap) if (base_ap + novel_ap) > 0 else 0.0
    print(f"[eval] {tag}: Base AP={base_ap*100:.2f}% Novel AP={novel_ap*100:.2f}% HM={hm*100:.2f}%", flush=True)
    return {"tag": tag, "base_AP": base_ap, "novel_AP": novel_ap, "HM": hm, "mAP50_95": float(r.box.map)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kshots", type=int, default=10)
    ap.add_argument("--epochs", type=int, default=25)
    ap.add_argument("--lr0", type=float, default=2e-4)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()
    RUNS.mkdir(parents=True, exist_ok=True)
    base_pt = ROOT / "runs/e10_inc/stage1_base/weights/best.pt"
    if not base_pt.exists():
        print("缺少 base 权重，退出")
        return
    data_yaml, n_img, n_box = build_novel(args.kshots, args.seed)
    name = f"probe_k{args.kshots}"
    out = RUNS / name
    if not (out / "weights/best.pt").exists():
        m = YOLO(str(base_pt))
        m.train(data=str(data_yaml), epochs=args.epochs, batch=4, imgsz=640, workers=0, seed=args.seed,
                lr0=args.lr0, mosaic=0.0, close_mosaic=0, project=str(RUNS), name=name, exist_ok=True,
                cache=False, plots=False, patience=10, verbose=True)
    res = evaluate(name, out / "weights/best.pt")
    res.update({"k_shots": args.kshots, "novel_images": n_img, "novel_boxes": n_box})
    (RUNS / "probe_results.json").write_text(json.dumps([res], ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n判定：Novel AP = {res['novel_AP']*100:.2f}% → "
          + ("新类可学（值得铺 K 扫描）" if res["novel_AP"] > 0.005 else "仍不可学（记录为边界结论）"))


if __name__ == "__main__":
    main()
