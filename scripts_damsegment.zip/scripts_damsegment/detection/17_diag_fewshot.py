# -*- coding: utf-8 -*-
"""
17_diag_fewshot.py — MoLoRA 少样本诊断（K=5, seed 42, 与 K=5 原组完全同协议/同子集）

诊断问题: K=5 下 MoLoRA(0.71%) 远低于 Full FT(4.54%)——真输还是配方失配?
  D1 diag1_molora_fs : MoLoRA + lora_few_shot_mode=True（自适应秩/dropconnect 等少样本机制）
  D2 diag2_molora_2e4r: MoLoRA 参数收缩: experts=2, r=4

与 15_kshot_matrix 的 K=5 组共享同一子集构建（同 seed 42 → 完全可比）。
用法: python 17_diag_fewshot.py [--diags d1,d2]
"""
import argparse
import json
import sys
from pathlib import Path

YOLO_PEFT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(YOLO_PEFT) not in sys.path:
    sys.path.insert(0, str(YOLO_PEFT))

import importlib.util  # noqa: E402

spec = importlib.util.spec_from_file_location("kshot15", YOLO_PEFT / "scripts/damsegment/detection/15_kshot_matrix.py")
kshot = importlib.util.module_from_spec(spec)
spec.loader.exec_module(kshot)  # noqa: E402

K = 5
SEED = 42
RUNS = kshot.RUNS

DIAGS = {
    "d1": dict(base="molora", extra=dict(lora_few_shot_mode=True)),
    "d2": dict(base="molora", extra=dict(molora_num_experts=2, molora_r=4)),
    "d4": dict(base="lora", extra=dict(
        lora_backend="fallback", lora_few_shot_mode=True,
        lora_few_shot_teacher=str(YOLO_PEFT / "runs/e6_full/fullft_baseline/weights/best.pt"),
        lora_few_shot_response_distill=True, lora_few_shot_distill_weight=0.5,
    )),
}


def run_diag(name, base, extra):
    import shutil
    from ultralytics import YOLO

    kd = RUNS / f".tmp_diag_{name}"
    (kd / "images").mkdir(parents=True, exist_ok=True)
    (kd / "labels").mkdir(parents=True, exist_ok=True)
    # reuse the exact same subset builder as the official K-shot runs
    img_dir, lbl_dir, stems = kshot.build_kshot_subset(K, SEED)
    for s in stems:
        shutil.copy2(img_dir / f"{s}.jpg", kd / "images" / f"{s}.jpg")
        shutil.copy2(lbl_dir / f"{s}.txt", kd / "labels" / f"{s}.txt")
    data_k = kd / "data.yaml"
    data_k.write_text(
        f"path: {kd.as_posix()}\ntrain: images\nval: {kshot.DATA_YAML.parent.as_posix()}/images/val\n"
        f"test: {kshot.DATA_YAML.parent.as_posix()}/images/test\n\nnc: 5\nnames:\n"
        + "".join(f"  {c}: {kshot.CLASSES[c]}\n" for c in range(5)),
        encoding="utf-8",
    )
    model = YOLO(str(kshot.PT))
    kwargs = dict(
        data=str(data_k), epochs=kshot.EPOCHS, batch=kshot.BATCH, imgsz=640, workers=2, seed=SEED,
        project=str(RUNS), name=name, exist_ok=True, cache=False, plots=False, verbose=False,
        close_mosaic=10, amp=True,
    )
    if base == "molora":
        kwargs.update(kshot.MOLORA_ARGS)  # contains amp=False
    else:
        kwargs.update(dict(lora_type="lora", lora_backend="fallback", lora_r=8, lora_alpha=16))
    kwargs.update(extra)
    model.train(**kwargs)
    m2 = YOLO(str(RUNS / name / "weights" / "best.pt"))
    res = m2.val(data=str(kshot.DATA_YAML), split="test", imgsz=640, batch=8, workers=2,
                 project=str(RUNS), name=f"{name}_test", exist_ok=True, verbose=False)
    pc = {}
    names = res.names
    for c in range(5):
        pc[names[c]] = {"ap50_95": float(res.box.ap[c]), "ap50": float(res.box.ap50[c])}
    rec = {"k": K, "method": name, "seed": SEED, "n_train_images": len(stems),
           "mAP50_95": float(res.box.map), "mAP50": float(res.box.map50), "per_class": pc}
    shutil.rmtree(kd, ignore_errors=True)
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--diags", default="d1,d2")
    args = ap.parse_args()
    results = []
    for d in [x.strip() for x in args.diags.split(",") if x.strip()]:
        cfg = DIAGS[d]
        name = f"diag_{d}_{cfg['base']}_k{K}_s{SEED}"
        print(f"\n===== 诊断 {d}: {name} {cfg['extra']} =====")
        try:
            rec = run_diag(name, cfg["base"], cfg["extra"])
        except Exception as e:  # noqa: BLE001
            print(f"[FAIL] {d}: {e}")
            rec = {"k": K, "method": name, "seed": SEED, "error": str(e)}
        results.append(rec)
        with (RUNS / "diag_results.json").open("w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
    print("\n===== 诊断汇总 (test mAP50-95, 对照: full=4.54% | molora=0.71%) =====")
    for r in results:
        if "error" in r:
            print(f"  {r['method']}: ERROR {r['error'][:100]}")
        else:
            pc = r["per_class"]
            print(f"  {r['method']}: {r['mAP50_95']*100:.2f}% | sp_small {pc.get('spalling_small',{}).get('ap50_95',0)*100:.2f}% "
                  f"| sp_large {pc.get('spalling_large',{}).get('ap50_95',0)*100:.2f}% | n={r['n_train_images']}")


if __name__ == "__main__":
    main()
