# -*- coding: utf-8 -*-
"""
15_kshot_matrix.py — DamCrack-Sub5 5-way K-shot 少样本域适配矩阵

协议:
  在 DamCrack-Sub5 train(3902) 上按子类均衡采样 K 张/类（5-way K-shot），
  仅用该子集训练；val 全量 1065 用于早停/选最优；test 全量 533 用于最终报告。

矩阵: K ∈ {1,5,10} × 方法 {full, lora, molora} × seeds {42, ...}
  全量微调 full   : 无 PEFT（传统做法）
  LoRA           : lora_type=lora, r=8, alpha=16
  MoLoRA         : E2 配方 (experts=4, top_k=2, r=8, alpha=16, linear router, balance 0.01, include_head)

用法:
  python 15_kshot_matrix.py --seeds 42            # 快速 9 组 (~20 min)
  python 15_kshot_matrix.py --seeds 42,123,456    # 论文版 27 组
"""
import argparse
import json
import random
import sys
from pathlib import Path

YOLO_PEFT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(YOLO_PEFT) not in sys.path:
    sys.path.insert(0, str(YOLO_PEFT))

from ultralytics import YOLO  # noqa: E402

DATA_YAML = YOLO_PEFT / "datasets" / "DamCrack-Sub5" / "data.yaml"
RUNS = YOLO_PEFT / "runs" / "e6_kshot"
PT = YOLO_PEFT / "yolo11n.pt"
SEED = 42
EPOCHS = 50
BATCH = 8

# 子类 id -> 名称（与 data.yaml 一致）
CLASSES = {0: "crack_fine", 1: "crack_network", 2: "crack_blocky", 3: "spalling_small", 4: "spalling_large"}

MOLORA_ARGS = dict(
    molora_num_experts=4, molora_top_k=2, molora_r=8, molora_alpha=16,
    molora_router_type="linear", molora_balance_loss=0.01, molora_use_rslora=True,
    lora_include_head=True, amp=False,
)


def parse_boxes(txt):
    out = []
    for ln in txt.read_text(encoding="utf-8", errors="ignore").splitlines():
        ln = ln.strip()
        if ln:
            out.append(int(ln.split()[0]))
    return out


def build_kshot_subset(k, seed=SEED):
    """从 train 选 K 张/类（类内采样，图片去重），返回 (images, labels) 临时目录对."""
    train_img = DATA_YAML.parent / "images" / "train"
    train_lbl = DATA_YAML.parent / "labels" / "train"
    per_class = {c: [] for c in CLASSES}
    for lbl in sorted(train_lbl.glob("*.txt")):
        cls = set(parse_boxes(lbl))
        for c in cls:
            if c in per_class:
                per_class[c].append(lbl)
    rng = random.Random(seed)
    picked = set()
    for c in sorted(CLASSES):
        pool = per_class[c]
        if len(pool) < k:
            print(f"[warn] class {CLASSES[c]} 仅 {len(pool)} 张图 < K={k}")
        for lbl in rng.sample(pool, min(k, len(pool))):
            picked.add(lbl.stem)
    return train_img, train_lbl, sorted(picked)


def run_one(k, method, seed):
    out_dir = RUNS / f"{method}_K{k}_s{seed}"
    img_dir, lbl_dir, stems = build_kshot_subset(k, seed)
    kd = RUNS / f".tmp_kshot_K{k}_s{seed}"
    (kd / "images").mkdir(parents=True, exist_ok=True)
    (kd / "labels").mkdir(parents=True, exist_ok=True)
    import shutil
    for s in stems:
        shutil.copy2(img_dir / f"{s}.jpg", kd / "images" / f"{s}.jpg")
        shutil.copy2(lbl_dir / f"{s}.txt", kd / "labels" / f"{s}.txt")
    # 临时 data.yaml
    data_k = kd / "data.yaml"
    data_k.write_text(
        f"path: {kd.as_posix()}\ntrain: images\nval: {DATA_YAML.parent.as_posix()}/images/val\n"
        f"test: {DATA_YAML.parent.as_posix()}/images/test\n\nnc: 5\nnames:\n" +
        "".join(f"  {c}: {CLASSES[c]}\n" for c in range(5)),
        encoding="utf-8",
    )
    model = YOLO(str(PT))
    kwargs = dict(
        data=str(data_k), epochs=EPOCHS, batch=BATCH, imgsz=640, workers=2, seed=seed,
        project=str(RUNS), name=f"{method}_K{k}_s{seed}", exist_ok=True, cache=False,
        plots=False, verbose=False, close_mosaic=10, amp=True,
    )
    if method == "lora":
        kwargs.update(lora_type="lora", lora_backend="fallback", lora_r=8, lora_alpha=16)
    elif method == "molora":
        kwargs.update(MOLORA_ARGS)
    model.train(**kwargs)
    # test 评估
    m2 = YOLO(str(out_dir / "weights" / "best.pt"))
    res = m2.val(data=str(DATA_YAML), split="test", imgsz=640, batch=8, workers=2,
                 project=str(RUNS), name=f"{method}_K{k}_s{seed}_test", exist_ok=True, verbose=False)
    pc = {}
    names = res.names
    ap_idx = res.box.ap_class_index if hasattr(res.box, "ap_class_index") else None
    names_list = [names[i] for i in ap_idx] if ap_idx is not None else list(names.values())
    for i, cname in enumerate(names_list):
        pc[cname] = {"ap50_95": float(res.box.ap[i]), "ap50": float(res.box.ap50[i])}
    rec = {
        "k": k, "method": method, "seed": seed, "n_train_images": len(stems),
        "mAP50_95": float(res.box.map), "mAP50": float(res.box.map50) if hasattr(res.box, "map50") else float(res.box.mp50),
        "per_class": pc,
    }
    shutil.rmtree(kd, ignore_errors=True)
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", default="42", help="逗号分隔 seed 列表")
    ap.add_argument("--ks", default="1,5,10")
    ap.add_argument("--methods", default="full,lora,molora")
    args = ap.parse_args()
    seeds = [int(x) for x in args.seeds.split(",")]
    ks = [int(x) for x in args.ks.split(",")]
    methods = [x.strip() for x in args.methods.split(",") if x.strip()]
    RUNS.mkdir(parents=True, exist_ok=True)
    results = []
    for k in ks:
        for m in methods:
            for s in seeds:
                print(f"\n===== K={k} {m} seed={s} =====")
                try:
                    rec = run_one(k, m, s)
                except Exception as e:  # noqa: BLE001
                    print(f"[FAIL] K={k} {m} seed={s}: {e}")
                    rec = {"k": k, "method": m, "seed": s, "error": str(e)}
                results.append(rec)
                with (RUNS / "kshot_results.json").open("w", encoding="utf-8") as f:
                    json.dump(results, f, ensure_ascii=False, indent=2)
    # 汇总表
    print("\n===== 汇总 (test mAP50-95) =====")
    for r in results:
        if "error" in r:
            print(f"  K={r['k']} {r['method']} s{r['seed']}: ERROR")
        else:
            print(f"  K={r['k']} {r['method']} s{r['seed']}: {r['mAP50_95']*100:.2f}%  "
                  f"(n={r['n_train_images']}, tail c3={r['per_class'].get('spalling_small',{}).get('ap50_95',0)*100:.2f}%, "
                  f"c4={r['per_class'].get('spalling_large',{}).get('ap50_95',0)*100:.2f}%)")


if __name__ == "__main__":
    main()
