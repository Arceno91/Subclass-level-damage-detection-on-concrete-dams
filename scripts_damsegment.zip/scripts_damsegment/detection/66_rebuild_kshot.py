# -*- coding: utf-8 -*-
"""66_rebuild_kshot.py — 重建 K-shot 汇总证据（runs/e6_kshot/kshot_results.json）

背景：kshot_results.json 曾被一次局部的 15_kshot_matrix.py 运行覆盖，只剩 1 条记录。
本脚本对现存全部 K-shot 权重在 DamCrack-Sub5 test 集上重评，重建完整记录
（字段格式与历史文件一致：k / method / seed / n_train_images / mAP50_95 / mAP50 / per_class）。
"""
import json
import sys
from pathlib import Path

import torch

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ultralytics import YOLO  # noqa: E402

KS = ROOT / "runs/e6_kshot"
DATA5 = ROOT / "datasets/DamCrack-Sub5"
NAMES = ["crack_fine", "crack_network", "crack_blocky", "spalling_small", "spalling_large"]


def main():
    runs = sorted([d for d in KS.iterdir()
                   if d.is_dir() and not d.name.endswith("_test")
                   and (d / "weights/best.pt").exists()])
    results = []
    for d in runs:
        r = YOLO(str(d / "weights/best.pt")).val(
            data=str(DATA5 / "data.yaml"), split="test", imgsz=640, batch=16, workers=2,
            device="0", project=str(KS), name=f"reeval_{d.name}", exist_ok=True, verbose=False)
        ap = r.box.all_ap
        per = {}
        if ap is not None and getattr(ap, "ndim", 0) == 2:
            mean = ap.mean(1).tolist()
            per = {n: {"ap50_95": float(v)} for n, v in zip(NAMES, mean)}
        # 解析 K 与 n_train_images
        name = d.name
        k = None
        for part in name.split("_"):
            if part.upper().startswith("K") and part[1:].isdigit():
                k = int(part[1:])
        n_train = {1: 5, 5: 25, 10: 50}.get(k, 25)
        rec = {"k": k, "method": name, "seed": 42, "n_train_images": n_train,
               "mAP50_95": float(r.box.map), "mAP50": float(r.box.map50), "per_class": per}
        results.append(rec)
        print(f"[66] {name:26s} K={k} mAP={rec['mAP50_95']*100:5.2f}", flush=True)
        torch.cuda.empty_cache()
    (KS / "kshot_results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2),
                                           encoding="utf-8")
    print(f"[66] done, {len(results)} 条 -> runs/e6_kshot/kshot_results.json", flush=True)


if __name__ == "__main__":
    main()
