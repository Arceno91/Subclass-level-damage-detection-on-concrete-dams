# -*- coding: utf-8 -*-
"""57_resolution_experiment.py — 方法支柱正结果候选：训练分辨率与数据侧重采样（C4 / C3）

动机（正文 4.13 节的机制论证）：
  难度的根源是目标在当前成像条件下的可分性（像素跨度），而非类别频率。
  已验证：损失侧重加权（M1）与域重复上采样（M3）均无增益。
  因此正向干预应落在"信息量"上——本脚本实现两个候选：
    C4  训练分辨率对齐：640（对照，已有基线）→ 896，检验细长裂缝 AP 是否提升及算力代价
    C3  数据侧难度过采样：把含细裂缝的训练图像重复（不改损失权重），检验难度是否应作用于数据分布

输出：runs/e17_resolution/{exp}/ + runs/e17_resolution/results.json + paper/分辨率实验.md
用法：
  python 57_resolution_experiment.py --exp c4 --imgsz 896 --batch 8 --workers 2 --device 0
  python 57_resolution_experiment.py --exp c3 --workers 2 --device 0
  python 57_resolution_experiment.py --exp eval --weights <path> --imgsz 896   # 仅评估
"""
import argparse
import json
import os
import shutil
import sys
from pathlib import Path

import numpy as np

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ultralytics import YOLO  # noqa: E402

DATA5 = ROOT / "datasets/DamCrack-Sub5/data.yaml"
RUNS = ROOT / "runs/e17_resolution"
NAMES = ["crack_fine", "crack_network", "crack_blocky", "spalling_small", "spalling_large"]
BASE_REF = {"mAP50_95": 34.34, "crack_fine": 29.17, "spalling_large": 44.05}  # 640 基线（种子 42）


def strip_scaler(weights):
    """修复 resume 的 GradScaler 空状态 bug：续训前删除 checkpoint 中的 scaler。"""
    import torch
    ck = torch.load(str(weights), map_location="cpu")
    if "scaler" in ck:
        ck.pop("scaler")
        torch.save(ck, str(weights))


def link_or_copy(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        return
    try:
        os.link(src, dst)
    except OSError:
        shutil.copy2(src, dst)


def build_hard_oversampled(out_dir: Path, factor: int = 2) -> Path:
    """C3：把包含细裂缝（crack_fine）的训练图像重复 factor 份（数据侧难度过采样）。"""
    src_img = ROOT / "datasets/DamCrack-Sub5/images/train"
    src_lbl = ROOT / "datasets/DamCrack-Sub5/labels/train"
    (out_dir / "images").mkdir(parents=True, exist_ok=True)
    (out_dir / "labels").mkdir(parents=True, exist_ok=True)
    hard = set()
    for lp in sorted(src_lbl.glob("*.txt")):
        for line in lp.read_text(encoding="utf-8").splitlines():
            if line.strip() and int(line.split()[0]) == 0:  # crack_fine
                hard.add(lp.stem)
                break
    n_hard = 0
    for lp in sorted(src_lbl.glob("*.txt")):
        stem = lp.stem
        img = src_img / f"{stem}.jpg"
        if not img.exists():
            continue
        link_or_copy(img, out_dir / "images" / f"{stem}.jpg")
        shutil.copy2(lp, out_dir / "labels" / f"{stem}.txt")
        if stem in hard:
            n_hard += 1
            for k in range(1, factor):
                link_or_copy(img, out_dir / "images" / f"{stem}_dup{k}.jpg")
                shutil.copy2(lp, out_dir / "labels" / f"{stem}_dup{k}.txt")
    (out_dir / "data.yaml").write_text(
        f"path: {out_dir.as_posix()}\ntrain: images\n"
        f"val: {(ROOT/'datasets/DamCrack-Sub5/images/val').as_posix()}\n"
        f"test: {(ROOT/'datasets/DamCrack-Sub5/images/test').as_posix()}\n\nnc: 5\nnames:\n"
        + "".join(f"  {c}: {NAMES[c]}\n" for c in range(5)), encoding="utf-8")
    total = len(list((out_dir / "images").glob("*.jpg")))
    print(f"[C3] 含细裂缝图像 {n_hard} 幅 ×{factor} → 训练集共 {total} 幅", flush=True)
    return out_dir / "data.yaml"


def train(tag, data_yaml, imgsz, batch, epochs, workers, device, lr0=None):
    out = RUNS / tag
    csv = out / "results.csv"
    if (out / "weights/best.pt").exists() and csv.exists():
        rows = [r for r in csv.read_text(encoding="utf-8").splitlines() if r.strip()]
        try:
            if int(float(rows[-1].split(",")[0])) >= epochs:
                print(f"[{tag}] 已完成 {epochs} 轮，跳过")
                return out / "weights/best.pt"
        except Exception:
            pass
    if out.exists():  # 中断残档：有 last.pt 则断点续训，否则清掉重训
        last = out / "weights" / "last.pt"
        if last.exists() and (out / "args.yaml").exists():
            print(f"[{tag}] 发现未完成残档，从 last.pt 断点续训")
            strip_scaler(last)
            YOLO(str(last)).train(resume=True)
            return out / "weights/best.pt"
        print(f"[{tag}] 无可续训残档，清除后重训")
        shutil.rmtree(out, ignore_errors=True)
    kw = dict(data=str(data_yaml), epochs=epochs, batch=batch, imgsz=imgsz, workers=workers,
              device=device, seed=42, deterministic=True, project=str(RUNS), name=tag,
              exist_ok=True, cache=False, plots=False, close_mosaic=10, verbose=True)
    if lr0:
        kw["lr0"] = lr0
    print(f"[{tag}] 训练开始 imgsz={imgsz} batch={batch} epochs={epochs}", flush=True)
    YOLO(str(ROOT / "yolo11n.pt")).train(**kw)
    return out / "weights/best.pt"


def evaluate(tag, weights, data_yaml, imgsz, workers, device, split="test"):
    r = YOLO(str(weights)).val(data=str(data_yaml), split=split, imgsz=imgsz, batch=8, workers=workers,
                               device=device, project=str(RUNS), name=f"eval_{tag}_sz{imgsz}",
                               exist_ok=True, verbose=False)
    ap = np.asarray(r.box.all_ap, dtype=float)
    per = ap.mean(1).tolist() if ap.ndim == 2 else []
    rec = {"tag": tag, "imgsz": imgsz, "weights": str(weights), "mAP50_95": float(r.box.map),
           "mAP50": float(r.box.map50), "mAP75": float(r.box.map75),
           "per_class": {NAMES[i]: float(per[i]) for i in range(min(len(per), len(NAMES)))},
           "params_M": None, "gflops": None}
    try:
        from ultralytics.utils.torch_utils import get_flops

        m = YOLO(str(weights)).model
        rec["gflops"] = float(get_flops(m, imgsz))
        rec["params_M"] = float(sum(p.numel() for p in m.parameters()) / 1e6)
    except Exception:
        pass
    print(f"[eval] {tag} @{imgsz}: mAP50-95={rec['mAP50_95']*100:.2f}% "
          f"crack_fine={rec['per_class'].get('crack_fine', 0)*100:.2f}% "
          f"spalling_large={rec['per_class'].get('spalling_large', 0)*100:.2f}%", flush=True)
    return rec


def report(results):
    L = ["# 分辨率与数据侧重采样实验（C4 / C3）", "",
         "对照口径：全部为 YOLO11n、80 轮、种子 42、末段 10 轮关闭 Mosaic；640 列取主基线（已实测）。", "",
         "| 实验 | 训练分辨率 | mAP50-95 | mAP50 | mAP75 | 细长裂缝 | 大型剥落 | 参数量(M) | GFLOPs |",
         "|---|---|---|---|---|---|---|---|---|"]
    ref = f"| 参照：主基线 | 640 | {BASE_REF['mAP50_95']:.2f} | 57.08 | 36.40 | {BASE_REF['crack_fine']:.2f} | {BASE_REF['spalling_large']:.2f} | 2.591 | 6.44 |"
    L.append(ref)
    for r in results:
        pc = r["per_class"]
        L.append(f"| {r['tag']} | {r['imgsz']} | {r['mAP50_95']*100:.2f} | {r['mAP50']*100:.2f} | "
                 f"{r['mAP75']*100:.2f} | {pc.get('crack_fine', 0)*100:.2f} | {pc.get('spalling_large', 0)*100:.2f} | "
                 f"{r['params_M']:.3f} | {r['gflops']:.1f} |")
    ok = [r for r in results if r["imgsz"] >= 800]
    if ok:
        best = max(ok, key=lambda r: r["mAP50_95"])
        dc = best["per_class"].get("crack_fine", 0) * 100 - BASE_REF["crack_fine"]
        dt = best["mAP50_95"] * 100 - BASE_REF["mAP50_95"]
        gl = (best["gflops"] or 0) / 6.3 if best["gflops"] else float("nan")
        L += ["", "## 判读", "",
              f"- 分辨率提升到 {best['imgsz']} 后：整体 mAP {dt:+.2f} 点，细长裂缝 AP {dc:+.2f} 点。",
              f"- 算力代价：GFLOPs 约 {gl:.2f}×（{best['gflops']:.1f} vs 6.3）。",
              "- 若细长裂缝 AP 明显提升（>1 点）且整体不降，则支持「把训练分辨率对齐到目标像素跨度」作为方法支柱的正结果；"
              "若提升有限，则方法贡献应落在「难度-干预决策协议」（见 paper/方法实验_解读.md §1.4）。"]
    (ROOT / "paper/分辨率实验.md").write_text("\n".join(L), encoding="utf-8")
    (RUNS / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    print("[report] -> paper/分辨率实验.md", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--exp", default="c4", choices=["c4", "c3", "all", "eval"])
    ap.add_argument("--imgsz", type=int, default=896)
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--epochs", type=int, default=80)
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--device", default="0")
    ap.add_argument("--weights", default="")
    args = ap.parse_args()
    RUNS.mkdir(parents=True, exist_ok=True)

    results = []
    if args.exp in ("c4", "all"):
        tag = f"c4_res{args.imgsz}"
        pt = train(tag, DATA5, args.imgsz, args.batch, args.epochs, args.workers, args.device)
        results.append(evaluate(tag, pt, DATA5, args.imgsz, args.workers, args.device))
        # 训练/推理分辨率交叉检查：高分辨率训练、640 推理
        if args.imgsz != 640:
            results.append(evaluate(f"{tag}_infer640", pt, DATA5, 640, args.workers, args.device))
    if args.exp in ("c3", "all"):
        yaml = build_hard_oversampled(RUNS / "data_hard_x2", factor=2)
        pt = train("c3_hardx2", yaml, 640, 16, args.epochs, args.workers, args.device)
        results.append(evaluate("c3_hardx2", pt, DATA5, 640, args.workers, args.device))
    if args.exp == "eval" and args.weights:
        results.append(evaluate(Path(args.weights).stem, args.weights, DATA5, args.imgsz,
                                args.workers, args.device))

    if results:
        report(results)
    else:
        print("[warn] 没有产生结果（--exp eval 需要 --weights）")


if __name__ == "__main__":
    main()
