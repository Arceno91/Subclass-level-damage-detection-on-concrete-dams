# -*- coding: utf-8 -*-
"""62_annot_budget.py — crack_fine 增量标注学习曲线（回应审稿意见第 1 条后半）

设计：固定其它类图像全部保留，把「含 crack_fine 框」的训练图像按比例随机剔除
（10% / 25% / 50% / 100% 保留），每次用 yolo11n 80ep/bs16/seed42 训练并测 test 集
crack_fine AP —— 得到"标注预算 → 细裂缝 AP"学习曲线，支撑"增加真实样本优先于
损失重配平"的决策规则。
输出：runs/e18_annot_budget/{results.json, learning_curve.csv}
用法：python 62_annot_budget.py --fracs 0.10,0.25,0.50,1.00
"""
import argparse
import csv
import json
import random
import shutil
import sys
from pathlib import Path

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ultralytics import YOLO  # noqa: E402

DATA5 = ROOT / "datasets/DamCrack-Sub5"
RUNS = ROOT / "runs/e18_annot_budget"
NAMES = ["crack_fine", "crack_network", "crack_blocky", "spalling_small", "spalling_large"]


def link_or_copy(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        return
    try:
        os_link = getattr(__import__("os"), "link")
        os_link(src, dst)
    except OSError:
        shutil.copy2(src, dst)


def build_subset(frac: float) -> Path:
    """保留 frac 比例的含 crack_fine 训练图；其它训练图全保留。"""
    src_img = DATA5 / "images/train"
    src_lbl = DATA5 / "labels/train"
    out = RUNS / f"data_cf{int(frac * 100)}"
    shutil.rmtree(out, ignore_errors=True)
    out.mkdir(parents=True)
    (out / "labels").mkdir(parents=True, exist_ok=True)
    hard, others = [], []
    for lp in sorted(src_lbl.glob("*.txt")):
        has = any(l.strip() and int(l.split()[0]) == 0 for l in lp.read_text(encoding="utf-8").splitlines())
        (hard if has else others).append(lp)
    rng = random.Random(42)
    keep = set(rng.sample(hard, max(1, int(round(len(hard) * frac)))))
    for lp in hard + others:
        if lp in hard and lp not in keep:
            continue
        link_or_copy(src_img / f"{lp.stem}.jpg", out / "images" / f"{lp.stem}.jpg")
        shutil.copy2(lp, out / "labels" / f"{lp.stem}.txt")
    (out / "data.yaml").write_text(
        f"path: {out.as_posix()}\ntrain: images\nval: {(DATA5 / 'images/val').as_posix()}\n"
        f"test: {(DATA5 / 'images/test').as_posix()}\n\nnc: 5\nnames:\n"
        + "".join(f"  {c}: {NAMES[c]}\n" for c in range(5)), encoding="utf-8")
    n = len(list((out / "images").glob("*.jpg")))
    print(f"[62] frac={frac:.2f}: 保留含 crack_fine 图 {len(keep)}/{len(hard)}，训练集共 {n} 幅", flush=True)
    return out / "data.yaml"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fracs", default="0.10,0.25,0.50,1.00")
    ap.add_argument("--device", default="0")
    args = ap.parse_args()
    fracs = [float(x) for x in args.fracs.split(",") if x.strip()]
    RUNS.mkdir(parents=True, exist_ok=True)
    results = []
    rj = RUNS / "results.json"
    if rj.exists():
        try:
            results = json.loads(rj.read_text(encoding="utf-8"))
        except Exception:
            results = []
    have = {r.get("frac_crack_fine") for r in results}

    def save_results():
        rj.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")

    def evaluate(tag):
        r = YOLO(str(RUNS / tag / "weights/best.pt")).val(
            data=str(DATA5 / "data.yaml"), split="test", imgsz=640, batch=16, workers=2,
            device=args.device, project=str(RUNS), name=f"eval_{tag}", exist_ok=True, verbose=False)
        ap_mat = getattr(r.box, "all_ap", None)
        per = [float(x) for x in ap_mat.mean(1)] if (ap_mat is not None and getattr(ap_mat, "ndim", 0) == 2) else []
        return {"mAP50_95": float(r.box.map), "mAP50": float(r.box.map50),
                "crack_fine_AP": float(per[0]) if len(per) > 0 else None}

    for frac in fracs:
        tag = f"cf{int(frac * 100)}"
        csv_path = RUNS / tag / "results.csv"
        complete = False
        if (RUNS / tag / "weights/best.pt").exists() and csv_path.exists():
            rows = [l for l in csv_path.read_text(encoding="utf-8").splitlines() if l.strip()]
            try:
                complete = int(float(rows[-1].split(",")[0])) >= 80
            except Exception:
                complete = False
        if complete:
            if frac in have:
                print(f"[62] {tag} 已完成，跳过", flush=True)
                continue
            rec = {"frac_crack_fine": frac, **evaluate(tag)}  # 已训练但缺结果：只补评测
            results.append(rec)
            save_results()
            print(f"[62] {tag} 补评测：mAP={rec['mAP50_95'] * 100:.2f}%", flush=True)
            continue
        yaml = build_subset(frac)
        last = RUNS / tag / "weights" / "last.pt"
        if last.exists() and (RUNS / tag / "args.yaml").exists():
            print(f"[62] {tag} 从 last.pt 断点续训", flush=True)
            import torch
            ck = torch.load(str(last), map_location="cpu")
            if "scaler" in ck:
                ck.pop("scaler")
                torch.save(ck, str(last))
            YOLO(str(last)).train(resume=True)
        else:
            YOLO(str(ROOT / "yolo11n.pt")).train(
                data=str(yaml), epochs=80, batch=16, imgsz=640, workers=2, device=args.device,
                seed=42, deterministic=True, project=str(RUNS), name=tag, exist_ok=True,
                cache=False, plots=False, close_mosaic=10, verbose=True)
        rec = {"frac_crack_fine": frac, **evaluate(tag)}
        results.append(rec)
        save_results()
        print(f"[62] {tag}: mAP={rec['mAP50_95'] * 100:.2f}% crack_fine={rec['crack_fine_AP'] and rec['crack_fine_AP'] * 100:.2f}%", flush=True)
    (RUNS / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    with (RUNS / "learning_curve.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["frac_crack_fine", "mAP50_95", "mAP50", "crack_fine_AP"])
        for r in results:
            w.writerow([r["frac_crack_fine"], f"{r['mAP50_95'] * 100:.2f}", f"{r['mAP50'] * 100:.2f}",
                        f"{r['crack_fine_AP'] * 100:.2f}" if r["crack_fine_AP"] else ""])
    print("[62] done -> runs/e18_annot_budget/", flush=True)


if __name__ == "__main__":
    main()
