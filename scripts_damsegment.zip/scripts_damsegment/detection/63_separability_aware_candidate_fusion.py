# -*- coding: utf-8 -*-
"""Separability-aware candidate fusion (SACF).

SACF combines a full-frame detector with a local-zoom detector. Candidates
from both experts are described by confidence, scale, aspect ratio and
cross-expert agreement. A class-specific logistic calibrator is trained only
on the validation split and then applied unchanged to the test split.

Usage:
  python 63_separability_aware_candidate_fusion.py \
      --data datasets/DamCrack-Sub5/data.yaml \
      --weights runs/e6_full/fullft_baseline/weights/best.pt \
      --tile-size 448 --overlap 0.5 \
      --out runs/e18_sacf/main.json
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import yaml
from PIL import Image
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ultralytics import YOLO  # noqa: E402

SGAT_PATH = Path(__file__).with_name("62_separability_guided_adaptive_tiling.py")
SPEC = importlib.util.spec_from_file_location("sgat_utils", SGAT_PATH)
SGAT = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(SGAT)


def class_names(data_yaml: dict) -> dict[int, str]:
    return SGAT.class_names(data_yaml)


def dataset_paths(data_arg: str):
    data_path = (ROOT / data_arg).resolve() if not Path(data_arg).is_absolute() else Path(data_arg)
    data_yaml = SGAT.load_yaml(data_path)
    return data_path, data_yaml


def collect_detections(
    model: YOLO,
    image_paths: list[Path],
    labels_dir: Path,
    tile_size: int,
    overlap: float,
    imgsz: int,
    conf: float,
    iou: float,
    max_det: int,
) -> list[dict]:
    records = []
    for index, image_path in enumerate(image_paths, start=1):
        image = cv2.imread(str(image_path))
        if image is None:
            continue
        height, width = image.shape[:2]
        gt_boxes, gt_classes = SGAT.load_ground_truth(labels_dir / f"{image_path.stem}.txt", width, height)
        global_det = SGAT.predict_arrays(model, [image], imgsz, conf, iou, max_det)[0]
        tiles = SGAT.tile_grid(width, height, tile_size, overlap)
        tile_det, _elapsed = SGAT.infer_tiles(model, image, tiles, imgsz, conf, iou, max_det)
        records.append(
            {
                "name": image_path.name,
                "shape": (height, width),
                "gt_boxes": gt_boxes,
                "gt_classes": gt_classes,
                "global": global_det,
                "tile": tile_det,
            }
        )
        if index % 25 == 0:
            print(f"[collect {index}/{len(image_paths)}] {image_path.name}", flush=True)
    return records


def expert_metrics(records: list[dict], names: dict[int, str], expert: str) -> dict:
    stats = []
    for record in records:
        boxes, scores, classes = record[expert]
        stats.append(
            {
                "tp": SGAT.match_tp(boxes, scores, classes, record["gt_boxes"], record["gt_classes"]),
                "target_cls": record["gt_classes"],
                "target_img": np.unique(record["gt_classes"]),
                "im_name": record["name"],
                "conf": scores if len(scores) else np.zeros(0),
                "pred_cls": classes if len(classes) else np.zeros(0),
            }
        )
    return SGAT.metrics_for(stats, names)


def union_metrics(records: list[dict], names: dict[int, str], iou_threshold: float) -> dict:
    stats = []
    for record in records:
        boxes, scores, classes = SGAT.merge_detections([record["global"], record["tile"]], iou_threshold)
        stats.append(
            {
                "tp": SGAT.match_tp(boxes, scores, classes, record["gt_boxes"], record["gt_classes"]),
                "target_cls": record["gt_classes"],
                "target_img": np.unique(record["gt_classes"]),
                "im_name": record["name"],
                "conf": scores if len(scores) else np.zeros(0),
                "pred_cls": classes if len(classes) else np.zeros(0),
            }
        )
    return SGAT.metrics_for(stats, names)


def candidate_features(
    record: dict,
    class_idx: int,
    source: str,
) -> tuple[np.ndarray, np.ndarray]:
    """Return features and best-IoU targets for one class and one expert."""
    boxes, scores, classes = record[source]
    keep = classes.astype(int) == class_idx
    boxes = boxes[keep]
    scores = scores[keep]
    other_source = "tile" if source == "global" else "global"
    other_boxes, other_scores, other_classes = record[other_source]
    other_keep = other_classes.astype(int) == class_idx
    other_boxes = other_boxes[other_keep]
    other_scores = other_scores[other_keep]
    gt_boxes = record["gt_boxes"][record["gt_classes"].astype(int) == class_idx]

    if len(boxes) == 0:
        return np.zeros((0, 12), dtype=np.float32), np.zeros((0, 4), dtype=np.float32)

    widths = np.maximum(boxes[:, 2] - boxes[:, 0], 0)
    heights = np.maximum(boxes[:, 3] - boxes[:, 1], 0)
    areas = widths * heights
    min_sides = np.minimum(widths, heights)
    max_sides = np.maximum(widths, heights)
    aspect = max_sides / np.maximum(min_sides, 1e-6)
    source_flag = np.ones(len(boxes), dtype=np.float32) if source == "tile" else np.zeros(len(boxes), dtype=np.float32)

    overlaps_other = SGAT.iou_matrix(boxes, other_boxes)
    if overlaps_other.size:
        best_other_idx = overlaps_other.argmax(axis=1)
        best_other_iou = overlaps_other[np.arange(len(boxes)), best_other_idx]
        best_other_score = other_scores[best_other_idx]
        agreement = (overlaps_other >= 0.3).sum(axis=1)
    else:
        best_other_iou = np.zeros(len(boxes), dtype=np.float32)
        best_other_score = np.zeros(len(boxes), dtype=np.float32)
        agreement = np.zeros(len(boxes), dtype=np.float32)

    features = np.stack(
        [
            scores,
            source_flag,
            np.log1p(areas) / np.log(640.0 * 640.0),
            np.log1p(np.minimum(aspect, 100.0)) / np.log(101.0),
            min_sides / 640.0,
            max_sides / 640.0,
            best_other_score,
            best_other_iou,
            agreement / 5.0,
            source_flag * best_other_score,
            source_flag * best_other_iou,
            np.ones(len(boxes), dtype=np.float32),
        ],
        axis=1,
    ).astype(np.float32)

    if len(gt_boxes) == 0:
        targets = np.zeros((len(boxes), 4), dtype=np.float32)
        return features, targets
    overlaps_gt = SGAT.iou_matrix(boxes, gt_boxes)
    best_gt = overlaps_gt.max(axis=1)
    targets = np.stack(
        [
            (best_gt >= 0.5).astype(np.float32),
            (best_gt >= 0.75).astype(np.float32),
            best_gt,
            np.ones(len(boxes), dtype=np.float32),
        ],
        axis=1,
    ).astype(np.float32)
    return features, targets


def fit_calibrators(
    records: list[dict],
    names: dict[int, str],
    min_positives: int = 8,
) -> tuple[dict[int, tuple[StandardScaler, LogisticRegression] | None], dict]:
    calibrators = {}
    diagnostics = {}
    for class_idx in sorted(names):
        features = []
        targets = []
        for record in records:
            for source in ("global", "tile"):
                x, y = candidate_features(record, class_idx, source)
                if len(x):
                    features.append(x)
                    targets.append(y[:, 0])
        if not features:
            calibrators[class_idx] = None
            diagnostics[names[class_idx]] = {"fallback": "global", "reason": "no candidates"}
            continue
        x = np.concatenate(features, axis=0)
        y = np.concatenate(targets, axis=0)
        positives = int(y.sum())
        if positives < min_positives:
            calibrators[class_idx] = None
            diagnostics[names[class_idx]] = {"fallback": "global", "reason": "few positives", "positives": positives}
            continue
        scaler = StandardScaler()
        x_scaled = scaler.fit_transform(x)
        model = LogisticRegression(
            class_weight="balanced",
            max_iter=500,
            solver="lbfgs",
            random_state=42,
        )
        model.fit(x_scaled, y)
        probability = model.predict_proba(x_scaled)[:, 1]
        calibrators[class_idx] = (scaler, model)
        diagnostics[names[class_idx]] = {
            "fallback": None,
            "positives": positives,
            "candidates": int(len(y)),
            "auc": float(roc_auc_score(y, probability)) if len(np.unique(y)) > 1 else None,
        }
    return calibrators, diagnostics


def calibrated_detection(
    record: dict,
    calibrators: dict[int, tuple[StandardScaler, LogisticRegression] | None],
    fallback_expert: dict[int, str],
):
    detections = []
    for class_idx, calibrator in calibrators.items():
        if calibrator is None:
            source = fallback_expert.get(class_idx, "global")
            boxes, scores, classes = record[source]
            keep = classes.astype(int) == class_idx
            if np.any(keep):
                detections.append((boxes[keep], scores[keep], classes[keep]))
            continue
        candidate_boxes = []
        candidate_scores = []
        for source in ("global", "tile"):
            boxes, scores, classes = record[source]
            keep = classes.astype(int) == class_idx
            boxes = boxes[keep]
            if len(boxes) == 0:
                continue
            features, _targets = candidate_features(record, class_idx, source)
            scaler, model = calibrator
            calibrated = model.predict_proba(scaler.transform(features))[:, 1].astype(np.float32)
            candidate_boxes.append(boxes)
            candidate_scores.append(calibrated)
        if not candidate_boxes:
            continue
        boxes = np.concatenate(candidate_boxes, axis=0)
        scores = np.concatenate(candidate_scores, axis=0)
        classes = np.full(len(boxes), class_idx, dtype=np.float32)
        detections.append((boxes, scores, classes))
    return SGAT.merge_detections(detections, 0.55)


def sacf_metrics(
    records: list[dict],
    names: dict[int, str],
    calibrators: dict,
    fallback_expert: dict[int, str],
) -> dict:
    stats = []
    for record in records:
        boxes, scores, classes = calibrated_detection(record, calibrators, fallback_expert)
        stats.append(
            {
                "tp": SGAT.match_tp(boxes, scores, classes, record["gt_boxes"], record["gt_classes"]),
                "target_cls": record["gt_classes"],
                "target_img": np.unique(record["gt_classes"]),
                "im_name": record["name"],
                "conf": scores if len(scores) else np.zeros(0),
                "pred_cls": classes if len(classes) else np.zeros(0),
            }
        )
    return SGAT.metrics_for(stats, names)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True)
    parser.add_argument("--weights", required=True)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--conf", type=float, default=0.01)
    parser.add_argument("--iou", type=float, default=0.7)
    parser.add_argument("--max-det", type=int, default=400)
    parser.add_argument("--tile-size", type=int, default=448)
    parser.add_argument("--overlap", type=float, default=0.5)
    parser.add_argument("--calib-limit", type=int, default=0)
    parser.add_argument("--test-limit", type=int, default=0)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    started = time.perf_counter()
    data_path, data_yaml = dataset_paths(args.data)
    names = class_names(data_yaml)
    weights = (ROOT / args.weights).resolve() if not Path(args.weights).is_absolute() else Path(args.weights)
    model = YOLO(str(weights))

    val_images = sorted(
        path
        for path in SGAT.split_dir(data_path, data_yaml, "val").iterdir()
        if path.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp"}
    )
    test_images = sorted(
        path
        for path in SGAT.split_dir(data_path, data_yaml, "test").iterdir()
        if path.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp"}
    )
    if args.calib_limit:
        val_images = val_images[: args.calib_limit]
    if args.test_limit:
        test_images = test_images[: args.test_limit]
    val_labels = SGAT.label_dir(SGAT.split_dir(data_path, data_yaml, "val"))
    test_labels = SGAT.label_dir(SGAT.split_dir(data_path, data_yaml, "test"))

    t0 = time.perf_counter()
    val_records = collect_detections(
        model,
        val_images,
        val_labels,
        args.tile_size,
        args.overlap,
        args.imgsz,
        args.conf,
        args.iou,
        args.max_det,
    )
    calib_sec = time.perf_counter() - t0
    calibrators, diagnostics = fit_calibrators(val_records, names)
    fallback_expert = {}
    for class_idx, calibrator in calibrators.items():
        if calibrator is not None:
            continue
        global_metric = expert_metrics(val_records, names, "global")["per_class"][names[class_idx]]["AP50_95"]
        tile_metric = expert_metrics(val_records, names, "tile")["per_class"][names[class_idx]]["AP50_95"]
        fallback_expert[class_idx] = "tile" if tile_metric > global_metric else "global"
        diagnostics[names[class_idx]]["global_AP50_95"] = global_metric
        diagnostics[names[class_idx]]["tile_AP50_95"] = tile_metric
        diagnostics[names[class_idx]]["selected"] = fallback_expert[class_idx]

    t1 = time.perf_counter()
    test_records = collect_detections(
        model,
        test_images,
        test_labels,
        args.tile_size,
        args.overlap,
        args.imgsz,
        args.conf,
        args.iou,
        args.max_det,
    )
    test_sec = time.perf_counter() - t1

    results = {
        "data": str(data_path),
        "weights": str(weights),
        "tile_size": args.tile_size,
        "overlap": args.overlap,
        "calibration_images": len(val_images),
        "test_images": len(test_images),
        "calibration_seconds": calib_sec,
        "test_seconds": test_sec,
        "total_seconds": time.perf_counter() - started,
        "calibrator": diagnostics,
        "val": {
            "global": expert_metrics(val_records, names, "global"),
            "tile": expert_metrics(val_records, names, "tile"),
            "union": union_metrics(val_records, names, args.iou),
            "sacf": sacf_metrics(val_records, names, calibrators, fallback_expert),
        },
        "test": {
            "global": expert_metrics(test_records, names, "global"),
            "tile": expert_metrics(test_records, names, "tile"),
            "union": union_metrics(test_records, names, args.iou),
            "sacf": sacf_metrics(test_records, names, calibrators, fallback_expert),
        },
    }
    out_path = (ROOT / args.out).resolve() if not Path(args.out).is_absolute() else Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(results["test"], indent=2, ensure_ascii=False))
    print(f"[OK] {out_path}")


if __name__ == "__main__":
    main()
