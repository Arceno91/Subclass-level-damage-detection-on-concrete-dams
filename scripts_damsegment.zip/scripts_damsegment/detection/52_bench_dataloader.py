# -*- coding: utf-8 -*-
"""52_bench_dataloader.py — 诊断 dataloader 吞吐：骨架掩膜是否拖慢每轮耗时

背景：9/9 的基线（yolo11n, DamCrack-Sub5, batch16, workers=0）为 55.6 s/轮，
9/15 的同类训练变成 119 s/轮。怀疑 dataset.py 的 skeleton_dir 自动探测
（datasets/DamCrack-Sub5/skeleton/train/ 存在）导致每个样本每轮都要读一张 PNG 掩膜，
即使本次训练 skeleton_aux=0（根本不用掩膜）。

用法：python 52_bench_dataloader.py [--samples 200]
"""
import argparse
import sys
import time
from pathlib import Path

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ultralytics.cfg import get_cfg  # noqa: E402
from ultralytics.data.dataset import YOLODataset  # noqa: E402


def make_ds(augment=True):
    return YOLODataset(
        img_path=str(ROOT / "datasets/DamCrack-Sub5/images/train"),
        imgsz=640, cache=False, augment=augment, hyp=get_cfg(), prefix="  ",
        rect=False, batch_size=16, stride=32, pad=0.0 if augment else 0.5,
        single_cls=False, classes=None, fraction=1.0,
        data={"path": str(ROOT / "datasets/DamCrack-Sub5"),
              "names": {i: n for i, n in enumerate(
                  ["crack_fine", "crack_network", "crack_blocky", "spalling_small", "spalling_large"])},
              "channels": 3},
        task="detect",
    )


def bench(ds, n, tag):
    t0 = time.perf_counter()
    for i in range(n):
        _ = ds[i % len(ds)]
    dt = time.perf_counter() - t0
    print(f"[bench] {tag}: {n} 样本 {dt:.1f}s -> {dt / n * 1000:.1f} ms/样本", flush=True)
    return dt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--samples", type=int, default=200)
    args = ap.parse_args()

    ds = make_ds(augment=True)
    print(f"[bench] skeleton_dir 自动探测 = {ds.skeleton_dir}")
    s0 = ds[0]
    print(f"[bench] 样本键: {sorted(s0.keys())}, semantic_mask={'semantic_mask' in s0}")

    t_with = bench(ds, args.samples, "带骨架掩膜（当前行为）")

    ds.skeleton_dir = None
    t_without = bench(ds, args.samples, "不读骨架掩膜")

    print(f"\n[bench] 比值 = {t_with / max(t_without, 1e-9):.2f}x "
          f"（每 3902 幅训练集的额外开销 ≈ {(t_with - t_without) / args.samples * 3902:.0f}s/轮）")


if __name__ == "__main__":
    main()
