# -*- coding: utf-8 -*-
"""50_afternoon_queue.py — 2026-09-15 下午 GPU 队列（硬停止 17:40，18:00 交还机器）

排期原则：按论文三支柱"当前最缺的先跑"
  支柱一 方法贡献  : M1 DACW（难度加权，β=1/β=2）、M3 DBJT（域平衡联合训练）、M2 DAAA（难度标注分配）
  支柱二 第二数据集: DSI-Det-2cls / DSI-Det-5cls 的 yolo11n 基线
  支柱三 方法对比  : yolov10n（排在最后，超出截止就自动跳过）

时间控制：
  * 每步开始前估算耗时，若 now + est 已超过 hard_stop - margin 则整步跳过（不启动必然被杀的实验）
  * 每步运行中若越过 hard_stop，驱动直接 kill 子进程并终止队列
  * 每一步结束都把状态写入 runs/queue_logs/queue_status.json 与 QUEUE_STATUS.md（被强杀也不丢信息）

用法：python 50_afternoon_queue.py [--hard-stop 17:40] [--only dsi2,dsi5,M1,M3,M2,yolov10n2]
"""
import argparse
import json
import os
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
PY = r"E:\Arceno\hj\envs\yolov11\python.exe"
CTRL = ROOT / "scripts" / "damsegment" / "detection"
LOGS = ROOT / "runs" / "queue_logs"
DSI_RUNS = ROOT / "runs" / "e15_dsi"
DATA5 = ROOT / "datasets" / "DamCrack-Sub5" / "data.yaml"

# 沙箱内 multiprocessing 命名管道被拒（WinError 5），标签缓存改走串行回退（见 ultralytics/data/dataset.py::_label_pool）
CHILD_ENV = {**os.environ, "YOLO_SERIAL_LABEL_CACHE": "1"}

TRAIN_CODE = (
    "import json,sys;from ultralytics import YOLO;"
    "kw=json.loads(sys.argv[1]);m=kw.pop('model');YOLO(m).train(**kw)"
)
EVAL_CODE = (
    "import json,sys;from ultralytics import YOLO;"
    "kw=json.loads(sys.argv[1]);out=kw.pop('out');w=kw.pop('weights');r=YOLO(w).val(**kw);"
    "ap=r.box.all_ap;"
    "apc=[float(x) for x in ap.mean(1)] if (ap is not None and getattr(ap,'ndim',0)==2) else [];"
    "rec={'mAP50_95':round(float(r.box.map),4),'mAP50':round(float(r.box.map50),4),"
    "'mAP75':round(float(r.box.map75),4),'per_class':apc};"
    "open(out,'w',encoding='utf-8').write(json.dumps(rec,ensure_ascii=False,indent=2));"
    "print('EVAL_RESULT '+json.dumps(rec))"
)


def hhmm(s):
    h, m = (int(x) for x in s.split(":"))
    now = datetime.now()
    return now.replace(hour=h, minute=m, second=0, microsecond=0)


def train_cmd(kw):
    return [PY, "-u", "-c", TRAIN_CODE, json.dumps(kw)]


def eval_cmd(kw):
    return [PY, "-u", "-c", EVAL_CODE, json.dumps(kw)]


def ul_step(name, est, model, data, project, run_name, extra=None, eval_split="test", workers=0):
    """一个 ultralytics 训练 + 评估步骤。"""
    kw = dict(
        model=str(model), data=str(data), epochs=80, batch=16, imgsz=640, workers=workers, device="0",
        seed=42, deterministic=True, project=str(project), name=run_name, exist_ok=True,
        cache=False, plots=False, close_mosaic=10, cls_remap=True,
    )
    if extra:
        kw.update(extra)
    weights = project / run_name / "weights" / "best.pt"
    metrics = project / f"{run_name}_metrics.json"
    cmds = [train_cmd(kw)]
    if eval_split:
        ekw = dict(
            weights=str(weights), data=str(data), split=eval_split, imgsz=640, batch=16,
            workers=0, device="0", project=str(project), name=f"eval_{run_name}",
            exist_ok=True, verbose=False, out=str(metrics),
        )
        cmds.append(eval_cmd(ekw))
    return {"name": name, "est": est, "cmds": cmds, "metrics": str(metrics)}


def script_step(name, est, script, args):
    """一个"调用现成脚本"的步骤（如 49_method_experiments.py）。"""
    return {"name": name, "est": est,
            "cmds": [[PY, "-u", str(script)] + list(args)], "metrics": None}


def build_steps(workers=0):
    dsi = ROOT / "datasets"
    w = ["--workers", str(workers)]
    steps = [
        ul_step("dsi2", 0.85, ROOT / "yolo11n.pt", dsi / "DSI-Det-2cls" / "data.yaml",
                DSI_RUNS, "dsi2_yolo11n", workers=workers),
        ul_step("dsi5", 0.85, ROOT / "yolo11n.pt", dsi / "DSI-Det-5cls" / "data.yaml",
                DSI_RUNS, "dsi5_yolo11n", workers=workers),
        script_step("M1", 2.70, CTRL / "49_method_experiments.py", ["--only", "M1"] + w),
        script_step("M3", 1.50, CTRL / "49_method_experiments.py", ["--only", "M3"] + w),
        script_step("M2", 0.55, CTRL / "49_method_experiments.py", ["--only", "M2"] + w),
        ul_step("yolov10n2", 1.90, ROOT / "yolov10n.pt", DATA5,
                ROOT / "runs" / "e14_detectors", "yolov10n", workers=workers),
    ]
    return steps


def dump_status(steps, status, hard_stop, note="", label=""):
    LOGS.mkdir(parents=True, exist_ok=True)
    rec = {"generated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "hard_stop": hard_stop.strftime("%H:%M"),
           "note": note, "steps": status}
    (LOGS / f"queue_status{label}.json").write_text(json.dumps(rec, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = [f"# 下午队列状态（更新于 {rec['generated']}，硬停止 {rec['hard_stop']}）", ""]
    if note:
        lines += [note, ""]
    lines += ["| 步骤 | 内容 | 预估 | 状态 | 起止 | 结果 mAP50-95 |", "|---|---|---|---|---|---|"]
    desc = {
        "dsi2": "DSI 二分类基线（yolo11n，80ep）",
        "dsi5": "DSI 五分类基线（yolo11n，80ep）",
        "M1": "方法 M1 DACW 难度加权 β=1/β=2",
        "M3": "方法 M3 DBJT 域平衡联合训练",
        "M2": "方法 M2 DAAA 难度标注分配（预算25幅）",
        "yolov10n2": "对比表 yolov10n（DamCrack-Sub5，80ep）",
    }
    for s in status:
        m = ""
        if s.get("metrics"):
            try:
                mm = json.loads(Path(s["metrics"]).read_text(encoding="utf-8"))
                m = f"{mm['mAP50_95'] * 100:.2f}"
            except Exception:
                m = ""
        lines.append(f"| {s['name']} | {desc.get(s['name'], '')} | {s['est']}h | {s['status']} | "
                     f"{s.get('start', '')}-{s.get('end', '')} | {m} |")
    (LOGS / f"QUEUE_STATUS{label}.md").write_text("\n".join(lines), encoding="utf-8")


def write_dsi_report():
    """把 DSI 两个基线写成论文可直接引用的表格（方法/结果落地）。"""
    rows = []
    for tag, names in (("dsi2_yolo11n", ["crack", "spalling"]),
                       ("dsi5_yolo11n", ["spot_small", "crack_linear", "spalling_area",
                                         "crack_branch", "noise_dot"])):
        p = DSI_RUNS / f"{tag}_metrics.json"
        if not p.exists():
            continue
        m = json.loads(p.read_text(encoding="utf-8"))
        rows.append((tag, names, m))
    if not rows:
        return None
    lines = ["# 第二数据集（DSI）基线结果", "",
             "数据：DSI 坝面巡检机器人图像（Buildings 2023, 13(2):285），掩膜转 YOLO 框后按形态学规则归类；",
             "类别语义由掩膜几何量（长宽比/面积/邻域数）推断，论文中需注明该对应关系为推断而非官方图例。", ""]
    for tag, names, m in rows:
        lines += [f"## {tag}（yolo11n，80 epochs，test split）", "",
                  f"- mAP50-95 = **{m['mAP50_95'] * 100:.2f}%**，mAP50 = {m['mAP50'] * 100:.2f}%，"
                  f"mAP75 = {m['mAP75'] * 100:.2f}%", "",
                  "| 类别 | AP50-95 |", "|---|---|"]
        for i, n in enumerate(names):
            v = m["per_class"][i] * 100 if i < len(m["per_class"]) else float("nan")
            lines.append(f"| {n} | {v:.2f} |")
        lines.append("")
    (ROOT / "paper" / "第二数据集.md").write_text("\n".join(lines), encoding="utf-8")
    return ROOT / "paper" / "第二数据集.md"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--hard-stop", default="17:40")
    ap.add_argument("--margin-min", type=float, default=12.0)
    ap.add_argument("--only", default="")
    ap.add_argument("--workers", type=int, default=0)
    ap.add_argument("--label", default="", help="状态文件名后缀，便于多个驱动实例各自留档")
    args = ap.parse_args()

    LOGS.mkdir(parents=True, exist_ok=True)
    (LOGS / "driver.pid").write_text(str(os.getpid()), encoding="utf-8")
    hard_stop = hhmm(args.hard_stop)

    steps = build_steps(args.workers)
    if args.only:
        keep = set(args.only.split(","))
        steps = [s for s in steps if s["name"] in keep]

    status = []
    print(f"[queue] 开始 {datetime.now():%H:%M:%S}，硬停止 {hard_stop:%H:%M}，共 {len(steps)} 步", flush=True)

    for st in steps:
        now = datetime.now()
        deadline = hard_stop - timedelta(minutes=args.margin_min)
        rec = {"name": st["name"], "est": st["est"], "status": "pending", "start": "",
               "end": "", "metrics": st["metrics"]}
        if st["metrics"] and Path(st["metrics"]).exists():
            rec["status"] = "done(已有结果)"
            status.append(rec)
            dump_status(steps, status, hard_stop, label=args.label)
            print(f"[queue] 跳过 {st['name']}：已存在结果文件", flush=True)
            continue
        if now + timedelta(hours=st["est"]) > deadline:
            rec["status"] = "skipped(时间不足)"
            status.append(rec)
            dump_status(steps, status, hard_stop, label=args.label)
            print(f"[queue] 跳过 {st['name']}：{now:%H:%M} + {st['est']}h 超过 {deadline:%H:%M}", flush=True)
            continue

        rec["status"] = "running"
        rec["start"] = now.strftime("%H:%M:%S")
        status.append(rec)
        dump_status(steps, status, hard_stop, label=args.label)
        print(f"[queue] >>> {st['name']} 开始 {rec['start']}", flush=True)

        log_path = LOGS / f"{st['name']}.log"
        killed = False
        bad_rc = None
        with log_path.open("w", encoding="utf-8", errors="replace") as f:
            for cmd in st["cmds"]:
                f.write(">>> " + " ".join(cmd[:3]) + " ...\n")
                f.flush()
                proc = subprocess.Popen(cmd, stdout=f, stderr=subprocess.STDOUT, cwd=str(ROOT), env=CHILD_ENV)
                left = (hard_stop - datetime.now()).total_seconds()
                try:
                    rc = proc.wait(timeout=max(30.0, left))
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()
                    rc = -9
                    killed = True
                f.write(f"<<< rc={rc}\n")
                f.flush()
                print(f"[queue]     cmd 结束 rc={rc} {datetime.now():%H:%M:%S}", flush=True)
                if killed:
                    break
                if rc != 0:
                    bad_rc = rc
                    break

        rec["end"] = datetime.now().strftime("%H:%M:%S")
        if killed:
            rec["status"] = "killed(越过硬停止)"
        elif bad_rc is not None:
            rec["status"] = f"failed(rc={bad_rc})"
        else:
            ok = True
            if st["metrics"]:
                ok = Path(st["metrics"]).exists()
            rec["status"] = "done" if ok else "failed(无结果文件)"
        dump_status(steps, status, hard_stop, label=args.label)
        print(f"[queue] <<< {st['name']} {rec['status']} {rec['start']}-{rec['end']}", flush=True)
        if killed:
            break

    try:
        p = write_dsi_report()
        if p:
            print(f"[queue] DSI 报告 -> {p}", flush=True)
    except Exception as exc:  # noqa: BLE001
        print(f"[queue] DSI 报告失败: {exc}", flush=True)

    dump_status(steps, status, hard_stop, note="队列自然结束（未越过硬停止则说明排期提前完成）", label=args.label)
    print(f"[queue] 队列结束 {datetime.now():%H:%M:%S}", flush=True)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
