# -*- coding: utf-8 -*-
"""53_build_dbjt_dataset.py — 单独构建 M3 的域平衡联合训练数据集（不触发训练）

用法：python 53_build_dbjt_dataset.py [--dup 3]
输出：runs/e16_method/data_balanced_AB/{images,labels,data.yaml}
"""
import argparse
import importlib.util
import sys
from pathlib import Path

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
CTRL = ROOT / "scripts" / "damsegment" / "detection"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def load_m49():
    spec = importlib.util.spec_from_file_location("m49", CTRL / "49_method_experiments.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # __name__ != "__main__"，不会执行 main()
    return mod


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dup", type=int, default=3, help="小域上采样倍数（含原图）")
    args = ap.parse_args()
    m = load_m49()
    out = m.RUNS / "data_balanced_AB"
    if (out / "images").is_dir():
        import shutil

        print(f"[DBJT] 清理旧目录 {out}")
        shutil.rmtree(out, ignore_errors=True)
    yaml_path = m.build_domain_balanced([m.BATCHES / "batchA.yaml", m.BATCHES / "batchB.yaml"], out, dup_small=args.dup)
    n = len(list((out / "images").glob("*.jpg")))
    print(f"[DBJT] 完成: {yaml_path}  共 {n} 幅")


if __name__ == "__main__":
    main()
