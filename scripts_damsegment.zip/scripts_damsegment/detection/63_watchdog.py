# -*- coding: utf-8 -*-
"""63_watchdog.py — 队列看门狗（由计划任务 DamPaperWatchdog 每 20 分钟调用）

作用：窗口内如果队列进程不在（静默死亡 / 机器休眠恢复后被杀等），自动重新拉起，
断点续训因此最多损失一个 epoch。窗口外或存在 STOP 文件时不动。

日志：runs/queue_logs/watchdog.log
"""
import ctypes
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
LOGS = ROOT / "runs/queue_logs"
LOCK = LOGS / "backlog.LOCK"
STOP = LOGS / "backlog.STOP"
WATCH_LOG = LOGS / "watchdog.log"
PY = r"E:\Arceno\hj\envs\yolov11\python.exe"
QUEUE = ROOT / "scripts/damsegment/detection/60_backlog_queue.py"
WIN_START_H = 8
WIN_HOURS = 10


def _alive(pid: int) -> bool:
    k32 = ctypes.windll.kernel32
    h = k32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
    if h:
        k32.CloseHandle(h)
        return True
    return False


def log(msg: str):
    try:
        with WATCH_LOG.open("a", encoding="utf-8") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n")
    except Exception:
        pass


def main():
    now = datetime.now()
    start = now.replace(hour=WIN_START_H, minute=0, second=0, microsecond=0)
    stop = start.replace(hour=WIN_START_H + WIN_HOURS)
    if not (start <= now < stop):
        log("窗口外，跳过")
        return
    if STOP.exists():
        log("存在 STOP 文件，跳过")
        return
    if LOCK.exists():
        try:
            pid = int(LOCK.read_text(encoding="utf-8").strip())
            if _alive(pid):
                log(f"队列存活（pid {pid}），无需动作")
                return
            log(f"LOCK 指向已退出进程 {pid}，清理陈旧锁")
            LOCK.unlink(missing_ok=True)
        except Exception as e:
            log(f"LOCK 读取异常（{e}），清理")
            try:
                LOCK.unlink(missing_ok=True)
            except Exception:
                pass
    # 拉起队列（完全脱离本进程）
    log("未发现存活队列，重新拉起")
    try:
        out = (LOGS / "watchdog_launch.log").open("a", encoding="utf-8", errors="replace")
        creationflags = 0x00000008 | 0x00000200  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        subprocess.Popen(
            [PY, str(QUEUE), "--window-start", "08:00", "--window-hours", str(WIN_HOURS)],
            cwd=str(ROOT), stdout=out, stderr=subprocess.STDOUT, creationflags=creationflags)
        log("已重新拉起队列")
    except Exception as e:
        log(f"拉起失败：{e}")


if __name__ == "__main__":
    main()
