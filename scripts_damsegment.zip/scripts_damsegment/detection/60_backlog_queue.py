# -*- coding: utf-8 -*-
"""60_backlog_queue.py — 补齐实验数据总队列（审稿意见回应版）

按优先级顺序执行（每步自带"已完成则跳过"，可随时用 STOP 文件中断）：

  1  c4_896     方法支柱正结果：训练分辨率 640→896（57_resolution_experiment.py）
  2  dacw_s123   DACW β=1/2 种子 123（49_method_experiments.py --only M1 --seed 123）
  3  dacw_s456   DACW β=1/2 种子 456
  4  daaa_s123   DAAA 非均匀分配策略 种子 123（--only M2 --seed 123）
  5  daaa_s456   DAAA 非均匀分配策略 种子 456
  6  aug_*      增强消融 6 配置 × 种子 123/456（19_full_seeds.py，12 次 80ep）
  7  det_v8n    检测器对比：yolov8n 80ep
  8  det_v10n   yolov10n 80ep
  9  det_rtd    RT-DETR-L 80ep（batch 8，最慢，排后）
  10 c3_hardx2  数据侧难度过采样 ×2（57_resolution_experiment.py --exp c3）
  11 c4_960     训练分辨率 960（加分项，最后）

中断：touch runs/queue_logs/backlog.STOP（两步之间检查，当前步会跑完）。
状态：runs/queue_logs/backlog_status.json；每步日志 backlog_<step>.log。

用法：python 60_backlog_queue.py [--only c4_896,dacw_s123,...]
"""
import argparse
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
PY = r"E:\Arceno\hj\envs\yolov11\python.exe"
CTRL = ROOT / "scripts" / "damsegment" / "detection"
LOGS = ROOT / "runs" / "queue_logs"
STOP = LOGS / "backlog.STOP"
LOCK = LOGS / "backlog.LOCK"
STATUS = LOGS / "backlog_status.json"
DATA5 = ROOT / "datasets" / "DamCrack-Sub5" / "data.yaml"

CHILD_ENV = {**os.environ, "YOLO_SERIAL_LABEL_CACHE": "1"}

# 每个步骤：(id, 耗时估计 h, 完成判定函数, [cmd 列表])
# 完成判定：返回 True 表示该步已完成可跳过


def _complete_c4(imgsz):
    csv = ROOT / "runs/e17_resolution" / f"c4_res{imgsz}" / "results.csv"
    try:
        rows = [l for l in csv.read_text(encoding="utf-8").splitlines() if l.strip()]
        return len(rows) > 1 and int(float(rows[-1].split(",")[0])) >= 80
    except Exception:
        return False


def _complete_c3():
    csv = ROOT / "runs/e17_resolution" / "c3_hardx2" / "results.csv"
    try:
        rows = [l for l in csv.read_text(encoding="utf-8").splitlines() if l.strip()]
        return len(rows) > 1 and int(float(rows[-1].split(",")[0])) >= 80
    except Exception:
        return False


def _complete_49(seed, only):
    base = ROOT / "runs/e16_method" if seed == 42 else ROOT / "runs/e16_method" / f"seed{seed}"
    tags = {"M1": ["dacw_b1", "dacw_b2"], "M2": ["daaa_frequency", "daaa_difficulty", "daaa_uniform"]}
    outs = []
    for t in tags.get(only, []):
        csv = base / t / "results.csv"
        if csv.exists():
            try:
                rows = [l for l in csv.read_text(encoding="utf-8").splitlines() if l.strip()]
                if int(float(rows[-1].split(",")[0])) >= (50 if t.startswith("daaa") else 80):
                    outs.append(True)
                else:
                    outs.append(False)
            except Exception:
                outs.append(False)
        else:
            outs.append(False)
    return bool(outs) and all(outs)


def _complete_aug(name):
    ok = 0
    for s in (123, 456):
        csv = ROOT / "runs/e8_multi" / f"{name}_s{s}" / "results.csv"
        try:
            rows = [l for l in csv.read_text(encoding="utf-8").splitlines() if l.strip()]
            if int(float(rows[-1].split(",")[0])) >= 80:
                ok += 1
        except Exception:
            pass
    return ok >= 2


def _complete_det(d, epochs=80):
    csv = ROOT / "runs/e14_detectors" / d / "results.csv"
    try:
        rows = [l for l in csv.read_text(encoding="utf-8").splitlines() if l.strip()]
        return int(float(rows[-1].split(",")[0])) >= epochs
    except Exception:
        return False


DET_TRAIN_CODE = (
    "import json,sys;from ultralytics import YOLO;"
    "kw=json.loads(sys.argv[1]);m=kw.pop('model');YOLO(m).train(**kw)"
)
DET_EVAL_CODE = (
    "import json,sys;from ultralytics import YOLO;"
    "kw=json.loads(sys.argv[1]);out=kw.pop('out');w=kw.pop('weights');r=YOLO(w).val(**kw);"
    "ap=r.box.all_ap;"
    "apc=[float(x) for x in ap.mean(1)] if (ap is not None and getattr(ap,'ndim',0)==2) else [];"
    "rec={'mAP50_95':round(float(r.box.map),4),'mAP50':round(float(r.box.map50),4),"
    "'mAP75':round(float(r.box.map75),4),'per_class':apc};"
    "open(out,'w',encoding='utf-8').write(json.dumps(rec,ensure_ascii=False,indent=2));"
    "print('EVAL_RESULT '+json.dumps(rec))"
)


def steps():
    s = []
    s.append(("c4_896", 2.5, lambda: _complete_c4(896),
              [str(CTRL / "57_resolution_experiment.py"), "--exp", "c4", "--imgsz", "896",
               "--batch", "8", "--workers", "2", "--device", "0"]))
    s.append(("dacw_s123", 2.5, lambda: _complete_49(123, "M1"),
              [str(CTRL / "49_method_experiments.py"), "--only", "M1", "--seed", "123", "--workers", "2"]))
    s.append(("dacw_s456", 2.5, lambda: _complete_49(456, "M1"),
              [str(CTRL / "49_method_experiments.py"), "--only", "M1", "--seed", "456", "--workers", "2"]))
    s.append(("daaa_s123", 0.3, lambda: _complete_49(123, "M2"),
              [str(CTRL / "49_method_experiments.py"), "--only", "M2", "--seed", "123", "--workers", "2"]))
    s.append(("daaa_s456", 0.3, lambda: _complete_49(456, "M2"),
              [str(CTRL / "49_method_experiments.py"), "--only", "M2", "--seed", "456", "--workers", "2"]))
    augs = [
        ("aug_skl05", "skeleton_aux=0.5"),
        ("aug_skl02", "skeleton_aux=0.2"),
        ("aug_cp05", "copy_paste=0.5"),
        ("aug_cpsk", "copy_paste=0.5;skeleton_aux=0.5"),
        ("aug_fullcp", "cls_pw=0.5;copy_paste=0.5;skeleton_aux=0.5"),
        ("aug_cpca", "copy_paste=0.3;copy_paste_classes=[3,4]"),
    ]
    for tag, aug in augs:
        s.append((tag, 2.5, lambda t=tag: _complete_aug(t.replace("aug_", "e7")),
                  [str(CTRL / "19_full_seeds.py"), "--seeds", "123,456", "--name", tag.replace("aug_", "e7"),
                   "--aug", aug]))
    s.append(("annot_budget", 4.5, lambda: (ROOT / "runs/e18_annot_budget/results.json").exists(),
              [str(CTRL / "62_annot_budget.py"), "--fracs", "0.10,0.25,0.50,1.00"]))
    dets = [
        ("det_v8n", "yolov8n.pt", 16, 1.5),
        ("det_v10n", "yolov10n.pt", 16, 1.5),
        # det_rtd（RT-DETR-L）已移除：论文未引用该模型，且在 4060 8GB 上约 10.5 s/it
        # （≈85 min/epoch，80ep 需 100+ 小时），每日 10h 窗口内不可完成。
    ]
    for tag, pt, batch, est in dets:
        s.append((tag, est, lambda d=tag: _complete_det(d), ("DET", tag, pt, batch)))
    s.append(("c3_hardx2", 3.0, lambda: _complete_c3(),
              [str(CTRL / "57_resolution_experiment.py"), "--exp", "c3", "--workers", "2", "--device", "0"]))
    s.append(("c4_960", 3.5, lambda: _complete_c4(960),
              [str(CTRL / "57_resolution_experiment.py"), "--exp", "c4", "--imgsz", "960",
               "--batch", "8", "--workers", "2", "--device", "0"]))
    s.append(("c4_reeval", 0.3, lambda: (ROOT / "runs/e17_resolution/reeval_done.json").exists(),
              [str(CTRL / "64_reeval_c4.py")]))
    return s


def det_eval(out, tag):
    ekw = {"weights": str(out / "weights/best.pt"), "data": str(DATA5), "split": "test", "imgsz": 640,
           "batch": 16, "workers": 2, "device": "0", "project": str(out.parent), "name": f"{tag}_test",
           "exist_ok": True, "verbose": False, "out": str(out / "test_metrics.json")}
    return subprocess.run([PY, "-c", DET_EVAL_CODE, json.dumps(ekw)], cwd=str(ROOT), env=CHILD_ENV).returncode


def run_det_step(tag, pt, batch):
    out = ROOT / "runs/e14_detectors" / tag
    out.mkdir(parents=True, exist_ok=True)
    lastp = out / "weights" / "last.pt"
    csvp = out / "results.csv"
    resume = False
    if lastp.exists() and (out / "args.yaml").exists() and csvp.exists():
        try:
            rows = [l for l in csvp.read_text(encoding="utf-8").splitlines() if l.strip()]
            if rows and int(float(rows[-1].split(",")[0])) < 80:
                resume = True
        except Exception:
            pass
    if resume:
        print(f"[DET] {tag} 从 last.pt 断点续训")
        r = subprocess.run([PY, "-c",
                            "import sys,torch;from ultralytics import YOLO;"
                            "p=sys.argv[1];ck=torch.load(p,map_location='cpu');"
                            "ck.pop('scaler',None);torch.save(ck,p);"
                            "YOLO(p).train(resume=True)",
                            str(lastp)], cwd=str(ROOT), env=CHILD_ENV)
        if r.returncode != 0:
            return r.returncode
    else:
        kw = {"model": str(ROOT / pt), "data": str(DATA5), "epochs": 80, "batch": batch, "imgsz": 640,
              "workers": 2, "seed": 42, "deterministic": True, "device": "0", "project": str(out.parent),
              "name": tag, "exist_ok": True, "cache": False, "plots": False, "close_mosaic": 10,
              "verbose": True}
        r = subprocess.run([PY, "-c", DET_TRAIN_CODE, json.dumps(kw)], cwd=str(ROOT), env=CHILD_ENV)
        if r.returncode != 0:
            return r.returncode
    return det_eval(out, tag)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="", help="逗号分隔的步骤 id 白名单")
    ap.add_argument("--dry-run", action="store_true", help="只打印计划不执行")
    ap.add_argument("--window-start", default="08:00", help="每天运行窗口起点 HH:MM")
    ap.add_argument("--window-hours", type=float, default=10.0, help="每天运行窗口时长（小时）")
    args = ap.parse_args()
    LOGS.mkdir(parents=True, exist_ok=True)
    only = {x.strip() for x in args.only.split(",") if x.strip()}

    hh, mm = (int(x) for x in args.window_start.split(":"))
    now = datetime.now()
    start_dt = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
    stop_dt = start_dt + timedelta(hours=args.window_hours)

    # 单实例锁：防止计划任务补跑与手动启动同时开两个队列
    LOCK = LOGS / "backlog.LOCK"
    if LOCK.exists():
        try:
            old_pid = int(LOCK.read_text(encoding="utf-8").strip())
            import ctypes
            k32 = ctypes.windll.kernel32
            h = k32.OpenProcess(0x1000, False, old_pid)  # PROCESS_QUERY_LIMITED_INFORMATION
            if h:
                k32.CloseHandle(h)
                print(f"[queue] 已有队列实例运行（pid {old_pid}），本次退出", flush=True)
                return
        except Exception:
            pass
    LOCK.write_text(str(os.getpid()), encoding="utf-8")
    import atexit
    atexit.register(lambda: LOCK.exists() and LOCK.unlink())
    if now < start_dt:
        wait = (start_dt - now).total_seconds()
        print(f"[queue] 未到窗口起点（{args.window_start}），等待 {wait / 60:.0f} 分钟后启动 ...", flush=True)
        time.sleep(wait)
    if datetime.now() >= stop_dt:
        print(f"[queue] 当前不在运行窗口内（{args.window_start} 起 {args.window_hours}h），本次退出",
              flush=True)
        return

    plan = [(sid, est, done, cmd) for sid, est, done, cmd in steps() if not only or sid in only]
    total_h = sum(est for _, est, _, _ in plan)
    print(f"[queue] 计划 {len(plan)} 步，预估 {total_h:.1f} h（窗口 {args.window_start} 起 "
          f"{args.window_hours}h，截止 {stop_dt:%H:%M}）", flush=True)
    if args.dry_run:
        for sid, est, done, cmd in plan:
            print(f"  {'SKIP' if done() else 'RUN '} {sid:12s} ~{est:.1f}h  {cmd}", flush=True)
        return

    status = {"started": datetime.now().isoformat(timespec="seconds"),
              "window_start": args.window_start, "window_hours": args.window_hours,
              "window_stop": stop_dt.isoformat(timespec="seconds"),
              "plan": [s[0] for s in plan], "steps": []}
    for sid, est, done, cmd in plan:
        if STOP.exists():
            print(f"[queue] 检测到 STOP 文件，中止（已完成 {len(status['steps'])} 步）", flush=True)
            status["stopped_by_file"] = True
            break
        if done():
            print(f"[queue] SKIP {sid}（已完成）", flush=True)
            status["steps"].append({"id": sid, "status": "skipped"})
            STATUS.write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")
            continue
        is_det = isinstance(cmd, tuple) and cmd and cmd[0] == "DET"
        remaining = (stop_dt - datetime.now()).total_seconds()
        need = est * 3600 + 120 if is_det else 900
        if remaining < need:
            reason = f"预估 {est}h" if is_det else "剩余不足 15 分钟"
            print(f"[queue] 剩余窗口 {remaining / 3600:.2f}h（{reason}），{sid} 推迟到下一窗口，"
                  f"尝试后续步骤", flush=True)
            status["steps"].append({"id": sid, "status": "deferred_window"})
            status["window_closed"] = True
            STATUS.write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")
            continue
        t0 = datetime.now()
        print(f"[queue] START {sid}（预估 {est:.1f}h）{t0:%H:%M:%S}", flush=True)
        status["steps"].append({"id": sid, "status": "running", "start": t0.isoformat(timespec="seconds")})
        STATUS.write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")
        log = (LOGS / f"backlog_{sid}.log").open("w", encoding="utf-8", errors="replace")
        hard = False
        stalled = False

        def _kill_tree(pid):
            try:
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                               capture_output=True, timeout=30)
            except Exception:
                try:
                    sub.kill()
                except Exception:
                    pass

        try:
            if isinstance(cmd, tuple) and cmd and cmd[0] == "DET":
                rc = run_det_step(cmd[1], cmd[2], cmd[3])
            else:
                sub = subprocess.Popen([PY, *cmd], cwd=str(ROOT), env=CHILD_ENV,
                                       stdout=log, stderr=subprocess.STDOUT)
                log_path = LOGS / f"backlog_{sid}.log"
                step_deadline = datetime.now() + timedelta(hours=est * 2 + 0.5)
                while True:
                    try:
                        rc = sub.wait(timeout=30)
                        break
                    except subprocess.TimeoutExpired:
                        if datetime.now() >= stop_dt:
                            print(f"[queue] 到达硬停时刻 {stop_dt:%H:%M}，终止 {sid}（明天断点续训）",
                                  flush=True)
                            _kill_tree(sub.pid)
                            rc = 143
                            hard = True
                            break
                        stall = None
                        if datetime.now() >= step_deadline:
                            stall = f"超过时长上限 {est * 2 + 0.5:.1f}h"
                        else:
                            try:
                                idle = time.time() - log_path.stat().st_mtime
                                if idle > 25 * 60:
                                    stall = f"日志 {idle / 60:.0f} 分钟无输出（疑卡死/休眠）"
                            except Exception:
                                pass
                        if stall:
                            print(f"[queue] {sid} {stall}，终止（明天断点续训）", flush=True)
                            _kill_tree(sub.pid)
                            rc = 124
                            stalled = True
                            break
        finally:
            log.close()
        dt = (datetime.now() - t0).total_seconds() / 3600
        status["steps"][-1].update({"status": "hard_stopped" if hard else
                                    ("stalled" if stalled else ("done" if rc == 0 else "failed")),
                                    "rc": rc,
                                    "end": datetime.now().isoformat(timespec="seconds"),
                                    "hours": round(dt, 2)})
        STATUS.write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"[queue] {'HARDSTOP' if hard else ('STALLED' if stalled else ('DONE' if rc == 0 else 'FAIL'))} "
              f"{sid} rc={rc} 用时 {dt:.2f}h", flush=True)
        if rc != 0:
            print(f"[queue] 日志: {LOGS / f'backlog_{sid}.log'}", flush=True)
        if hard:
            status["window_closed"] = True
            STATUS.write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")
            break
    status["finished"] = datetime.now().isoformat(timespec="seconds")
    STATUS.write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        LOCK.unlink(missing_ok=True)
    except Exception:
        pass
    print("[queue] 队列结束", flush=True)


if __name__ == "__main__":
    main()
