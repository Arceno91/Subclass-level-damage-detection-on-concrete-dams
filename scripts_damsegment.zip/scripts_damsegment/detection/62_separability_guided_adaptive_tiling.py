# -*- coding: utf-8 -*-
"""Separability-guided adaptive tiling (SGAT) for damage detection.

The method first runs a full-frame detector, then performs overlapping local
re-detection only for resolution-bound classes. Resolution-bound classes are
defined from training-set geometry: classes whose projected minimum side is
small or whose median aspect ratio is high are treated as scale-limited.

The script evaluates the following inference strategies under one protocol:
  global        full-frame inference only
  tile_all      all local tiles, all classes
  union_all     global + all local tiles, class-aware NMS
  sgat_full     class-conditional fusion of global + all local tiles
  sgat_gated    SGAT with tile selection estimated from the global detections

Usage:
  python 62_separability_guided_adaptive_tiling.py \
      --data datasets/DamCrack-Sub5/data.yaml \
      --weights runs/e6_full/fullft_baseline/weights/best.pt \
      --tile-size 384 --overlap 0.25 --max-images 50 \
      --out runs/e17_sgat/pilot_main.json
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import torch
import yaml
from PIL import Image
from torchvision.ops import nms

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ultralytics import YOLO  # noqa: E402
from ultralytics.utils.metrics import DetMetrics  # noqa: E402

IOUV = torch.linspace(0.5, 0.95, 10)


def load_yaml(path: Path) -> dict:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def class_names(data_yaml: dict) -> dict[int, str]:
    names = data_yaml.get("names", {})
    if isinstance(names, list):
        return {i: str(name) for i, name in enumerate(names)}
    return {int(key): str(value) for key, value in names.items()}


def dataset_root(data_path: Path, data_yaml: dict) -> Path:
    root = Path(data_yaml.get("path") or data_path.parent)
    if not root.is_absolute():
        root = (ROOT / root).resolve()
    return root


def split_dir(data: Path, data_yaml: dict, split: str) -> Path:
    value = data_yaml.get(split) or data_yaml.get("val")
    path = Path(value)
    return path if path.is_absolute() else dataset_root(data, data_yaml) / path


def label_dir(images_dir: Path) -> Path:
    return images_dir.parent.parent / "labels" / images_dir.name


def load_ground_truth(label_path: Path, width: int, height: int) -> tuple[np.ndarray, np.ndarray]:
    boxes: list[list[float]] = []
    classes: list[int] = []
    if label_path.exists():
        for line in label_path.read_text(encoding="utf-8", errors="ignore").splitlines():
            parts = line.split()
            if len(parts) != 5:
                continue
            cls, cx, cy, bw, bh = int(parts[0]), *map(float, parts[1:])
            boxes.append(
                [
                    (cx - bw / 2) * width,
                    (cy - bh / 2) * height,
                    (cx + bw / 2) * width,
                    (cy + bh / 2) * height,
                ]
            )
            classes.append(cls)
    return np.asarray(boxes, dtype=np.float32), np.asarray(classes, dtype=np.int64)


def find_target_classes(
    data_yaml: dict,
    train_images: Path,
    max_samples: int = 0,
    min_side_threshold: float = 24.0,
    aspect_threshold: float = 2.5,
) -> tuple[list[int], dict[str, dict[str, float]]]:
    labels = label_dir(train_images)
    image_files = sorted(train_images.glob("*"))
    if max_samples:
        image_files = image_files[:max_samples]
    stats: dict[int, dict[str, list[float]]] = {}
    for image_path in image_files:
        with Image.open(image_path) as image:
            width, height = image.size
        label_path = labels / f"{image_path.stem}.txt"
        if not label_path.exists():
            continue
        scale = min(640.0 / width, 640.0 / height)
        for line in label_path.read_text(encoding="utf-8", errors="ignore").splitlines():
            parts = line.split()
            if len(parts) != 5:
                continue
            cls, _cx, _cy, bw, bh = int(parts[0]), *map(float, parts[1:])
            width_px = bw * width * scale
            height_px = bh * height * scale
            min_side = min(width_px, height_px)
            aspect = max(width_px, height_px) / max(min_side, 1e-6)
            record = stats.setdefault(cls, {"min_side": [], "aspect": []})
            record["min_side"].append(min_side)
            record["aspect"].append(aspect)
    summary: dict[str, dict[str, float]] = {}
    target: list[int] = []
    names = class_names(data_yaml)
    for cls, values in sorted(stats.items()):
        median_min_side = float(np.median(values["min_side"]))
        median_aspect = float(np.median(values["aspect"]))
        summary[names[cls]] = {
            "median_min_side_px": median_min_side,
            "median_aspect_ratio": median_aspect,
            "instances": float(len(values["min_side"])),
        }
        if median_min_side <= min_side_threshold or median_aspect >= aspect_threshold:
            target.append(cls)
    return target, summary


def tile_grid(width: int, height: int, tile_size: int, overlap: float) -> list[tuple[int, int, int, int]]:
    tile_size = max(32, min(tile_size, width, height))
    stride = max(1, int(round(tile_size * (1.0 - overlap))))

    def positions(length: int) -> list[int]:
        if length <= tile_size:
            return [0]
        starts = list(range(0, length - tile_size + 1, stride))
        if starts[-1] != length - tile_size:
            starts.append(length - tile_size)
        return starts

    return [(x, y, x + tile_size, y + tile_size) for y in positions(height) for x in positions(width)]


def iou_matrix(boxes_a: np.ndarray, boxes_b: np.ndarray) -> np.ndarray:
    if len(boxes_a) == 0 or len(boxes_b) == 0:
        return np.zeros((len(boxes_a), len(boxes_b)), dtype=np.float32)
    a = torch.as_tensor(boxes_a, dtype=torch.float32)
    b = torch.as_tensor(boxes_b, dtype=torch.float32)
    lt = torch.maximum(a[:, None, :2], b[None, :, :2])
    rb = torch.minimum(a[:, None, 2:], b[None, :, 2:])
    wh = (rb - lt).clamp(min=0)
    inter = wh[..., 0] * wh[..., 1]
    area_a = (a[:, 2] - a[:, 0]).clamp(min=0) * (a[:, 3] - a[:, 1]).clamp(min=0)
    area_b = (b[:, 2] - b[:, 0]).clamp(min=0) * (b[:, 3] - b[:, 1]).clamp(min=0)
    return (inter / (area_a[:, None] + area_b[None, :] - inter).clamp(min=1e-6)).numpy()


def class_nms(
    boxes: np.ndarray,
    scores: np.ndarray,
    classes: np.ndarray,
    iou_threshold: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    keep: list[int] = []
    for cls in np.unique(classes):
        idx = np.flatnonzero(classes == cls)
        if len(idx) == 0:
            continue
        kept = nms(
            torch.as_tensor(boxes[idx], dtype=torch.float32),
            torch.as_tensor(scores[idx], dtype=torch.float32),
            iou_threshold,
        ).numpy()
        keep.extend(idx[kept].tolist())
    if not keep:
        return (
            np.zeros((0, 4), dtype=np.float32),
            np.zeros((0,), dtype=np.float32),
            np.zeros((0,), dtype=np.float32),
        )
    keep_arr = np.asarray(sorted(keep), dtype=np.int64)
    return boxes[keep_arr], scores[keep_arr], classes[keep_arr]


def merge_detections(detections: list[tuple[np.ndarray, np.ndarray, np.ndarray]], iou_threshold: float):
    if not detections:
        return (
            np.zeros((0, 4), dtype=np.float32),
            np.zeros((0,), dtype=np.float32),
            np.zeros((0,), dtype=np.float32),
        )
    boxes = np.concatenate([item[0] for item in detections if len(item[0])], axis=0)
    scores = np.concatenate([item[1] for item in detections if len(item[1])], axis=0)
    classes = np.concatenate([item[2] for item in detections if len(item[2])], axis=0)
    return class_nms(boxes, scores, classes, iou_threshold)


def predict_arrays(model: YOLO, images: list[np.ndarray], imgsz: int, conf: float, iou: float, max_det: int):
    if not images:
        return []
    results = model.predict(
        source=images,
        imgsz=imgsz,
        conf=conf,
        iou=iou,
        max_det=max_det,
        verbose=False,
        device="cpu",
    )
    outputs = []
    for result in results:
        if result.boxes is None or len(result.boxes) == 0:
            outputs.append(
                (
                    np.zeros((0, 4), dtype=np.float32),
                    np.zeros((0,), dtype=np.float32),
                    np.zeros((0,), dtype=np.float32),
                )
            )
            continue
        outputs.append(
            (
                result.boxes.xyxy.cpu().numpy().astype(np.float32),
                result.boxes.conf.cpu().numpy().astype(np.float32),
                result.boxes.cls.cpu().numpy().astype(np.float32),
            )
        )
    return outputs


def infer_tiles(
    model: YOLO,
    image: np.ndarray,
    tiles: list[tuple[int, int, int, int]],
    imgsz: int,
    conf: float,
    iou: float,
    max_det: int,
    batch_size: int = 16,
):
    if not tiles:
        return (
            np.zeros((0, 4), dtype=np.float32),
            np.zeros((0,), dtype=np.float32),
            np.zeros((0,), dtype=np.float32),
        ), 0.0
    crops = [image[y1:y2, x1:x2] for x1, y1, x2, y2 in tiles]
    started = time.perf_counter()
    predictions: list[tuple[np.ndarray, np.ndarray, np.ndarray]] = []
    for start in range(0, len(crops), batch_size):
        predictions.extend(predict_arrays(model, crops[start : start + batch_size], imgsz, conf, iou, max_det))
    elapsed = time.perf_counter() - started
    detections: list[tuple[np.ndarray, np.ndarray, np.ndarray]] = []
    for tile, prediction in zip(tiles, predictions):
        x1, y1, _x2, _y2 = tile
        boxes, scores, classes = prediction
        if len(boxes):
            boxes = boxes + np.asarray([x1, y1, x1, y1], dtype=np.float32)
        detections.append((boxes, scores, classes))
    boxes, scores, classes = merge_detections(detections, iou)
    return (boxes, scores, classes), elapsed


def tile_trigger_tiles(
    global_boxes: np.ndarray,
    global_scores: np.ndarray,
    global_classes: np.ndarray,
    tiles: list[tuple[int, int, int, int]],
    target_classes: list[int],
    confidence_threshold: float = 0.35,
    min_side_threshold: float = 32.0,
    max_tiles_per_box: int = 4,
) -> list[tuple[int, int, int, int]]:
    if not target_classes:
        return tiles
    target_mask = np.isin(global_classes.astype(int), target_classes)
    if not np.any(target_mask):
        return tiles
    selected: set[tuple[int, int, int, int]] = set()
    target_idx = np.flatnonzero(target_mask)
    for idx in target_idx:
        box = global_boxes[idx]
        side = min(float(box[2] - box[0]), float(box[3] - box[1]))
        aspect = max(float(box[2] - box[0]), float(box[3] - box[1])) / max(side, 1e-6)
        if global_scores[idx] >= confidence_threshold and side >= min_side_threshold and aspect < 2.5:
            continue
        overlaps = iou_matrix(np.asarray([box]), np.asarray(tiles, dtype=np.float32))[0]
        candidates = np.argsort(-overlaps)
        added = 0
        for tile_idx in candidates:
            if overlaps[tile_idx] <= 1e-6:
                break
            selected.add(tiles[int(tile_idx)])
            added += 1
            if added >= max_tiles_per_box:
                break
    return sorted(selected)


def fuse_separability(
    global_det,
    tile_det,
    target_classes: list[int],
    overlap_threshold: float = 0.3,
    nms_threshold: float = 0.55,
):
    global_boxes, global_scores, global_classes = global_det
    tile_boxes, tile_scores, tile_classes = tile_det
    target_mask_g = np.isin(global_classes.astype(int), target_classes)
    target_mask_t = np.isin(tile_classes.astype(int), target_classes)
    detections = [
        (global_boxes[~target_mask_g], global_scores[~target_mask_g], global_classes[~target_mask_g]),
        (tile_boxes[target_mask_t], tile_scores[target_mask_t], tile_classes[target_mask_t]),
    ]
    if np.any(target_mask_g) and np.any(target_mask_t):
        overlaps = iou_matrix(global_boxes[target_mask_g], tile_boxes[target_mask_t])
        same_class = (
            global_classes[target_mask_g][:, None].astype(int)
            == tile_classes[target_mask_t][None, :].astype(int)
        )
        suppressed = np.any((overlaps >= overlap_threshold) & same_class, axis=1)
        detections.append(
            (
                global_boxes[target_mask_g][~suppressed],
                global_scores[target_mask_g][~suppressed],
                global_classes[target_mask_g][~suppressed],
            )
        )
    elif np.any(target_mask_g):
        detections.append(
            (
                global_boxes[target_mask_g],
                global_scores[target_mask_g],
                global_classes[target_mask_g],
            )
        )
    return merge_detections(detections, nms_threshold)


def match_tp(
    pred_boxes: np.ndarray,
    pred_scores: np.ndarray,
    pred_classes: np.ndarray,
    gt_boxes: np.ndarray,
    gt_classes: np.ndarray,
) -> np.ndarray:
    tp = np.zeros((len(pred_boxes), len(IOUV)), dtype=bool)
    if len(pred_boxes) == 0 or len(gt_boxes) == 0:
        return tp
    iou = iou_matrix(pred_boxes, gt_boxes)
    order = np.argsort(-pred_scores)
    used_gt: set[int] = set()
    for pred_idx in order:
        candidates = [
            gt_idx
            for gt_idx in range(len(gt_boxes))
            if gt_idx not in used_gt
            and int(pred_classes[pred_idx]) == int(gt_classes[gt_idx])
            and iou[pred_idx, gt_idx] >= 0.5
        ]
        if not candidates:
            continue
        gt_idx = max(candidates, key=lambda value: iou[pred_idx, value])
        used_gt.add(gt_idx)
        for level, threshold in enumerate(IOUV.tolist()):
            if iou[pred_idx, gt_idx] >= threshold:
                tp[pred_idx, level] = True
    return tp


def metrics_for(stats: list[dict], names: dict[int, str]) -> dict:
    metrics = DetMetrics(names=names)
    for stat in stats:
        metrics.update_stats(stat)
    metrics.process()
    per_class = {}
    for i, class_idx in enumerate(metrics.box.ap_class_index):
        per_class[names[int(class_idx)]] = {
            "AP50_95": float(metrics.box.ap[i]),
            "AP50": float(metrics.box.ap50[i]),
        }
    return {
        "mAP50_95": float(metrics.box.map),
        "mAP50": float(metrics.box.map50),
        "per_class": per_class,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True)
    parser.add_argument("--weights", required=True)
    parser.add_argument("--split", default="test")
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--conf", type=float, default=0.01)
    parser.add_argument("--iou", type=float, default=0.7)
    parser.add_argument("--max-det", type=int, default=500)
    parser.add_argument("--tile-size", type=int, default=384)
    parser.add_argument("--overlap", type=float, default=0.25)
    parser.add_argument("--target-classes", default="")
    parser.add_argument("--max-images", type=int, default=0)
    parser.add_argument("--global-only", action="store_true")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    data_path = (ROOT / args.data).resolve() if not Path(args.data).is_absolute() else Path(args.data)
    data_yaml = load_yaml(data_path)
    names = class_names(data_yaml)
    images_dir = split_dir(data_path, data_yaml, args.split)
    labels = label_dir(images_dir)
    image_files = sorted(
        path for path in images_dir.iterdir() if path.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp"}
    )
    if args.max_images:
        image_files = image_files[: args.max_images]
    weights = (ROOT / args.weights).resolve() if not Path(args.weights).is_absolute() else Path(args.weights)

    train_images = split_dir(data_path, data_yaml, "train")
    if args.target_classes:
        target_classes = [int(value) for value in args.target_classes.split(",") if value.strip()]
        geometry = {}
    else:
        target_classes, geometry = find_target_classes(data_yaml, train_images)

    model = YOLO(str(weights))
    method_stats = {method: [] for method in ("global", "tile_all", "union_all", "sgat_full", "sgat_gated")}
    timing = {"global_sec": 0.0, "tiles_full_sec": 0.0, "tiles_gated_sec": 0.0}
    tile_counts = {"full": [], "gated": []}
    started = time.perf_counter()
    for image_index, image_path in enumerate(image_files, start=1):
        image = cv2.imread(str(image_path))
        if image is None:
            continue
        height, width = image.shape[:2]
        gt_boxes, gt_classes = load_ground_truth(labels / f"{image_path.stem}.txt", width, height)

        t0 = time.perf_counter()
        global_det = predict_arrays(model, [image], args.imgsz, args.conf, args.iou, args.max_det)[0]
        timing["global_sec"] += time.perf_counter() - t0

        if args.global_only:
            tile_det = (
                np.zeros((0, 4), dtype=np.float32),
                np.zeros((0,), dtype=np.float32),
                np.zeros((0,), dtype=np.float32),
            )
            gated_det = tile_det
        else:
            tiles = tile_grid(width, height, args.tile_size, args.overlap)
            tile_det, tile_elapsed = infer_tiles(
                model,
                image,
                tiles,
                args.imgsz,
                args.conf,
                args.iou,
                args.max_det,
            )
            timing["tiles_full_sec"] += tile_elapsed
            tile_counts["full"].append(len(tiles))

            gated_tiles = tile_trigger_tiles(
                global_det[0],
                global_det[1],
                global_det[2],
                tiles,
                target_classes,
            )
            tile_counts["gated"].append(len(gated_tiles))
            gated_det, gated_elapsed = infer_tiles(
                model,
                image,
                gated_tiles,
                args.imgsz,
                args.conf,
                args.iou,
                args.max_det,
            )
            timing["tiles_gated_sec"] += gated_elapsed

        method_detections = {
            "global": global_det,
            "tile_all": tile_det,
            "union_all": merge_detections([global_det, tile_det], args.iou),
            "sgat_full": fuse_separability(global_det, tile_det, target_classes),
            "sgat_gated": fuse_separability(global_det, gated_det, target_classes),
        }
        for method, (boxes, scores, classes) in method_detections.items():
            tp = match_tp(boxes, scores, classes, gt_boxes, gt_classes)
            method_stats[method].append(
                {
                    "tp": tp,
                    "target_cls": gt_classes,
                    "target_img": np.unique(gt_classes),
                    "im_name": image_path.name,
                    "conf": scores if len(scores) else np.zeros(0),
                    "pred_cls": classes if len(classes) else np.zeros(0),
                }
            )
        if image_index % 20 == 0:
            print(f"[{image_index}/{len(image_files)}] {image_path.name}", flush=True)

    results = {
        "data": str(data_path),
        "weights": str(weights),
        "split": args.split,
        "n_images": len(image_files),
        "imgsz": args.imgsz,
        "conf": args.conf,
        "iou": args.iou,
        "tile_size": args.tile_size,
        "overlap": args.overlap,
        "target_classes": {names[class_idx]: class_idx for class_idx in target_classes},
        "geometry": geometry,
        "methods": {method: metrics_for(stats, names) for method, stats in method_stats.items()},
        "timing": {
            **timing,
            "total_sec": time.perf_counter() - started,
            "full_tiles_per_image": float(np.mean(tile_counts["full"])) if tile_counts["full"] else 0.0,
            "gated_tiles_per_image": float(np.mean(tile_counts["gated"])) if tile_counts["gated"] else 0.0,
        },
    }
    out_path = (ROOT / args.out).resolve() if not Path(args.out).is_absolute() else Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(results, indent=2, ensure_ascii=False))
    print(f"[OK] {out_path}")


if __name__ == "__main__":
    main()
