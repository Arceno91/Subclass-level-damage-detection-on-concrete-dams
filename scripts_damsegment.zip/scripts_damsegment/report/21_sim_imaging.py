# -*- coding: utf-8 -*-
"""21_sim_imaging.py — 巡检成像条件仿真（工程评估章节素材）

思路：对 DamCrack-Sub5 test 集施加可控的退化（模拟无人机巡检的高度/GSD、运动模糊、
光照、图传压缩），用已训练基线模型评估，得到「检出率-成像条件」曲线，给出巡检作业建议。

退化族（单因素扫描，标签保持不变）：
  GSD/分辨率 : 缩放比 s ∈ {1.0, 0.75, 0.5, 0.35, 0.25}  → 下采样再上采样（细节损失）
  运动模糊   : 核长 k ∈ {0, 3, 7, 11} px（45° 方向）
  光照       : gamma ∈ {1.0, 0.7, 1.4}（暗/正常/亮）+ 低对比 alpha=0.7
  图传压缩   : JPEG 质量 ∈ {95, 75, 50, 30}

输出：runs/sim_imaging/{results.json, fig_sim_imaging.png} + 每个条件的 val 目录
用法：python 21_sim_imaging.py [--device cpu]
"""
import argparse
import json
import shutil
import sys
from pathlib import Path

import cv2
import numpy as np

YOLO_PEFT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(YOLO_PEFT) not in sys.path:
    sys.path.insert(0, str(YOLO_PEFT))

from ultralytics import YOLO  # noqa: E402

DATA = YOLO_PEFT / "datasets/DamCrack-Sub5"
MODEL = YOLO_PEFT / "runs/e6_full/fullft_baseline/weights/best.pt"
OUT = YOLO_PEFT / "runs/sim_imaging"
NAMES = {0: "crack_fine", 1: "crack_network", 2: "crack_blocky", 3: "spalling_small", 4: "spalling_large"}


def deg_gsd(img, s):
    if s >= 1.0:
        return img
    h, w = img.shape[:2]
    small = cv2.resize(img, (max(8, int(w * s)), max(8, int(h * s))), interpolation=cv2.INTER_AREA)
    return cv2.resize(small, (w, h), interpolation=cv2.INTER_LINEAR)


def deg_blur(img, k):
    if k <= 0:
        return img
    kernel = np.zeros((k, k), dtype=np.float32)
    cv2.line(kernel, (0, 0), (k - 1, k - 1), 1.0, 1)
    kernel /= kernel.sum()
    return cv2.filter2D(img, -1, kernel)


def deg_gamma(img, g, alpha=1.0):
    out = img.astype(np.float32) / 255.0
    if g != 1.0:
        out = np.power(out, g)
    if alpha != 1.0:
        mean = out.mean()
        out = (out - mean) * alpha + mean
    return np.clip(out * 255.0, 0, 255).astype(np.uint8)


def deg_jpeg(img, q):
    ok, enc = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), q])
    return cv2.imdecode(enc, cv2.IMREAD_COLOR) if ok else img


CONDITIONS = []
for s in (1.0, 0.75, 0.5, 0.35, 0.25):
    CONDITIONS.append((f"gsd_s{s}", "GSD/分辨率", f"{s}x", lambda im, s=s: deg_gsd(im, s)))
for k in (0, 3, 7, 11):
    CONDITIONS.append((f"blur_k{k}", "运动模糊", f"{k}px", lambda im, k=k: deg_blur(im, k)))
for g in (1.0, 0.7, 1.4):
    CONDITIONS.append((f"gamma_{g}", "光照", f"γ={g}", lambda im, g=g: deg_gamma(im, g)))
CONDITIONS.append(("contrast_0.7", "光照", "对比度×0.7", lambda im: deg_gamma(im, 1.0, 0.7)))
for q in (95, 75, 50, 30):
    CONDITIONS.append((f"jpeg_q{q}", "图传压缩", f"JPEG q={q}", lambda im, q=q: deg_jpeg(im, q)))


def build_condition_dir(tag, fn):
    cdir = OUT / tag
    img_out, lbl_out = cdir / "images", cdir / "labels"
    if img_out.exists():
        shutil.rmtree(cdir)
    img_out.mkdir(parents=True, exist_ok=True)
    lbl_out.mkdir(parents=True, exist_ok=True)
    for src in sorted((DATA / "images/test").glob("*.jpg")):
        im = cv2.imread(str(src))
        if im is None:
            continue
        cv2.imwrite(str(img_out / src.name), fn(im))
        shutil.copy2(DATA / "labels/test" / f"{src.stem}.txt", lbl_out / f"{src.stem}.txt")
    (cdir / "data.yaml").write_text(
        f"path: {cdir.as_posix()}\ntrain: images\nval: images\n\nnc: 5\nnames:\n"
        + "".join(f"  {c}: {NAMES[c]}\n" for c in range(5)),
        encoding="utf-8",
    )
    return cdir / "data.yaml"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="cpu")
    args = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    model = YOLO(str(MODEL))
    results = []
    for tag, family, level, fn in CONDITIONS:
        print(f"[sim] {tag} ({family} {level}) ...", flush=True)
        yaml = build_condition_dir(tag, fn)
        r = model.val(data=str(yaml), split="val", imgsz=640, batch=16, workers=0,
                      device=args.device, project=str(OUT), name=f"{tag}_val", exist_ok=True, verbose=False)
        pc = {NAMES[c]: float(r.box.ap[c]) for c in range(5)}
        rec = {"tag": tag, "family": family, "level": level,
               "mAP50_95": float(r.box.map), "mAP50": float(r.box.map50),
               "precision": float(r.box.mp), "recall": float(r.box.mr), "per_class": pc}
        results.append(rec)
        with (OUT / "results.json").open("w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        print(f"[sim]   mAP50-95={rec['mAP50_95']*100:.2f}%  mAP50={rec['mAP50']*100:.2f}%", flush=True)
    print("\n===== 成像条件仿真汇总 (test mAP50-95 %) =====")
    for r in results:
        print(f"  {r['family']:<12} {r['level']:<14} {r['mAP50_95']*100:6.2f}%   (mAP50 {r['mAP50']*100:6.2f}%)")


if __name__ == "__main__":
    main()
