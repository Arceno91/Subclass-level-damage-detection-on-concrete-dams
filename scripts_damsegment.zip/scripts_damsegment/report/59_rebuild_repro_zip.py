# -*- coding: utf-8 -*-
"""59_rebuild_repro_zip.py — 重建复现包 zip（补齐审稿意见第 6 条缺项）

新增相对旧包的内容：
  results_json/       全部实验结果 JSON（metrics_suite / e16_method / e15_dsi / e12 / e6_kshot /
                      e10_inc / e11_novel_probe / e13_zoo / e14_detectors / sim_imaging /
                      threshold_tuning / e8_multi / e17_resolution / separability）
  derived_labels/     DamCrack-Sub5 与 DSI-Det-2cls/5cls 的衍生标签 + data.yaml + 划分清单
  scripts_damsegment/ 全部实验脚本（含 49_method_experiments.py 的 DACW/DAAA/DBJT，
                      53_build_dbjt_dataset.py，57_resolution_experiment.py，19_full_seeds.py，
                      60_backlog_queue.py，58_separability_analysis.py 等）

用法：python 59_rebuild_repro_zip.py
输出：submission_ajse/reproducibility_package.zip（旧包备份为 *.bak_<日期>）
"""
import json
import shutil
import zipfile
from datetime import datetime
from pathlib import Path

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
OUT_ZIP = ROOT / "submission_ajse" / "reproducibility_package.zip"
REPRO = ROOT / "submission_ajse" / "06_reproducibility"
STAGE = ROOT / "submission_ajse" / "build" / "repro_stage"

# 需要收集的结果 JSON（相对 ROOT；若不存在则跳过）
RESULT_JSONS = [
    "runs/metrics_suite/metrics.json",
    "runs/metrics_suite/suite_20260915.json",
    "runs/e16_method/results.json",
    "runs/e16_method/seed123/results.json",
    "runs/e16_method/seed456/results.json",
    "runs/e15_dsi/dsi2_yolo11n_metrics.json",
    "runs/e15_dsi/dsi5_yolo11n_metrics.json",
    "runs/e12_cross_batch/results.json",
    "runs/e6_kshot/kshot_results.json",
    "runs/e6_kshot/diag_results.json",
    "runs/e10_inc/incremental_results.json",
    "runs/e11_novel_probe/probe_results.json",
    "runs/e13_zoo/detector_zoo.json",
    "runs/sim_imaging/results.json",
    "runs/sim_imaging/remedy_results.json",
    "runs/sim_imaging/remedy_validator.json",
    "runs/sim_imaging/remedy_clean.json",
    "runs/e14_detectors/det_v8n/test_metrics.json",
    "runs/e14_detectors/det_v10n/test_metrics.json",
    "runs/e17_resolution/reeval_done.json",
    "runs/threshold_tuning/results.json",
    "runs/e8_multi/results_multi.json",
    "runs/e17_resolution/results.json",
    "runs/e18_annot_budget/results.json",
    "runs/e18_annot_budget/learning_curve.csv",
    "runs/separability/results.json",
    "runs/separability/per_class_stats.csv",
    "runs/queue_logs/backlog_status.json",
]

# 衍生标签目录（整体收进 derived_labels/<名字>/）
LABEL_DIRS = [
    ("DamCrack-Sub5", "datasets/DamCrack-Sub5"),
    ("DSI-Det-2cls", "datasets/DSI-Det-2cls"),
    ("DSI-Det-5cls", "datasets/DSI-Det-5cls"),
    ("DamCrack-Batches", "datasets/DamCrack-Batches"),
]


def add_labels(dst: Path, src: Path):
    """只收 labels/、data.yaml、清单与统计文件，不收图像（任意层级的 images 目录都排除）。"""
    shutil.copytree(src, dst, ignore=shutil.ignore_patterns("images", "__pycache__", "*.cache", "skeleton"), dirs_exist_ok=True)


def main():
    if STAGE.exists():
        shutil.rmtree(STAGE)
    STAGE.mkdir(parents=True)

    # 1) source + data_manifest + weights_and_samples（沿用现有 06_reproducibility 内容）
    for sub in ("source", "data_manifest", "weights_and_samples"):
        src = REPRO / sub
        if src.exists():
            shutil.copytree(src, STAGE / sub)

    # 2) results_json/
    rj = STAGE / "results_json"
    rj.mkdir()
    n = 0
    for rel in RESULT_JSONS:
        p = ROOT / rel
        if p.exists():
            dst = rj / rel.replace("/", "__")
            shutil.copy2(p, dst)
            n += 1
    print(f"[1/4] results_json: {n}/{len(RESULT_JSONS)} 个文件")

    # 3) derived_labels/
    dl = STAGE / "derived_labels"
    dl.mkdir()
    for name, rel in LABEL_DIRS:
        src = ROOT / rel
        if src.exists():
            add_labels(dl / name, src)
    print("[2/4] derived_labels 完成")

    # 4) scripts_damsegment/
    sd = ROOT / "scripts" / "damsegment"
    if sd.exists():
        shutil.copytree(sd, STAGE / "scripts_damsegment",
                        ignore=shutil.ignore_patterns("__pycache__"))
    print("[3/4] scripts_damsegment 完成")

    # 5) README + LICENSE
    readme = (REPRO / "README.md").read_text(encoding="utf-8")
    if "results_json/" not in readme:
        readme = readme.replace(
            "## Contents\n\n",
            "## Contents\n\n"
            "- `results_json/` -- all experiment result JSONs cited by the paper's tables "
            "(baseline seeds, method experiments DACW/DAAA/DBJT including seed 123/456 repeats when present, "
            "DSI metrics, cross-batch, K-shot, incremental, imaging simulation, threshold tuning, "
            "detector zoo and the separability analysis).\n"
            "- `derived_labels/` -- the derived DamCrack-Sub5, DSI-Det-2cls/5cls and DamCrack-Batches "
            "labels, split manifests and data YAMLs (images are downloaded from the cited sources).\n"
            "- `scripts_damsegment/` -- the full experiment pipeline, including the training scripts for "
            "DACW/DAAA/DBJT (`detection/49_method_experiments.py`, supports `--seed`), the "
            "domain-balancing builder (`detection/53_build_dbjt_dataset.py`), the resolution/oversampling "
            "experiments (`detection/57_resolution_experiment.py`), the multi-seed runner "
            "(`detection/19_full_seeds.py`) and the backlog queue driver (`detection/60_backlog_queue.py`).\n",
        )
        readme = readme.replace(
            "## Generation commands\n\n```bash\n",
            "## Method-experiment commands (DACW / DAAA / DBJT)\n\n"
            "```bash\n"
            "python scripts_damsegment/detection/49_method_experiments.py --only M1 --seed 42 --workers 2\n"
            "python scripts_damsegment/detection/49_method_experiments.py --only M2 --seed 42 --workers 2\n"
            "python scripts_damsegment/detection/49_method_experiments.py --only M3 --workers 2\n"
            "```\n\n"
            "## Generation commands\n\n```bash\n",
        )
    (STAGE / "README.md").write_text(readme, encoding="utf-8")
    shutil.copy2(REPRO / "LICENSE_DATA.md", STAGE / "LICENSE_DATA.md")
    print("[4/4] README 更新完成")

    # 打包（备份旧包）
    if OUT_ZIP.exists():
        bak = OUT_ZIP.with_name(f"{OUT_ZIP.stem}.bak_{datetime.now():%Y%m%d_%H%M}.zip")
        shutil.copy2(OUT_ZIP, bak)
        print(f"[zip] 旧包备份 -> {bak.name}")
    with zipfile.ZipFile(OUT_ZIP, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(STAGE.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(STAGE).as_posix())
    mb = OUT_ZIP.stat().st_size / 1e6
    print(f"[zip] -> {OUT_ZIP} ({mb:.1f} MB)")


if __name__ == "__main__":
    main()
