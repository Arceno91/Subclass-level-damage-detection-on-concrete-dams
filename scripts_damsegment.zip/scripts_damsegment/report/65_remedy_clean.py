# -*- coding: utf-8 -*-
"""65_remedy_clean.py — 推理侧补救实验（统一标准流水线重跑）

背景：旧的 remedy_results.json 使用自写 mAP 流水线，与 Table 7 的标准 val() 结果
不一致（direct 21.53 vs 26.84），且 remedy_validator.json 无脚本可考。
本脚本用 ultralytics 标准 val() 在**同一模型、同一退化数据**上重测：

  A. direct   : imgsz=640,   augment=False
  B. upscale  : imgsz=1280,  augment=False
  C. up + TTA : imgsz=1280,  augment=True

条件：clean（干净 test）、gsd_s0.35、blur_k7，另加 clean@640+TTA（正文 +0.30 说法）。

输出：runs/sim_imaging/remedy_clean.json
"""
import json
import sys
from pathlib import Path

import torch

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ultralytics import YOLO  # noqa: E402

OUT = ROOT / "runs/sim_imaging"
MODEL = ROOT / "runs/e6_full/fullft_baseline/weights/best.pt"
DATA5 = ROOT / "datasets/DamCrack-Sub5"

CONDITIONS = {
    "clean": (DATA5, "test"),
    "gsd_s0.35": (OUT / "gsd_s0.35", "val"),
    "blur_k7": (OUT / "blur_k7", "val"),
}
VARIANTS = [
    ("A_direct640", 640, False),
    ("B_up1280", 1280, False),
    ("C_up1280_tta", 1280, True),
    ("D_direct640_tta", 640, True),  # 仅 clean 条件需要（+0.30 说法）
]


def main():
    model = YOLO(str(MODEL))
    results = []
    for cond, (data_dir, split) in CONDITIONS.items():
        yaml = (data_dir / "data.yaml") if cond != "clean" else (DATA5 / "data.yaml")
        for name, imgsz, tta in VARIANTS:
            if cond != "clean" and name == "D_direct640_tta":
                continue
            batch = 16 if imgsz == 640 else 8
            r = model.val(data=str(yaml), split=split, imgsz=imgsz, batch=batch, workers=2,
                          device="0", augment=tta, project=str(OUT), name=f"remedy_clean_{cond}_{name}",
                          exist_ok=True, verbose=False)
            ap = r.box.all_ap
            per = [float(x) for x in ap.mean(1)] if try_ndim(ap) else []
            rec = {"condition": cond, "variant": name, "imgsz": imgsz, "tta": bool(tta),
                   "mAP50_95": float(r.box.map), "mAP50": float(r.box.map50),
                   "crack_fine_AP": per[0] if per else None}
            results.append(rec)
            print(f"[65] {cond:10s} {name:16s} mAP={rec['mAP50_95']*100:5.2f} "
                  f"cf={rec['crack_fine_AP']*100 if rec['crack_fine_AP'] else 0:5.2f}", flush=True)
            torch.cuda.empty_cache()
    (OUT / "remedy_clean.json").write_text(json.dumps(results, ensure_ascii=False, indent=2),
                                           encoding="utf-8")
    print("[65] done -> runs/sim_imaging/remedy_clean.json", flush=True)


def try_ndim(ap):
    try:
        return ap is not None and ap.ndim == 2
    except Exception:
        return False


if __name__ == "__main__":
    main()
