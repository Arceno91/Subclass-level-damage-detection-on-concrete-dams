# -*- coding: utf-8 -*-
"""24_remedy_experiment.py — 仿真→补救闭环：成像退化下的推理策略对比（工程章）

背景：成像条件仿真显示 GSD 0.35x / 模糊 7px 时细长裂缝检出崩塌（26.84% / 16.54%）。
问题：工程上"分辨率不足/模糊"能否通过推理策略补救？
对比（同一退化数据、同一模型）：
  A. direct640   基线推理（imgsz=640）
  B. up1280      提高推理分辨率（imgsz=1280）
  C. tta1280     imgsz=1280 + TTA（augment=True）
  D. slice       放大 1.5x（960）后 640 窗口切片推理（overlap 0.25）+ NMS（SAHI 式）

输出：runs/sim_imaging/remedy_results.json + 控制台对比表
用法：python 24_remedy_experiment.py --device 0
"""
import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import torch

YOLO_PEFT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(YOLO_PEFT) not in sys.path:
    sys.path.insert(0, str(YOLO_PEFT))

from ultralytics import YOLO  # noqa: E402
from ultralytics.utils.metrics import DetMetrics  # noqa: E402

OUT = YOLO_PEFT / "runs/sim_imaging"
MODEL = YOLO_PEFT / "runs/e6_full/fullft_baseline/weights/best.pt"
CONDS = ["gsd_s0.35", "blur_k7"]
NAMES = {0: "crack_fine", 1: "crack_network", 2: "crack_blocky", 3: "spalling_small", 4: "spalling_large"}
IOUV = np.linspace(0.5, 0.95, 10)
CONF, IOU_TH = 0.001, 0.7
WIN, OVERLAP, SCALE = 640, 0.25, 1.5


def load_gt(lbl_path, w, h):
    boxes, cls = [], []
    if lbl_path.exists():
        for ln in lbl_path.read_text(encoding="utf-8").splitlines():
            p = ln.split()
            if len(p) != 5:
                continue
            c, cx, cy, bw, bh = int(p[0]), *map(float, p[1:])
            boxes.append([(cx - bw / 2) * w, (cy - bh / 2) * h, (cx + bw / 2) * w, (cy + bh / 2) * h])
            cls.append(c)
    return np.array(boxes, dtype=np.float32).reshape(-1, 4), np.array(cls, dtype=np.int64)


def match_tp(pb, pc, pcls, gb, gcls):
    tp = np.zeros((len(pb), 10), dtype=bool)
    if len(pb) == 0 or len(gb) == 0:
        return tp
    from ultralytics.utils.metrics import box_iou
    iou = box_iou(torch.tensor(pb), torch.tensor(gb)).numpy()
    used = set()
    for p in np.argsort(-pc):
        cand = [g for g in range(len(gb)) if gcls[g] == pcls[p] and g not in used and iou[p, g] >= 0.5]
        if not cand:
            continue
        g = max(cand, key=lambda g: iou[p, g])
        used.add(g)
        for i, th in enumerate(IOUV):
            if iou[p, g] >= th:
                tp[p, i] = True
    return tp


def eval_stats(all_stats):
    dm = DetMetrics(names=NAMES)
    for st in all_stats:
        dm.update_stats(st)
    dm.process()
    pc = {}
    for i, idx in enumerate(dm.box.ap_class_index):
        pc[NAMES[int(idx)]] = {"ap": float(dm.box.ap[i]), "ap50": float(dm.box.ap50[i])}
    return {"mAP50_95": float(dm.box.map), "mAP50": float(dm.box.map50), "per_class": pc}


def infer_direct(model, img, imgsz, device):
    r = model.predict(source=img, imgsz=imgsz, conf=CONF, iou=IOU_TH, device=device, verbose=False)[0]
    if r.boxes is None or len(r.boxes) == 0:
        return np.zeros((0, 4)), np.zeros((0,)), np.zeros((0,), dtype=int)
    return r.boxes.xyxy.cpu().numpy(), r.boxes.conf.cpu().numpy(), r.boxes.cls.cpu().numpy().astype(int)


def infer_slice(model, img, device):
    """放大 SCALE 倍 → 640 窗口（overlap 0.25）切片推理 → 坐标映射 + NMS 合并（SAHI 式）"""
    H, W = img.shape[:2]
    big = cv2.resize(img, (int(W * SCALE), int(H * SCALE)), interpolation=cv2.INTER_CUBIC)
    H2, W2 = big.shape[:2]
    w = min(WIN, W2)
    stride = max(1, int(w * (1 - OVERLAP)))
    xs = list(range(0, max(1, W2 - w + 1), stride)) or [0]
    ys = list(range(0, max(1, H2 - w + 1), stride)) or [0]
    if W2 > w and (W2 - w) % stride != 0:
        xs.append(W2 - w)
    if H2 > w and (H2 - w) % stride != 0:
        ys.append(H2 - w)
    boxes, confs, clss = [], [], []
    for y0 in ys:
        for x0 in xs:
            win = big[y0 : y0 + w, x0 : x0 + w]
            b, c, k = infer_direct(model, win, w, device)
            if len(b) == 0:
                continue
            boxes.append(b + np.array([x0, y0, x0, y0]))
            confs.append(c)
            clss.append(k)
    if not boxes:
        return np.zeros((0, 4)), np.zeros((0,)), np.zeros((0,), dtype=int)
    boxes, confs, clss = np.concatenate(boxes), np.concatenate(confs), np.concatenate(clss)
    keep = _nms(boxes, confs, IOU_TH)
    boxes, confs, clss = boxes[keep], confs[keep], clss[keep]
    boxes = boxes / SCALE  # 映射回原尺寸
    return boxes, confs, clss


def _nms(boxes, confs, iou_th):
    """NMS：优先 torchvision.ops，退回 cv2.dnn.NMSBoxes（本环境 torch.ops.torchvision 不可用）"""
    try:
        import torchvision  # noqa: F401

        return torchvision.ops.nms(
            torch.tensor(boxes, dtype=torch.float32), torch.tensor(confs, dtype=torch.float32), iou_th
        ).numpy()
    except Exception:
        b = boxes.astype(np.float32)  # xyxy
        rects = [[float(b[i, 0]), float(b[i, 1]), float(b[i, 2] - b[i, 0]), float(b[i, 3] - b[i, 1])] for i in range(len(b))]
        idx = cv2.dnn.NMSBoxes(rects, confs.astype(float).tolist(), float(conf_th_low(confs)), float(iou_th))
        return np.array(idx).reshape(-1).astype(int) if len(idx) else np.zeros(0, dtype=int)


def conf_th_low(confs):
    return float(np.min(confs)) if len(confs) else 0.0


def main():
    global CONDS
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="0")
    ap.add_argument("--conds", default=",".join(CONDS), help="逗号分隔的退化条件名")
    ap.add_argument("--limit", type=int, default=0, help="每个条件只用前 N 张（smoke 用）")
    args = ap.parse_args()
    CONDS = [c.strip() for c in args.conds.split(",") if c.strip()]
    print(f"[remedy] 条件={CONDS} limit={args.limit} device={args.device}", flush=True)
    model = YOLO(str(MODEL))
    print("[remedy] 模型加载完成", flush=True)
    variants = {
        "A_direct640": lambda m, im: infer_direct(m, im, 640, args.device),
        "B_up1280": lambda m, im: infer_direct(m, im, 1280, args.device),
        "C_tta1280": lambda m, im: infer_direct(m, im, 1280, args.device),  # TTA 由 predict augment 控制
        "D_slice": lambda m, im: infer_slice(m, im, args.device),
    }
    results = []
    for cond in CONDS:
        cdir = OUT / cond
        img_dir, lbl_dir = cdir / "images", cdir / "labels"
        if not img_dir.is_dir():
            print(f"[skip] {cond} 缺少退化图像目录")
            continue
        imgs = sorted(img_dir.glob("*.jpg"))
        if args.limit:
            imgs = imgs[: args.limit]
        for vname, fn in variants.items():
            print(f"[remedy] {cond} {vname} 开始（{len(imgs)} 张）", flush=True)
            stats = []
            for ii, ip in enumerate(imgs):
                im = cv2.imread(str(ip))
                if im is None:
                    continue
                h, w = im.shape[:2]
                gb, gcls = load_gt(lbl_dir / f"{ip.stem}.txt", w, h)
                if vname == "C_tta1280":
                    r = model.predict(source=im, imgsz=1280, conf=CONF, iou=IOU_TH, augment=True,
                                      device=args.device, verbose=False)[0]
                    pb = r.boxes.xyxy.cpu().numpy() if r.boxes is not None and len(r.boxes) else np.zeros((0, 4))
                    pc = r.boxes.conf.cpu().numpy() if r.boxes is not None and len(r.boxes) else np.zeros((0,))
                    pk = r.boxes.cls.cpu().numpy().astype(int) if r.boxes is not None and len(r.boxes) else np.zeros((0,), dtype=int)
                else:
                    pb, pc, pk = fn(model, im)
                stats.append({
                    "tp": match_tp(pb, pc, pk, gb, gcls),
                    "conf": pc,
                    "pred_cls": pk,
                    "target_cls": gcls,
                    "target_img": np.full(len(gcls), ii, dtype=np.int64),
                    "im_name": ip.name,
                })
            m = eval_stats(stats)
            rec = {"condition": cond, "variant": vname, **m}
            results.append(rec)
            print(f"[remedy] {cond} {vname}: mAP50-95={m['mAP50_95']*100:.2f}%  "
                  f"crack_fine={m['per_class'].get('crack_fine', {}).get('ap', 0)*100:.2f}%", flush=True)
            with (OUT / "remedy_results.json").open("w", encoding="utf-8") as f:
                json.dump(results, f, ensure_ascii=False, indent=2)
    print("\n===== 补救策略对比汇总 =====")
    for r in results:
        print(f"  {r['condition']:<12} {r['variant']:<12} mAP50-95={r['mAP50_95']*100:6.2f}%")


if __name__ == "__main__":
    main()
