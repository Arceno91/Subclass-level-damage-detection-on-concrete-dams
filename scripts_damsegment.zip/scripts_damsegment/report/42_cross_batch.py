# -*- coding: utf-8 -*-
"""42_cross_batch.py — 跨采集批次泛化实验（表8：跨批次泛化的替代方案）

背景：真·跨数据集（DamSegment 3500 幅）需联网下载且当前环境无网络；
本地 datasets/DamSegment 实为 DamCrack 的 E/H/M 批次（已并入训练集），直接用会造成泄漏。
因此本实验以「采集批次」作为域划分：
  A 批 4000 幅（A1–A4000，官方 Detection 子集）  vs  B 批 1500 幅（E/H/M，早期批次，同坝体）
协议：在源批次训练集上训练，分别在「源批次测试集（域内）」与「目标批次测试集（跨批次）」评估。

用法：python 42_cross_batch.py --device 0
输出：runs/e12_cross_batch/{results.json, fig_cross_batch.png} + paper/跨批次泛化.md
"""
import argparse
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ultralytics import YOLO  # noqa: E402

BATCHES = ROOT / "datasets/DamCrack-Batches"
RUNS = ROOT / "runs/e12_cross_batch"
PT = ROOT / "yolo11n.pt"
NAMES = ["crack_fine", "crack_network", "crack_blocky", "spalling_small", "spalling_large"]


def train_batch(model_name, data_yaml, device, epochs=80):
    out = RUNS / model_name
    if (out / "weights/best.pt").exists():
        print(f"[{model_name}] 已存在，跳过训练")
        return out / "weights/best.pt"
    m = YOLO(str(PT))
    imgsz_warm = 640
    m.train(data=str(data_yaml), epochs=epochs, batch=16, imgsz=imgsz_warm, workers=2, seed=42,
            device=device, project=str(RUNS), name=model_name, exist_ok=True, cache=False,
            plots=False, close_mosaic=10, verbose=True)
    return out / "weights/best.pt"


def evaluate(tag, weights, data_yaml, split, device):
    m = YOLO(str(weights))
    r = m.val(data=str(data_yaml), split=split, imgsz=640, batch=16, workers=0, device=device,
              project=str(RUNS), name=f"eval_{tag}", exist_ok=True, verbose=False)
    ap = np.asarray(r.box.all_ap)
    rec = {"tag": tag, "data": data_yaml.name, "split": split,
           "mAP50_95": float(r.box.map), "mAP50": float(r.box.map50), "AP75": float(ap[:, 5].mean()),
           "per_class": {NAMES[i]: float(ap.mean(1)[i]) for i in range(5)}}
    print(f"[eval] {tag}: mAP50-95={rec['mAP50_95']*100:.2f}% mAP50={rec['mAP50']*100:.2f}% "
          f"AP75={rec['AP75']*100:.2f}%", flush=True)
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="0")
    ap.add_argument("--epochs", type=int, default=80)
    args = ap.parse_args()
    RUNS.mkdir(parents=True, exist_ok=True)

    jobs = [
        ("modelA_onBatchA", BATCHES / "batchA.yaml",
         [(BATCHES / "batchA.yaml", "test", "域内(A→A)"), (BATCHES / "batchB.yaml", "test", "跨批次(A→B)")]),
        ("modelB_onBatchB", BATCHES / "batchB.yaml",
         [(BATCHES / "batchB.yaml", "test", "域内(B→B)"), (BATCHES / "batchA.yaml", "test", "跨批次(B→A)")]),
    ]
    results = []
    for name, train_yaml, evals in jobs:
        print(f"\n===== 训练 {name}（数据 {train_yaml.name}）=====", flush=True)
        pt = train_batch(name, train_yaml, args.device, args.epochs)
        for data_yaml, split, tag in evals:
            results.append(evaluate(f"{name}_{tag}", pt, data_yaml, split, args.device))
        (RUNS / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")

    # ---- 汇总表 ----
    lines = ["# 表 8 跨采集批次泛化（YOLO11n，80 epoch，种子 42）", "",
             "> 说明：真·跨数据集（不同坝体）数据需联网获取，本文以「同坝体不同采集批次」作为域划分的替代验证：",
             "> A 批 = 官方 Detection 子集 4000 幅；B 批 = 早期批次 1500 幅（E/H/M 命名）。两批图像不重叠。", "",
             "| 训练批次 | 评估集 | 类型 | mAP50-95 | mAP50 | AP75 | 相对域内下降 |",
             "|---|---|---|---|---|---|---|"]
    in_domain = {}
    for r in results:
        if r["tag"].endswith("域内(A→A)") or r["tag"].endswith("域内(B→B)"):
            in_domain[r["tag"].split("_")[0]] = r["mAP50_95"]
    for r in results:
        key = r["tag"].split("_")[0]
        base = in_domain.get(key)
        drop = f"-{(base - r['mAP50_95']) * 100:.2f}pt" if base and "跨批次" in r["tag"] else "—"
        lines.append(f"| {r['tag'].split('_')[1]} | {r['data']} | {r['tag'].split('_')[-1]} | "
                     f"{r['mAP50_95']*100:.2f} | {r['mAP50']*100:.2f} | {r['AP75']*100:.2f} | {drop} |")
    (ROOT / "paper/跨批次泛化.md").write_text("\n".join(lines), encoding="utf-8")

    # ---- 图 ----
    plt.rcParams.update({"figure.dpi": 300, "savefig.dpi": 300, "font.size": 9.5, "axes.grid": True,
                         "grid.alpha": 0.3, "font.sans-serif": ["Microsoft YaHei", "SimHei"],
                         "axes.unicode_minus": False})
    labels = [r["tag"].split("_", 1)[1] for r in results]
    vals = [r["mAP50_95"] * 100 for r in results]
    colors = ["#4C72B0" if "域内" in l else "#C44E52" for l in labels]
    fig, ax = plt.subplots(figsize=(7.2, 4.0))
    bars = ax.bar(labels, vals, color=colors)
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.3, f"{v:.2f}", ha="center", fontsize=9)
    ax.set_ylabel("测试集 mAP50-95 (%)")
    ax.set_ylim(0, max(vals) * 1.3)
    ax.set_title("域内 vs 跨采集批次泛化（YOLO11n；蓝=域内，红=跨批次）")
    plt.xticks(rotation=10, fontsize=8)
    fig.tight_layout()
    fig.savefig(ROOT / "paper/figures/图15_跨批次泛化.png")
    plt.close(fig)
    print("\n===== 汇总 =====")
    for r in results:
        print(f"  {r['tag']}: mAP50-95={r['mAP50_95']*100:.2f}%")


if __name__ == "__main__":
    main()
