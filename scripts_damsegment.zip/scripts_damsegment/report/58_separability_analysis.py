# -*- coding: utf-8 -*-
"""58_separability_analysis.py — 可分性与难度的定量分析（回应审稿意见第 4 条）

把论文的定性论断"难度由像素跨度、长宽比、纹理对比决定"变成可核查的数字：
  1. 对 DamCrack-Sub5 train/test 与 DSI-Det-5cls test，逐类计算：
     目标数、像素跨度（长边，px）、长宽比、面积、同类邻居数、局部对比度（内/外灰度差）
  2. 与 per-class AP 做 Spearman 相关 + OLS 回归（主数据集 n=5，合并 DSI n=10），
     输出统计量（ρ / R² / p 值）与逐类表格
输出：runs/separability/results.json + per_class_stats.csv + paper/可分性分析.md
用法：python 58_separability_analysis.py
"""
import csv
import json
import random
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scipy import stats  # noqa: E402

MAIN = ROOT / "datasets/DamCrack-Sub5"
DSI = ROOT / "datasets/DSI-Det-5cls"
OUT = ROOT / "runs/separability"
NAMES = ["crack_fine", "crack_network", "crack_blocky", "spalling_small", "spalling_large"]
DSI_NAMES = ["spot_small", "crack_linear", "spalling_area", "crack_branch", "noise_dot"]
CRACK_IDS = {0, 1, 2}
N_CONTRAST = 150
SEED = 42


def load_ap():
    """per-class AP50-95：主数据集用基线 seed42，DSI 用 dsi5 结果。"""
    m = {r["tag"]: r for r in json.loads((ROOT / "runs/metrics_suite/metrics.json").read_text(encoding="utf-8"))}
    per = m["基线 seed42"]["per_class"]
    if isinstance(per, list):
        main = {c["name"]: c["AP50_95"] * 100 for c in per}
    else:
        main = {k: v["AP50_95"] * 100 for k, v in per.items()}
    dsi = json.loads((ROOT / "runs/e15_dsi/dsi5_yolo11n_metrics.json").read_text(encoding="utf-8"))
    dsi_ap = {DSI_NAMES[i]: v * 100 for i, v in enumerate(dsi["per_class"])}
    return main, dsi_ap


def image_dims(root, split):
    """(stem -> (W,H))：DamCrack 图已确认全部 640x640，DSI 逐个读。"""
    imgs = root / "images" / split
    dims = {}
    for p in sorted(imgs.glob("*.jpg")) + sorted(imgs.glob("*.png")):
        h, w = cv2.imread(str(p), cv2.IMREAD_GRAYSCALE).shape
        dims[p.stem] = (w, h)
    return dims


def collect_boxes(root, split, crack_ids, names, dsi_flag=False):
    """逐类收集几何特征（像素跨度/长宽比/面积/同类邻居数）。"""
    dims = image_dims(root, split)
    per_class = {n: {"span": [], "ar": [], "area": [], "nbr_same": [], "nbr_crack": []} for n in names}
    img_cls = {}
    for lp in sorted((root / "labels" / split).glob("*.txt")):
        stem = lp.stem
        if stem not in dims:
            continue
        W, H = dims[stem]
        lines = [l for l in lp.read_text(encoding="utf-8").splitlines() if l.strip()]
        boxes = []
        for l in lines:
            p = l.split()
            c = int(p[0])
            x, y, w, h = [float(v) for v in p[1:5]]
            if c >= len(names):
                continue
            boxes.append((c, w * W, h * H))
        cls_of = [c for c, _, _ in boxes]
        img_cls[stem] = cls_of
        for c, bw, bh in boxes:
            n = names[c]
            span = max(bw, bh)
            ar = max(bw, bh) / (min(bw, bh) + 1e-6)
            same = sum(1 for cc in cls_of if cc == c) - 1
            nbr_crack = sum(1 for cc in cls_of if cc in crack_ids) - (1 if c in crack_ids else 0)
            per_class[n]["span"].append(span)
            per_class[n]["ar"].append(ar)
            per_class[n]["area"].append(bw * bh)
            per_class[n]["nbr_same"].append(same)
            per_class[n]["nbr_crack"].append(nbr_crack)
    return per_class, dims, img_cls


def contrast_feature(root, split, per_class, dims, img_cls, names):
    """对每类采样 N_CONTRAST 个框，计算 框内-邻域 灰度差与框内纹理(std)。"""
    rng = random.Random(SEED)
    for n in names:
        per_class[n]["contrast"] = []
        per_class[n]["texture_std"] = []
    ext_of = {p.stem: p.suffix for p in (root / "images" / split).glob("*") if p.suffix.lower() in (".jpg", ".png")}
    cache = {}
    items = sorted((root / "labels" / split).glob("*.txt"))
    rng.shuffle(items)
    quota = {n: 0 for n in names}
    done = {n: False for n in names}
    for lp in items:
        if all(done.values()):
            break
        stem = lp.stem
        if stem not in dims or stem not in img_cls or stem not in ext_of:
            continue
        lines = [l for l in lp.read_text(encoding="utf-8").splitlines() if l.strip()]
        if not lines:
            continue
        W, H = dims[stem]
        img = cache.get(stem)
        if img is None:
            g = cv2.imread(str(root / "images" / split / (stem + ext_of[stem])), cv2.IMREAD_GRAYSCALE)
            if g is None:
                continue
            img = g.astype(np.float32)
            cache[stem] = img
            if len(cache) > 40:
                cache.pop(next(iter(cache)))
        for l in lines:
            p = l.split()
            c = int(p[0])
            if c >= len(names) or done[names[c]]:
                continue
            x, y, w, h = [float(v) for v in p[1:5]]
            x1, y1 = int(round(x * W)), int(round(y * H))
            x2, y2 = int(round((x + w) * W)), int(round((y + h) * H))
            x1, y1 = max(0, x1), max(0, y1)
            x2, y2 = min(W, x2), min(H, y2)
            if x2 - x1 < 3 or y2 - y1 < 3:
                continue
            inside = img[y1:y2, x1:x2]
            pad_w, pad_h = int((x2 - x1) * 0.35), int((y2 - y1) * 0.35)
            bx1, by1 = max(0, x1 - pad_w), max(0, y1 - pad_h)
            bx2, by2 = min(W, x2 + pad_w), min(H, y2 + pad_h)
            outside = np.concatenate([
                img[by1:y1, bx1:bx2].ravel(), img[y2:by2, bx1:bx2].ravel(),
                img[y1:y2, bx1:x1].ravel(), img[y1:y2, x2:bx2].ravel(),
            ]) if bx2 > bx1 and by2 > by1 else np.array([], dtype=np.float32)
            n = names[c]
            per_class[n]["contrast"].append(float(abs(inside.mean() - outside.mean())) if outside.size else float("nan"))
            per_class[n]["texture_std"].append(float(inside.std()))
            quota[n] += 1
            if quota[n] >= N_CONTRAST:
                done[n] = True
            if all(done.values()):
                break
    return per_class


def summarize(per_class, names):
    out = {}
    for n in names:
        d = per_class[n]
        d.setdefault("contrast", [])
        d.setdefault("texture_std", [])
        stats_ = {}
        for k, arr in d.items():
            if k in ("contrast", "texture_std"):
                vals = [v for v in arr if v == v]
                stats_[k] = {"median": float(np.median(vals)) if vals else None, "n": len(vals)}
            elif k.startswith("nbr"):
                stats_[k] = {"median": float(np.median(arr)), "mean": float(np.mean(arr))}
            else:
                stats_[k] = {"median": float(np.median(arr)), "mean": float(np.mean(arr)),
                             "p90": float(np.percentile(arr, 90))}
        out[n] = {"n_instances": len(d["span"]), **stats_}
    return out


def corr_table(stats_main, stats_dsi, ap_main, ap_dsi, names, dsi_names):
    """Spearman ρ + OLS(R², p)：主数据集 n=5，合并 DSI n=10。"""
    features = ["span", "ar", "area", "contrast"]
    rows = []
    datasets = [(stats_main, ap_main, names, "DamCrack-Sub5"),
                (stats_dsi, ap_dsi, dsi_names, "DSI-5cls")]
    pooled = {f: [] for f in features}
    pooled_ap = []
    for st, ap, nms, tag in datasets:
        for n in nms:
            if st[n]["n_instances"] == 0:
                continue
            for f in features:
                v = st[n][f]["median"]
                pooled[f].append(v if v is not None else float("nan"))
            pooled_ap.append(ap[n])
    for f in features:
        xp = [v for v in pooled[f] if v == v]
        yp = [a for v, a in zip(pooled[f], pooled_ap) if v == v]
        # 单数据集
        xs, ys = [], []
        for n in names:
            v = stats_main[n][f]["median"]
            if stats_main[n]["n_instances"] and v is not None and v == v:
                xs.append(v)
                ys.append(ap_main[n])
        rho, pv = stats.spearmanr(xs, ys)
        try:
            lr = stats.linregress(xs, ys)
            r2, p_lr, slope = lr.rvalue ** 2, lr.pvalue, lr.slope
        except Exception:
            r2, p_lr, slope = float("nan"), float("nan"), float("nan")
        rho_p, pv_p = (stats.spearmanr(xp, yp) if len(xp) >= 3 else (float("nan"), float("nan")))
        try:
            lrp = stats.linregress(xp, yp)
            r2p, p_lrp, slopep = lrp.rvalue ** 2, lrp.pvalue, lrp.slope
        except Exception:
            r2p, p_lrp, slopep = float("nan"), float("nan"), float("nan")
        rows.append({
            "feature": f, "n_main": len(xs),
            "spearman_main": round(float(rho), 3), "p_main": round(float(pv), 4),
            "ols_r2_main": round(float(r2), 3), "ols_p_main": round(float(p_lr), 4),
            "ols_slope_main": round(float(slope), 4),
            "n_pooled": len(xp),
            "spearman_pooled": round(float(rho_p), 3), "p_pooled": round(float(pv_p), 4),
            "ols_r2_pooled": round(float(r2p), 3), "ols_p_pooled": round(float(p_lrp), 4),
            "ols_slope_pooled": round(float(slopep), 4),
        })
    return rows


def write_md(stats_main, stats_dsi, ap_main, ap_dsi, corr):
    L = ["# 可分性与难度定量分析（审稿意见第 4 条支撑数据）", "",
         "口径：像素跨度 = 框长边(px)；长宽比 = 长边/短边；面积 = w·h(px²)；",
         "对比度 = |框内灰度均值 − 邻域灰度均值|（每类抽样 ≤150 框，seed 42）；",
         "AP 取 DamCrack-Sub5 基线 seed42 / DSI-5cls（test，mAP@[.50:.95] 口径的逐类 AP）。", ""]
    for tag, st, ap, nms in [("DamCrack-Sub5（test）", stats_main, ap_main, NAMES),
                             ("DSI-5cls（test）", stats_dsi, ap_dsi, DSI_NAMES)]:
        L += [f"## {tag}", "",
              "| 类 | n | 中位跨度(px) | 中位长宽比 | 中位面积(px²) | 中位同类邻居 | 中位对比度 | 纹理std | AP(%) |",
              "|---|---|---|---|---|---|---|---|---|"]
        for n in nms:
            s = st[n]
            if s["n_instances"] == 0:
                continue
            L.append(f"| {n} | {s['n_instances']} | {s['span']['median']:.1f} | {s['ar']['median']:.2f} | "
                     f"{s['area']['median']:.0f} | {s['nbr_same']['median']:.1f} | "
                     f"{s['contrast']['median']:.1f} | {s['texture_std']['median']:.1f} | {ap[n]:.2f} |")
        L.append("")
    L += ["## 相关与回归（AP ~ 特征）", "",
          "| 特征 | n(主) | Spearman ρ(主) | p(主) | OLS R²(主) | OLS p(主) | n(合并) | Spearman ρ(合并) | p(合并) | OLS R²(合并) | OLS p(合并) |",
          "|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in corr:
        L.append(f"| {r['feature']} | {r['n_main']} | {r['spearman_main']} | {r['p_main']} | "
                 f"{r['ols_r2_main']} | {r['ols_p_main']} | {r['n_pooled']} | "
                 f"{r['spearman_pooled']} | {r['p_pooled']} | {r['ols_r2_pooled']} | {r['ols_p_pooled']} |")
    L += ["", "## 判读要点（可直接改写进正文 4.3 / 5.1）", "",
          "- 跨度（分辨率可分离性）：跨度越小 AP 越低 → 支持\"难度 = 像素级可分性\"机制；",
          "- 对比度（纹理可分离性）：细裂缝与背景灰度差小，剥离类对比度高；",
          "- 长宽比：细长目标（AR 极大）在 IoU 阈值下更难精确回归；",
          "- 频率：把类实例数并入同表即可展示\"频率与难度无关\"（见 图2/表5 口径）。"]
    (ROOT / "paper/可分性分析.md").write_text("\n".join(L), encoding="utf-8")


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    ap_main, ap_dsi = load_ap()
    print("[1/4] DamCrack-Sub5 test 几何统计 ...", flush=True)
    pc_main, dims_main, ic_main = collect_boxes(MAIN, "test", CRACK_IDS, NAMES)
    pc_main = contrast_feature(MAIN, "test", pc_main, dims_main, ic_main, NAMES)
    stats_main = summarize(pc_main, NAMES)
    print("[2/4] DamCrack-Sub5 train 几何统计 ...", flush=True)
    pc_tr, dims_tr, ic_tr = collect_boxes(MAIN, "train", CRACK_IDS, NAMES)
    stats_train = summarize(pc_tr, NAMES)
    print("[3/4] DSI-5cls test 几何统计 ...", flush=True)
    pc_dsi, dims_d, ic_d = collect_boxes(DSI, "test", CRACK_IDS, DSI_NAMES)
    pc_dsi = contrast_feature(DSI, "test", pc_dsi, dims_d, ic_d, DSI_NAMES)
    stats_dsi = summarize(pc_dsi, DSI_NAMES)
    print("[4/4] 相关与回归 ...", flush=True)
    corr = corr_table(stats_main, stats_dsi, ap_main, ap_dsi, NAMES, DSI_NAMES)

    (OUT / "results.json").write_text(json.dumps(
        {"ap_main": ap_main, "ap_dsi": ap_dsi, "stats_main_test": stats_main,
         "stats_main_train": stats_train, "stats_dsi_test": stats_dsi, "correlations": corr},
        ensure_ascii=False, indent=2), encoding="utf-8")

    with (OUT / "per_class_stats.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["dataset", "split", "class", "n", "median_span_px", "median_ar", "median_area_px2",
                    "median_nbr_same", "median_contrast", "median_texture_std", "AP"])
        def fmt(v):
            return "" if v is None else f"{v:.2f}"

        for tag, split, st, ap, nms in [("DamCrack-Sub5", "train", stats_train, ap_main, NAMES),
                                        ("DamCrack-Sub5", "test", stats_main, ap_main, NAMES),
                                        ("DSI-5cls", "test", stats_dsi, ap_dsi, DSI_NAMES)]:
            for n in nms:
                s = st[n]
                if s["n_instances"] == 0:
                    continue
                w.writerow([tag, split, n, s["n_instances"],
                            f"{s['span']['median']:.1f}", f"{s['ar']['median']:.3f}",
                            f"{s['area']['median']:.1f}", f"{s['nbr_same']['median']:.2f}",
                            fmt(s['contrast']['median']), fmt(s['texture_std']['median']),
                            f"{ap[n]:.2f}" if n in ap else ""])
    write_md(stats_main, stats_dsi, ap_main, ap_dsi, corr)
    for r in corr:
        print(f"  {r['feature']:9s} 主数据集 ρ={r['spearman_main']} (p={r['p_main']}) R²={r['ols_r2_main']} | "
              f"合并 ρ={r['spearman_pooled']} (p={r['p_pooled']}) R²={r['ols_r2_pooled']}", flush=True)
    print("[done] -> runs/separability/ + paper/可分性分析.md", flush=True)


if __name__ == "__main__":
    main()
