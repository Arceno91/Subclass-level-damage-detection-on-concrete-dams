# ABD 模块代码交接文档（2026-09-08）

## 一、改动清单（YOLO-PEFT-main 源码）

| 文件 | 改动 |
|---|---|
| `ultralytics/nn/modules/moa/heads.py` | 新增 `_StripAttnHead`（4D 接口：水平/垂直 1-D 条带 DW 卷积 + 空间门控） |
| `ultralytics/nn/modules/moa/block.py` | 新增 `MoAStripBlock`（4 组注意力混合：local/regional/global/**strip**，NUM_GROUPS=4） |
| `ultralytics/nn/modules/moa/wrappers.py` | 新增 `C2fMoAStrip`（C2f 风格包装，YAML 可替换 C3k2/C2fMoA） |
| `ultralytics/nn/modules/moa/__init__.py` | 导出 `MoAStripBlock`、`C2fMoAStrip` |
| `ultralytics/nn/modules/block.py` | 新增 `StripAttention`（方案A 独立模块）、`SkeletonAuxHead`（方案D 辅助掩码头） |
| `ultralytics/nn/modules/__init__.py` | 导出 `StripAttention`、`SkeletonAuxHead` |
| `ultralytics/nn/mixture_registry.py` | 注册 `C2fMoAStrip`(repeat) / `StripAttention` / `SkeletonAuxHead` |
| `ultralytics/mixture_metadata.py` | kinds 补充三项 |
| `ultralytics/engine/trainer.py` | 已打的 BUGFIX（adapter.setup 后 .to(device)） |

## 二、新模型 YAML

| 文件 | 说明 |
|---|---|
| `ultralytics/cfg/models/26/yolo26-strip.yaml` | 方案A：yolo26n + 3 个 StripAttention（P3/P4/P5 特征源后），2.75M 参数 |
| `ultralytics/cfg/models/26/yolo26-moastrip.yaml` | 方案B：yolo26n + neck 用 C2fMoAStrip 替换 C3k2（P4 融合 ×3 + P3 ×2），2.55M 参数 |

均已通过构建 + 前向验证。

## 三、方案 D（骨架伪标签）现状

- ✅ 伪标签已生成：`Damage Detection/dataset/skeleton/{train,val,test}/*.png`
  （LSD 自动提取，train 1199 图 / 15652 裂缝框 / 4.76M 骨架像素）
- ✅ 网络模块 `SkeletonAuxHead` 已就绪（多尺度特征 → stride-4 单通道 logits）
- ⏳ **待接入（明天训练前）**：aux 损失钩子 + dataloader 加载 skeleton
  - loss.py `v8DetectionLoss`：`skeleton_w` 参数开关（默认 0 关闭），BCEWithLogits
  - dataset.py YOLODataset：可选读同名 skeleton png（key "skeleton"）

## 四、训练命令（明天）

```bash
# S1: 方案A（StripAttention）
python 07_detection_experiments.py --exp S1 --epochs 80
# S2: 方案B（MoAStrip）
python 07_detection_experiments.py --exp S2 --epochs 80
```

（在 07 脚本里加 S1/S2 条目：model=yolo26-strip.yaml / yolo26-moastrip.yaml，
可加 MoLoRA（molora_num_experts=4, include_head=True, amp=False, batch=16）或先全量。）

## 五、预期关注指标

- crack_fine / crack_network 的 per-class AP50-95（对比 E2 基线的 18.34% / 17.25%）
- MoAStripBlock 的路由热力图（细长裂缝 → strip 专家的概率）
