# -*- coding: utf-8 -*-
"""23_export_paper_assets.py — 整理论文素材：图复制到 paper/figures + 生成实验参数汇总表

产出:
  paper/figures/图1_K-shot边界曲线.png ... 图7_成像条件仿真.png
  paper/实验参数汇总.md   （每个实验的关键超参，供论文"实验设置"章节与附录使用）
"""
import json
import shutil
from pathlib import Path

import yaml

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
PAPER = ROOT / "paper"
FIGS = PAPER / "figures"
FIGS.mkdir(parents=True, exist_ok=True)

# 图清单：源文件 -> 论文图号名
FIG_MAP = [
    (ROOT / "runs/today_plots/fig1_kshot_boundary.png", "图1_K-shot三方法边界曲线.png"),
    (ROOT / "runs/today_plots/fig2_freq_vs_difficulty.png", "图2_频率与难度反相关.png"),
    (ROOT / "runs/today_plots/fig3_e7_vs_baseline.png", "图3_增强组合与基线per-class对比.png"),
    (ROOT / "runs/today_plots/fig4_kshot_diag.png", "图4_K5少样本诊断.png"),
    (ROOT / "runs/today_plots/fig5_baseline_curve.png", "图5_基线训练曲线.png"),
    (ROOT / "runs/sim_imaging/fig7_sim_imaging.png", "图7_成像条件仿真曲线.png"),
]

# 参数汇总：实验目录 -> 论文中的实验编号/说明
RUN_MAP = [
    ("runs/e6_full/fullft_baseline", "E6-Full（基线主实验）"),
    ("runs/e8_multi/e6full_s123", "E6-Full（seed 123）"),
    ("runs/e7_aug/aug_stack", "E7 全组合（CP+cls_pw+骨架）"),
    ("runs/e7_aug/cp_skl", "E7b（CP+骨架）"),
    ("runs/e7_aug/cp_only", "E7c（仅 CP）"),
    ("runs/e7_aug/skl_only", "E7d（仅骨架）"),
    ("runs/e6_kshot/full_K5_s42", "K-shot Full FT (K=5)"),
    ("runs/e6_kshot/lora_K5_s42", "K-shot LoRA r8 (K=5)"),
    ("runs/e6_kshot/molora_K5_s42", "K-shot MoLoRA (K=5)"),
    ("runs/e6_kshot/diag_d2_molora_k5_s42", "D2 MoLoRA 2专家r4 (K=5)"),
]

KEYS = [
    "model", "data", "epochs", "batch", "imgsz", "seed", "optimizer", "lr0", "lrf",
    "mosaic", "mixup", "copy_paste", "copy_paste_mode", "copy_paste_classes", "cls_pw", "skeleton_aux",
    "lora_type", "lora_r", "lora_alpha", "lora_backend", "lora_include_head",
    "molora_num_experts", "molora_r", "molora_alpha", "molora_top_k", "molora_router_type",
    "amp", "close_mosaic", "workers", "pretrained", "val", "deterministic",
]


def main():
    print("=== 复制图件 ===")
    for src, dst in FIG_MAP:
        if src.exists():
            shutil.copy2(src, FIGS / dst)
            print(f"  {src.name} -> paper/figures/{dst}")
        else:
            print(f"  [缺失] {src}")

    print("\n=== 生成参数汇总 ===")
    lines = ["# 实验参数汇总（自动生成，供论文『实验设置』与附录使用）", ""]
    lines.append("## 一、数据集")
    ds = yaml.safe_load((ROOT / "datasets/DamCrack-Sub5/data.yaml").read_text(encoding="utf-8"))
    lines.append(f"- 路径: `datasets/DamCrack-Sub5`｜类别数 nc={ds['nc']}｜类别: " +
                 ", ".join(f"{k}={v}" for k, v in ds["names"].items()))
    stats = json.loads((ROOT / "datasets/DamCrack-Sub5/stats_summary.json").read_text(encoding="utf-8"))
    lines.append(f"- 规模: {stats['total_images']} 图｜划分 train/val/test = "
                 f"{stats['splits'].get('train')}/{stats['splits'].get('val')}/{stats['splits'].get('test')}"
                 f"（比例 7:2:1，seed={stats['seed']}）")
    lines.append(f"- 实例数: " + ", ".join(f"{k}={v}" for k, v in stats["instances_per_class"].items()))
    lines.append("")

    lines.append("## 二、各实验关键超参")
    lines.append("")
    for rel, label in RUN_MAP:
        args_file = ROOT / rel / "args.yaml"
        if not args_file.exists():
            lines.append(f"### {label}（{rel}）\n- ⚠️ 无 args.yaml\n")
            continue
        a = yaml.safe_load(args_file.read_text(encoding="utf-8")) or {}
        lines.append(f"### {label}")
        lines.append("| 参数 | 值 |")
        lines.append("|---|---|")
        for k in KEYS:
            if k in a and a[k] not in (None, ""):
                lines.append(f"| {k} | `{a[k]}` |")
        lines.append("")
    (PAPER / "实验参数汇总.md").write_text("\n".join(lines), encoding="utf-8")
    print("  -> paper/实验参数汇总.md")

    print("\n=== 结果数据索引 ===")
    for rel in ["runs/e8_multi/results_multi.json", "runs/e6_kshot/kshot_results.json",
                "runs/e6_kshot/diag_results.json", "runs/sim_imaging/results.json"]:
        p = ROOT / rel
        print(f"  {'OK ' if p.exists() else 'MISS'} {rel}")


if __name__ == "__main__":
    main()
