# -*- coding: utf-8 -*-
"""40_render_paper_figures.py — 论文图件统一渲染器（300 dpi，输出到 paper/figures）

用途：从已保存的实验结果（JSON/CSV）重新渲染全部论文图，替代早期分散的绘图脚本。
数据来源（全部只读，不重新训练）：
  runs/e6_kshot/kshot_results.json      图1 K-shot 边界
  datasets/DamCrack-Sub5/stats_summary.json + runs/metrics_suite/metrics.json   图2 / 图12 / 图13
  runs/e6_full/fullft_baseline/results.csv                                      图5 训练曲线
  runs/e8_multi/results_multi.json                                             图6 多种子
  runs/sim_imaging/results.json + remedy_validator.json                        图7 / 图8
  runs/threshold_tuning/results.json                                           图14
  runs/e6_kshot/diag_results.json                                              图4
  datasets/DamCrack-Sub5/{images,labels}/test                                  图9 / 图11（需 GPU 推理）

用法: python 40_render_paper_figures.py [--dpi 300] [--skip-gpu]
"""
import argparse
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch  # noqa: E402

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
FIGS = ROOT / "paper/figures"
FIGS.mkdir(parents=True, exist_ok=True)
CN = ["细长裂缝", "网状裂缝", "块状裂缝", "小型剥落", "大型剥落"]
EN = ["crack_fine", "crack_network", "crack_blocky", "spalling_small", "spalling_large"]
BOX_COLORS = {0: (255, 56, 56), 1: (255, 157, 151), 2: (255, 112, 31), 3: (255, 178, 29), 4: (207, 210, 49)}
DPI = 300


def setup():
    plt.rcParams.update({
        "figure.dpi": DPI, "savefig.dpi": DPI, "font.size": 9.5, "axes.grid": True, "grid.alpha": 0.3,
        "font.sans-serif": ["Microsoft YaHei", "SimHei", "DejaVu Sans"], "axes.unicode_minus": False,
    })


def load(rel):
    p = ROOT / rel
    if p.suffix == ".json":
        return json.loads(p.read_text(encoding="utf-8"))
    if p.suffix == ".csv":
        return list(csv.DictReader(p.open(encoding="utf-8")))
    return None


def save(fig, name):
    fig.tight_layout()
    fig.savefig(FIGS / name)
    plt.close(fig)
    print(f"  [ok] {name}")


# ---------------- 图1 K-shot 边界 ----------------
def fig1():
    recs = load("runs/e6_kshot/kshot_results.json")
    series = {"full": ("全量微调", "o", "#4C72B0"), "lora": ("LoRA r8", "s", "#DD8452"),
              "molora": ("MoLoRA 4 专家", "^", "#55A868")}
    fig, ax = plt.subplots(figsize=(6.6, 4.2))
    for key, (label, mk, col) in series.items():
        pts = sorted([(r["k"], r["mAP50_95"] * 100) for r in recs
                      if r.get("method") == key and "error" not in r])
        if not pts:
            continue
        ks = [p[0] for p in pts]
        vs = [p[1] for p in pts]
        ax.semilogy(ks, vs, mk + "-", label=label, color=col)
        for x, y in zip(ks, vs):
            ax.annotate(f"{y:.2f}", (x, y), textcoords="offset points", xytext=(0, 7), ha="center", fontsize=7.5)
    ax.set_xlabel("5-way K-shot（每子类训练图像数）")
    ax.set_ylabel("测试集 mAP50-95 (%)  [对数坐标]")
    ax.set_xticks([1, 5, 10])
    ax.set_title("K-shot 适用性边界：全量微调系统性优于参数高效微调")
    ax.legend(fontsize=8)
    save(fig, "图1_K-shot边界曲线.png")


# ---------------- 图2 频率-难度反相关 ----------------
def fig2():
    stats = load("datasets/DamCrack-Sub5/stats_summary.json")
    metrics = load("runs/metrics_suite/metrics.json")
    freq = [stats["instances_per_class"][n] for n in EN]
    base = next(r for r in metrics if r["tag"] == "基线 seed42")
    ap = [base["per_class"][n]["AP50_95"] * 100 for n in EN]
    x = np.arange(5)
    fig, ax1 = plt.subplots(figsize=(7.2, 4.2))
    bars = ax1.bar(x, freq, color="#9ECAE1", label="训练集实例数（频率）")
    for b, v in zip(bars, freq):
        ax1.text(b.get_x() + b.get_width() / 2, v, f"{v:,}", ha="center", va="bottom", fontsize=8)
    ax1.set_ylabel("训练集实例数")
    ax1.set_xticks(x)
    ax1.set_xticklabels([f"{c}\n{e}" for c, e in zip(CN, EN)], fontsize=8)
    ax2 = ax1.twinx()
    ax2.plot(x, ap, "o-", color="#D62728", linewidth=2, label="测试集 AP50-95（难度）")
    ax2.set_ylabel("测试集 AP50-95 (%)")
    ax2.set_ylim(20, 52)
    for xi, yi in zip(x, ap):
        ax2.annotate(f"{yi:.1f}", (xi, yi), textcoords="offset points", xytext=(0, 8), ha="center",
                     fontsize=8, color="#D62728")
    ax1.set_title("频率与检测难度反相关：尾类（剥落）反而更易检出")
    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, loc="upper center", fontsize=8)
    save(fig, "图2_频率与难度反相关.png")


# ---------------- 图3 增强消融 ----------------
ABLATION = [
    ("基线", 34.34, 44.05, 29.17),
    ("骨架 λ=0.5", 34.32, 47.65, 28.83),
    ("骨架 λ=0.2", 34.51, 46.90, 29.10),
    ("仅 Copy-Paste", 33.61, 46.30, 28.10),
    ("CP+骨架", 33.18, 44.30, 28.10),
    ("全组合+类先验", 33.59, 47.24, 27.28),
    ("类感知 CP", 34.18, 45.65, 29.00),
]


def fig3():
    x = np.arange(len(ABLATION))
    w = 0.28
    fig, ax = plt.subplots(figsize=(9.0, 4.2))
    ax.bar(x - w, [v[1] for v in ABLATION], w, label="整体 mAP50-95", color="#4C72B0")
    ax.bar(x, [v[2] for v in ABLATION], w, label="大型剥落", color="#55A868")
    ax.bar(x + w, [v[3] for v in ABLATION], w, label="细长裂缝（最难类）", color="#C44E52")
    for xi, v in zip(x, ABLATION):
        ax.text(xi, v[1] + 0.6, f"{v[1]:.2f}", ha="center", fontsize=7)
    ax.axhline(34.34, color="gray", linestyle="--", linewidth=1)
    ax.set_xticks(x)
    ax.set_xticklabels([v[0] for v in ABLATION], fontsize=8)
    ax.set_ylabel("测试集 mAP50-95 / AP (%)")
    ax.set_ylim(20, 52)
    ax.set_title("增强策略的类条件效应：大型剥落普遍受益，细裂缝受损")
    ax.legend(fontsize=8)
    save(fig, "图3_增强消融终版.png")


# ---------------- 图4 K=5 诊断 ----------------
def fig4():
    diag = load("runs/e6_kshot/diag_results.json")
    kshot = load("runs/e6_kshot/kshot_results.json")

    def k5(method):
        for r in kshot:
            if r.get("method") == method and r.get("k") == 5 and "error" not in r:
                return r["mAP50_95"] * 100
        return 0.0

    labels = ["全量微调\n（对照）", "LoRA r8", "MoLoRA\n4 专家 r8", "MoLoRA\n2 专家 r4", "LoRA+教师蒸馏"]
    vals = [k5("full"), k5("lora"), k5("molora")]
    for d in diag:
        if "error" in d:
            continue
        tag = d["method"]
        vals.append(d["mAP50_95"] * 100 if "d2" in tag or "d4" in tag else vals[-1])
    vals = [k5("full"), k5("lora"), k5("molora")]
    for tag in ("d2", "d4"):
        hit = [d for d in diag if tag in d.get("method", "") and "error" not in d]
        vals.append(hit[0]["mAP50_95"] * 100 if hit else 0.0)
    fig, ax = plt.subplots(figsize=(6.8, 3.9))
    bars = ax.bar(labels, vals, color=["#4C72B0", "#DD8452", "#55A868", "#9467BD", "#8C564B"])
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.08, f"{v:.2f}%", ha="center", fontsize=9)
    ax.set_ylabel("测试集 mAP50-95 (%)")
    ax.set_ylim(0, max(vals) * 1.35)
    ax.set_title("K=5 少样本诊断：参数高效微调家族显著落后于全量微调")
    save(fig, "图4_K5少样本诊断.png")


# ---------------- 图5 训练曲线 ----------------
def fig5():
    rows = load("runs/e6_full/fullft_baseline/results.csv")
    ep = [int(r["epoch"]) for r in rows]
    fig, ax = plt.subplots(figsize=(6.6, 3.9))
    ax.plot(ep, [float(r["metrics/mAP50-95(B)"]) * 100 for r in rows], label="mAP50-95", color="#4C72B0")
    ax.plot(ep, [float(r["metrics/mAP50(B)"]) * 100 for r in rows], label="mAP50", color="#DD8452", alpha=0.85)
    ax.set_xlabel("训练轮次 epoch")
    ax.set_ylabel("验证集指标 (%)")
    ax.set_title("全量基线训练曲线（80 轮，末段收敛）")
    ax.legend(fontsize=8)
    save(fig, "图5_基线训练曲线.png")


# ---------------- 图6 多种子 ----------------
def fig6():
    multis = load("runs/e8_multi/results_multi.json")
    vals = {"种子 42": 34.34, "种子 123": 35.06, "种子 456": 34.59}
    for r in multis:
        if r["name"].startswith("e6full") and "seed" in r:
            vals[f"种子 {r['seed']}"] = r["mAP50_95"] * 100
    vals = dict(sorted(vals.items(), key=lambda kv: kv[0]))
    mean = float(np.mean(list(vals.values())))
    vals["均值"] = mean
    fig, ax = plt.subplots(figsize=(6.4, 3.9))
    bars = ax.bar(list(vals.keys()), list(vals.values()),
                  color=["#4C72B0"] * (len(vals) - 1) + ["#DD8452"])
    for b, v in zip(bars, vals.values()):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.12, f"{v:.2f}", ha="center", fontsize=9)
    ax.set_ylabel("测试集 mAP50-95 (%)")
    ax.set_ylim(30, 37)
    ax.set_title("全量基线的多种子复现性（标准差 ≈ 0.37 个百分点）")
    save(fig, "图6_基线多种子复现性.png")


# ---------------- 图7 成像条件仿真 ----------------
def fig7():
    data = load("runs/sim_imaging/results.json")
    fams = {}
    for r in data:
        fams.setdefault(r["family"], []).append(r)
    panels = [("GSD/分辨率", "缩放比（等效地面分辨率）"), ("运动模糊", "模糊核长（像素）"),
              ("光照", "成像条件"), ("图传压缩", "JPEG 质量")]
    fig, axes = plt.subplots(2, 2, figsize=(10, 6.4))
    for ax, (fam, xlabel) in zip(axes.ravel(), panels):
        rows = fams.get(fam, [])
        if not rows:
            continue
        x = range(len(rows))
        overall = [r["mAP50_95"] * 100 for r in rows]
        crack = [r["per_class"]["crack_fine"] * 100 for r in rows]
        spall = [r["per_class"]["spalling_large"] * 100 for r in rows]
        ax.plot(x, overall, "o-", color="#4C72B0", label="整体 mAP50-95")
        ax.plot(x, crack, "s--", color="#D62728", label="细长裂缝")
        ax.plot(x, spall, "^--", color="#2CA02C", label="大型剥落")
        for xi, v in zip(x, overall):
            ax.annotate(f"{v:.1f}", (xi, v), textcoords="offset points", xytext=(0, 6), ha="center", fontsize=7.5)
        ax.set_xticks(list(x))
        ax.set_xticklabels([r["level"] for r in rows], fontsize=8)
        ax.set_xlabel(xlabel)
        ax.set_ylabel("AP / mAP (%)")
        ax.set_ylim(0, 55)
        ax.set_title(fam)
    axes[0, 0].legend(fontsize=7.5, loc="lower left")
    fig.suptitle("巡检成像条件仿真：检出率随成像退化的响应（DamCrack-Sub5 测试集）", fontsize=11)
    save(fig, "图7_成像条件仿真曲线.png")


# ---------------- 图8 推理补救 ----------------
def fig8():
    sim = {r["tag"]: r for r in load("runs/sim_imaging/results.json")}
    val = load("runs/sim_imaging/remedy_validator.json")
    keys = [("gsd_s0.35", "GSD 0.35×"), ("blur_k7", "运动模糊 7 px")]
    direct = [sim["gsd_s0.35"]["mAP50_95"] * 100, sim["blur_k7"]["mAP50_95"] * 100]
    up = [val["gsd_s0.35"]["up1280"] * 100, val["blur_k7"]["up1280"] * 100]
    tta = [val["gsd_s0.35"]["up1280_tta"] * 100, val["blur_k7"]["up1280_tta"] * 100]
    x = np.arange(2)
    w = 0.26
    fig, ax = plt.subplots(figsize=(6.8, 4.0))
    for i, (ys, lab, col) in enumerate([(direct, "640 直推（基准）", "#4C72B0"),
                                        (up, "推理分辨率 1280", "#C44E52"),
                                        (tta, "1280 + TTA", "#55A868")]):
        bars = ax.bar(x + (i - 1) * w, ys, w, label=lab, color=col)
        for b, v in zip(bars, ys):
            ax.text(b.get_x() + b.get_width() / 2, v + 0.4, f"{v:.1f}", ha="center", fontsize=8)
    ax.set_xticks(x)
    ax.set_xticklabels([k[1] for k in keys])
    ax.set_ylabel("测试集 mAP50-95 (%)")
    ax.set_ylim(0, 32)
    ax.set_title("退化场景下的推理侧补救：提高分辨率反而更差，TTA 仅部分挽救")
    ax.legend(fontsize=8)
    save(fig, "图8_推理补救策略.png")


# ---------------- 图9 数据样例 ----------------
def _draw_gt(img, lbl):
    h, w = img.shape[:2]
    for ln in lbl.read_text(encoding="utf-8").splitlines():
        p = ln.split()
        if len(p) != 5:
            continue
        c, cx, cy, bw, bh = int(p[0]), *map(float, p[1:])
        x1, y1 = int((cx - bw / 2) * w), int((cy - bh / 2) * h)
        x2, y2 = int((cx + bw / 2) * w), int((cy + bh / 2) * h)
        import cv2
        cv2.rectangle(img, (x1, y1), (x2, y2), BOX_COLORS[c], 2)
        cv2.putText(img, CN[c], (x1, max(12, y1 - 4)), cv2.FONT_HERSHEY_SIMPLEX, 0.45, BOX_COLORS[c], 1, cv2.LINE_AA)
    return img


def _pick_samples():
    import cv2  # noqa: F401
    lbl_dir = ROOT / "datasets/DamCrack-Sub5/labels/test"
    picks = {}
    for lbl in sorted(lbl_dir.glob("*.txt")):
        counts = {}
        for ln in lbl.read_text(encoding="utf-8").splitlines():
            if ln.strip():
                c = int(ln.split()[0])
                counts[c] = counts.get(c, 0) + 1
        for c, n in counts.items():
            if c not in picks or n > picks[c][1]:
                picks[c] = (lbl.stem, n)
    return picks


def fig9():
    import cv2
    img_dir = ROOT / "datasets/DamCrack-Sub5/images/test"
    lbl_dir = ROOT / "datasets/DamCrack-Sub5/labels/test"
    picks = _pick_samples()
    fig, axes = plt.subplots(2, 3, figsize=(12, 8))
    axes = axes.ravel()
    for i, c in enumerate(range(5)):
        stem, n = picks[c]
        img = _draw_gt(cv2.imread(str(img_dir / f"{stem}.jpg")), lbl_dir / f"{stem}.txt")
        axes[i].imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        axes[i].set_title(f"{CN[c]}（{EN[c]}，该类 {n} 个实例）", fontsize=10)
        axes[i].axis("off")
    counts = {}
    for lbl in sorted(lbl_dir.glob("*.txt")):
        for ln in lbl.read_text(encoding="utf-8").splitlines():
            if ln.strip():
                c = int(ln.split()[0])
                counts[c] = counts.get(c, 0) + 1
    ax = axes[5]
    ax.bar([CN[c] for c in range(5)], [counts.get(c, 0) for c in range(5)],
           color=[f"#{r:02x}{g:02x}{b:02x}" for (b, g, r) in [BOX_COLORS[c] for c in range(5)]])
    for i, c in enumerate(range(5)):
        ax.text(i, counts.get(c, 0) + 8, str(counts.get(c, 0)), ha="center", fontsize=9)
    ax.set_title("测试集各类实例数（长尾分布）", fontsize=10)
    ax.tick_params(axis="x", labelsize=8)
    fig.suptitle("DamCrack-Sub5 数据集样例与子类标注示意（测试集）", fontsize=12)
    save(fig, "图9_数据集样例与子类示意.png")


# ---------------- 图10 方法框架 ----------------
def fig10():
    fig, ax = plt.subplots(figsize=(9.2, 5.6))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6.2)
    ax.axis("off")

    def box(x, y, w, h, text, fc="#EAF2FB", ec="#2B6CB0", fs=8.5):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.1",
                                    linewidth=1.2, edgecolor=ec, facecolor=fc))
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, linespacing=1.5)

    def arrow(x1, y1, x2, y2, color="#4A5568", ls="-"):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=12,
                                     linewidth=1.3, color=color, linestyle=ls, shrinkA=2, shrinkB=2))

    box(0.25, 4.55, 1.7, 1.1, "坝面巡检影像\n640×640", fc="#F7FAFC")
    arrow(1.95, 5.1, 2.75, 5.1)
    box(2.75, 4.55, 2.0, 1.1, "YOLO11n\n骨干 + 颈部", fc="#E3F2FD")
    arrow(4.75, 5.1, 5.55, 5.1)
    box(5.55, 4.55, 1.9, 1.1, "5 子类\n检测头", fc="#E3F2FD")
    arrow(7.45, 5.1, 8.25, 5.1)
    box(8.25, 4.55, 1.5, 1.1, "检测结果\n5 子类", fc="#F7FAFC")
    box(0.25, 2.75, 2.6, 1.25, "① 数据层\n矩形粘贴式 Copy-Paste\n（含类别过滤开关）", fc="#FFF4E6", ec="#C05621")
    arrow(1.55, 4.0, 3.2, 4.5, color="#C05621", ls="--")
    box(3.3, 2.75, 2.9, 1.25, "② 结构层\n骨架辅助监督（LSD 伪标签\n+ stride-4 分支 + BCE 损失）", fc="#FFF4E6", ec="#C05621")
    arrow(4.75, 4.0, 5.9, 4.5, color="#C05621", ls="--")
    box(6.65, 2.75, 3.1, 1.25, "③ 损失层\n类别先验加权\n（用于检验难度假设）", fc="#EDF7ED", ec="#2F855A")
    arrow(8.2, 4.0, 6.9, 4.5, color="#2F855A", ls="--")
    box(0.25, 0.5, 4.4, 1.5,
        "评价协议\n· 全量基线（3 随机种子）\n· 5-way K-shot（K=1/5/10）\n  ×{全量微调, LoRA, MoLoRA}\n· base→novel 增量适配（回放／参数隔离）",
        fc="#F7FAFC", ec="#718096", fs=8)
    box(5.1, 0.5, 4.65, 1.5,
        "工程评估\n· 成像条件仿真（分辨率／模糊／光照／压缩）\n· 推理侧补救（分辨率／TTA／切片）\n· 阈值与成本（AP50／AP75／时延）",
        fc="#F7FAFC", ec="#718096", fs=8)
    arrow(3.0, 2.75, 2.4, 2.0, color="#718096", ls=":")
    arrow(7.4, 2.75, 7.6, 2.0, color="#718096", ls=":")
    ax.text(0.25, 5.95, "图 10  面向混凝土大坝巡检的子类损伤检测方法框架", fontsize=10, fontweight="bold")
    save(fig, "图10_方法框架.png")


# ---------------- 图11 检测可视化（GPU） ----------------
def fig11():
    import cv2
    import sys
    sys.path.insert(0, str(ROOT))
    from ultralytics import YOLO

    img_dir = ROOT / "datasets/DamCrack-Sub5/images/test"
    picks = _pick_samples()
    stems = [picks[c][0] for c in range(5)] + [sorted(img_dir.glob("*.jpg"))[0].stem]
    model = YOLO(str(ROOT / "runs/e6_full/fullft_baseline/weights/best.pt"))
    fig, axes = plt.subplots(2, 3, figsize=(12, 8))
    axes = axes.ravel()
    for i, stem in enumerate(stems[:6]):
        r = model.predict(source=str(img_dir / f"{stem}.jpg"), imgsz=640, conf=0.25, device="0", verbose=False)[0]
        n = len(r.boxes) if r.boxes is not None else 0
        axes[i].imshow(cv2.cvtColor(r.plot(), cv2.COLOR_BGR2RGB))
        axes[i].set_title(f"检测结果（{n} 个目标）", fontsize=9)
        axes[i].axis("off")
    fig.suptitle("基线模型检测结果可视化（DamCrack-Sub5 测试集，置信度阈值 0.25）", fontsize=12)
    save(fig, "图11_检测结果可视化.png")


# ---------------- 图12 分类别 AP ----------------
def fig12():
    metrics = load("runs/metrics_suite/metrics.json")
    base = next(r for r in metrics if r["tag"] == "基线 seed42")
    x = np.arange(5)
    w = 0.26
    fig, ax = plt.subplots(figsize=(8.4, 4.0))
    for i, (key, lab, col) in enumerate([("AP50", "AP50", "#4C72B0"), ("AP75", "AP75", "#DD8452"),
                                         ("AP50_95", "AP50-95（mAP）", "#55A868")]):
        vals = [base["per_class"][n][key] * 100 for n in EN]
        bars = ax.bar(x + (i - 1) * w, vals, w, label=lab, color=col)
        for b, v in zip(bars, vals):
            ax.text(b.get_x() + b.get_width() / 2, v + 0.5, f"{v:.1f}", ha="center", fontsize=7.5)
    ax.set_xticks(x)
    ax.set_xticklabels([f"{c}\n{e}" for c, e in zip(CN, EN)], fontsize=8)
    ax.set_ylabel("AP (%)")
    ax.set_ylim(0, 80)
    ax.set_title("基线模型分类别 AP50 / AP75 / AP50-95（测试集）")
    ax.legend(fontsize=8)
    save(fig, "图12_per-class_AP指标.png")


# ---------------- 图13 类组 AP 与 HM ----------------
def fig13():
    metrics = load("runs/metrics_suite/metrics.json")
    tags = [r["tag"] for r in metrics]
    base_ap = [r["base_group_AP"] * 100 for r in metrics]
    novel_ap = [r["novel_group_AP"] * 100 for r in metrics]
    hm = [r["HM"] * 100 for r in metrics]
    x = np.arange(len(tags))
    w = 0.26
    fig, ax = plt.subplots(figsize=(8.6, 4.0))
    for i, (vals, lab, col) in enumerate([(base_ap, "Base 组（裂缝）", "#4C72B0"),
                                          (novel_ap, "Novel 组（剥落）", "#DD8452"),
                                          (hm, "HM（调和平均）", "#55A868")]):
        bars = ax.bar(x + (i - 1) * w, vals, w, label=lab, color=col)
        for b, v in zip(bars, vals):
            ax.text(b.get_x() + b.get_width() / 2, v + 0.4, f"{v:.1f}", ha="center", fontsize=7.5)
    ax.set_xticks(x)
    ax.set_xticklabels(tags, fontsize=8, rotation=10)
    ax.set_ylabel("AP (%)")
    ax.set_ylim(0, 60)
    ax.set_title("类组 AP 与 HM：剥落组（尾类）显著高于裂缝组")
    ax.legend(fontsize=8)
    save(fig, "图13_类组AP与HM.png")


# ---------------- 图14 阈值调优 ----------------
def fig14():
    data = load("runs/threshold_tuning/results.json")
    rows = data["conf_sweep"]
    best = max(rows, key=lambda r: r["F1"])
    c = [r["conf"] for r in rows]
    fig, ax = plt.subplots(figsize=(7.4, 4.2))
    ax.plot(c, [r["P"] * 100 for r in rows], "o-", label="精确率 P", color="#4C72B0")
    ax.plot(c, [r["R"] * 100 for r in rows], "s-", label="召回率 R", color="#DD8452")
    ax.plot(c, [r["F1"] * 100 for r in rows], "^-", label="F1", color="#55A868", linewidth=2)
    ax.axvline(0.25, color="gray", linestyle="--", linewidth=1, label="默认 conf=0.25")
    ax.scatter([best["conf"]], [best["F1"] * 100], s=90, marker="*", color="#C44E52", zorder=5,
               label=f"最优 F1={best['F1']*100:.1f}%")
    ax.set_xlabel("置信度阈值 conf")
    ax.set_ylabel("指标 (%)")
    ax.set_title("置信度阈值调优：F1 处于平台区，阈值并非瓶颈")
    ax.legend(fontsize=8)
    save(fig, "图14_阈值调优F1曲线.png")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dpi", type=int, default=300)
    ap.add_argument("--skip-gpu", action="store_true", help="跳过需要模型推理的图11")
    args = ap.parse_args()
    global DPI
    DPI = args.dpi
    setup()
    print(f"=== 渲染论文图件 (dpi={DPI}) ===")
    for fn in (fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8, fig9, fig10, fig12, fig13, fig14):
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            print(f"  [FAIL] {fn.__name__}: {e}")
    if not args.skip_gpu:
        try:
            fig11()
        except Exception as e:  # noqa: BLE001
            print(f"  [FAIL] fig11: {e}")
    # 清理历史遗留的重复图
    for stale in ("图1_K-shot三方法边界曲线.png", "图3_增强组合与基线per-class对比.png"):
        p = FIGS / stale
        if p.exists():
            p.unlink()
            print(f"  [clean] 删除旧图 {stale}")
    print("完成 ->", FIGS)


if __name__ == "__main__":
    main()
