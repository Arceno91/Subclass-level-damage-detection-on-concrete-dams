# -*- coding: utf-8 -*-
"""Convert the curated English Markdown tables into Springer LaTeX table blocks.

The source Markdown uses a deliberately narrow pipe-table dialect. This script
parses that structure and emits ``table*`` environments that can be inserted
into the Springer Nature LaTeX manuscript.
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
SOURCE = ROOT / "paper/en/tables.md"
MAIN_OUT = ROOT / "paper/en/tables_ajse.tex"
SUPP_OUT = ROOT / "paper/en/supplementary_tables_ajse.tex"


def latex_text(value: str) -> str:
    """Convert the limited Markdown inline syntax used in table cells to LaTeX."""
    value = value.strip()
    value = re.sub(r"`([^`]+)`", r"\\texttt{\1}", value)
    value = re.sub(r"\*\*([^*]+)\*\*", r"\\textbf{\1}", value)
    value = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"\\textit{\1}", value)
    replacements = {
        "&": r"\&",
        "%": r"\%",
        "#": r"\#",
        "_": r"\_",
        "–": "--",
        "—": "---",
        "−": "-",
        "→": r"$\to$",
        "±": r"$\pm$",
        "×": r"$\times$",
        "·": r"$\cdot$",
        "≤": r"$\leq$",
        "≥": r"$\geq$",
        "β": r"$\beta$",
        "Δ": r"$\Delta$",
        "λ": r"$\lambda$",
        "²": r"$^2$",
        "⁴": r"$^4$",
        "⁻": r"$^{-}$",
        "paper/指标汇总.md": "paper/en/tables.md",
    }
    for old, new in replacements.items():
        value = value.replace(old, new)
    return value


def parse_tables(text: str) -> list[dict[str, object]]:
    pattern = re.compile(r"(?m)^\*\*Table (S?\d+)\*\*\s+(.+?)\s*$")
    matches = list(pattern.finditer(text))
    tables: list[dict[str, object]] = []
    for i, match in enumerate(matches):
        start = match.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        block = text[start:end]
        lines = [line.strip() for line in block.splitlines() if line.strip()]
        table_lines = [line for line in lines if line.startswith("|")]
        if not table_lines:
            continue
        headers = [cell.strip() for cell in table_lines[0].strip("|").split("|")]
        separator = table_lines[1]
        aligns = []
        for token in separator.strip("|").split("|"):
            token = token.strip()
            aligns.append("c" if token.startswith(":") and token.endswith(":") else "l")
        rows = []
        for line in table_lines[2:]:
            rows.append([cell.strip() for cell in line.strip("|").split("|")])
        notes = []
        for line in lines:
            if line.startswith(">"):
                notes.append(line.lstrip("> ").strip())
            elif line.startswith("\\*"):
                notes.append(line[2:].strip())
        tables.append(
            {
                "number": match.group(1),
                "caption": latex_text(match.group(2)),
                "headers": [latex_text(cell) for cell in headers],
                "aligns": "".join(aligns),
                "rows": [[latex_text(cell) for cell in row] for row in rows],
                "notes": [latex_text(note) for note in notes],
            }
        )
    return tables


def render_table(table: dict[str, object], supplementary: bool) -> str:
    number = str(table["number"])
    caption = str(table["caption"])
    if supplementary:
        cap_cmd = rf"\caption*{{Table S{number[1:]} {caption}}}"
        label = f"tab:S{number[1:]}"
    else:
        cap_cmd = rf"\caption{{{caption}}}"
        label = f"tab:{number}"
    lines = [
        r"\begin{table*}[t]",
        r"\centering",
        cap_cmd,
        rf"\label{{{label}}}",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        rf"\begin{{adjustbox}}{{max width=\textwidth}}",
        rf"\begin{{tabular}}{{{table['aligns']}}}",
        r"\toprule",
        " & ".join(str(cell) for cell in table["headers"]) + r" \\",
        r"\midrule",
    ]
    for row in table["rows"]:
        lines.append(" & ".join(str(cell) for cell in row) + r" \\")
    lines.extend(
        [
            r"\bottomrule",
            r"\end{tabular}",
            r"\end{adjustbox}",
        ]
    )
    for note in table["notes"]:
        lines.append(r"\par\vspace{2pt}\footnotesize\noindent " + str(note))
    lines.append(r"\end{table*}")
    return "\n".join(lines)


def main() -> None:
    text = SOURCE.read_text(encoding="utf-8")
    tables = parse_tables(text)
    main = [table for table in tables if not str(table["number"]).startswith("S")]
    supp = [table for table in tables if str(table["number"]).startswith("S")]
    MAIN_OUT.write_text("\n\n".join(render_table(table, False) for table in main) + "\n", encoding="utf-8")
    SUPP_OUT.write_text("\n\n".join(render_table(table, True) for table in supp) + "\n", encoding="utf-8")
    print(f"[tables] main={len(main)} supplementary={len(supp)} -> {MAIN_OUT.name}, {SUPP_OUT.name}")


if __name__ == "__main__":
    main()
