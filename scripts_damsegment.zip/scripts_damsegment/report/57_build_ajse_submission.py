# -*- coding: utf-8 -*-
"""Build the AJSE initial-submission package from the curated Markdown sources."""
from __future__ import annotations

import csv
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
PANDOC = ROOT / "submission_ajse/tools/pandoc-3.11/pandoc.exe"
TEMPLATE = ROOT / "submission_ajse/template/sn-article-template"
SOURCE = ROOT / "paper/en/manuscript_ajse.md"
FIGURES_SRC = ROOT / "paper/en/figures"
FIGURES_TEX = ROOT / "paper/en/figures_ajse.tex"
TABLES_TEX = ROOT / "paper/en/tables_ajse.tex"
SUPP_TABLES_TEX = ROOT / "paper/en/supplementary_tables_ajse.tex"
BIB = ROOT / "paper/en/references_ajse.bib"

OUT = ROOT / "submission_ajse"
MANUSCRIPT_DIR = OUT / "01_manuscript"
FIGURE_DIR = OUT / "02_figures"
TABLE_DIR = OUT / "03_tables"
DECL_DIR = OUT / "04_declarations"
SUPP_DIR = OUT / "05_supplementary"
REPRO_DIR = OUT / "06_reproducibility"
BUILD_DIR = OUT / "build"

FIGURE_FILES = {
    1: "fig01_kshot_boundary",
    2: "fig02_frequency_vs_difficulty",
    3: "fig03_augmentation_ablation",
    4: "fig04_kshot_diagnostic",
    5: "fig05_training_curves",
    6: "fig06_seed_reproducibility",
    7: "fig07_imaging_envelope",
    8: "fig08_inference_remedies",
    9: "fig09_dataset_samples",
    10: "fig10_method_framework",
    11: "fig11_detection_results",
    12: "fig12_per_class_ap",
    13: "fig13_class_group_hm",
    14: "fig14_threshold_tuning",
    15: "fig15_cross_batch",
    16: "fig16_detector_comparison",
    17: "fig17_second_dataset",
    18: "fig18_method_experiments",
    19: "fig19_resolution_matrix",
}


def pandoc(markdown: str, *args: str) -> str:
    result = subprocess.run(
        [str(PANDOC), "-f", "markdown", "-t", "latex", *args],
        input=markdown,
        text=True,
        encoding="utf-8",
        capture_output=True,
        check=True,
        cwd=ROOT,
    )
    return result.stdout


def latex_unicode(value: str) -> str:
    replacements = {
        "·": r"$\cdot$",
        "→": r"$\to$",
        "±": r"$\pm$",
        "×": r"$\times$",
        "−": "-",
        "∝": r"$\propto$",
        "≤": r"$\leq$",
        "≥": r"$\geq$",
        "²": r"$^2$",
        "β": r"$\beta$",
        "λ": r"$\lambda$",
        "mAP@{[}.50:.95{]}": "mAP@[.50:.95]",
        r"\textless=3": r"$\leq 3$",
        "+/-": r"$\pm$",
    }
    for old, new in replacements.items():
        value = value.replace(old, new)
    return value


def extract_section(text: str, title: str) -> str:
    match = re.search(rf"(?ms)^## {re.escape(title)}\s*\n(.*?)(?=^---\s*$|^##\s)", text)
    if not match:
        raise RuntimeError(f"section not found: {title}")
    return match.group(1).strip()


def split_figure_blocks() -> dict[str, str]:
    figure_tex = FIGURES_TEX.read_text(encoding="utf-8")
    figure_tex = re.sub(
        r"fig(\d{2})_[A-Za-z0-9_]+\.pdf",
        lambda match: f"Fig{int(match.group(1))}.pdf",
        figure_tex,
    )
    blocks = re.findall(r"\\begin\{figure\*\}.*?\\end\{figure\*\}", figure_tex, re.S)
    result = {}
    for block in blocks:
        match = re.search(r"\\label\{fig:(\d+)\}", block)
        if not match:
            continue
        number = int(match.group(1))
        numbered_block = rf"\setcounter{{figure}}{{{number - 1}}}" + "\n" + block.strip()
        result[f"FIGBLOCK{number:02d}TOKEN"] = numbered_block
    return result


def replace_figure_tokens(latex: str) -> str:
    blocks = split_figure_blocks()
    for token, block in blocks.items():
        latex = latex.replace(token, f"\n\n{block}\n\n")
        number = token.removeprefix("FIGBLOCK").removesuffix("TOKEN")
        escaped = f"{{[}}{{]}}FIG{number}{{]}}{{]}}"
        latex = latex.replace(escaped, f"\n\n{block}\n\n")
    return latex


def normalise_body(body: str) -> str:
    body = re.sub(r"(?m)^---\s*$", "", body)
    body = re.sub(r"(?m)^(#{2,4})\s+\d+(?:\.\d+)*\s+", r"\1 ", body)
    body = body.replace("[[FIG", "FIGBLOCK").replace("]]", "TOKEN")
    return body.strip()


def build_manuscript() -> dict[str, str]:
    text = SOURCE.read_text(encoding="utf-8")
    title = re.search(r"(?m)^# (.+)$", text).group(1).strip()
    abstract_md = extract_section(text, "Abstract").split("**Keywords:**", 1)[0].strip()
    abstract = latex_unicode(pandoc(abstract_md).strip())
    keywords_match = re.search(r"(?m)^\*\*Keywords:\*\*\s*(.+)$", text)
    if not keywords_match:
        raise RuntimeError("keywords not found")
    keywords = keywords_match.group(1).strip()

    body_start = text.index("## 1 Introduction")
    body_md = normalise_body(text[body_start:])
    body_tex = pandoc(body_md, "--natbib", "--shift-heading-level-by=-1")
    body_tex = latex_unicode(body_tex)
    body_tex = replace_figure_tokens(body_tex)
    body_tex = body_tex.replace(r"\section{Statements and Declarations}", r"\section*{Statements and Declarations}")
    body_tex = body_tex.replace(r"\subsection{5.1", r"\subsection{5.1")

    tables = TABLES_TEX.read_text(encoding="utf-8").strip()
    body_tex += "\n\n\\clearpage\n\\section*{Tables}\n\n" + tables + "\n"

    manuscript = rf"""\documentclass[iicol,pdflatex,sn-mathphys-num]{{sn-jnl}}

\usepackage{{graphicx}}
\usepackage{{multirow}}
\usepackage{{amsmath,amssymb,amsfonts}}
\usepackage{{booktabs}}
\usepackage{{adjustbox}}
\usepackage{{stfloats}}
\usepackage{{xurl}}
\graphicspath{{{{../02_figures/}}}}
\setlength{{\emergencystretch}}{{2em}}
\Urlmuskip=0mu plus 1mu\relax
\providecommand{{\tightlist}}{{%
  \setlength{{\itemsep}}{{0pt}}\setlength{{\parskip}}{{0pt}}}}

\articletype{{Research Article}}

\title[Damage detection on concrete dams]{{{title}}}

\author*[1]{{\fnm{{AUTHOR}} \sur{{INPUT\_NEEDED}}}}\email{{author-input-needed@example.invalid}}
\affil*[1]{{\orgdiv{{AUTHOR\_INPUT\_NEEDED}}, \orgname{{AUTHOR\_INPUT\_NEEDED}}, \orgaddress{{\city{{AUTHOR\_INPUT\_NEEDED}}, \country{{AUTHOR\_INPUT\_NEEDED}}}}}}

\abstract{{{abstract}}}

\keywords{{{keywords}}}

\begin{{document}}
\maketitle

{body_tex}

\backmatter
\bibliography{{references_ajse}}
\end{{document}}
"""
    (MANUSCRIPT_DIR / "manuscript.tex").write_text(manuscript, encoding="utf-8")
    return {"title": title, "abstract": abstract, "keywords": keywords}


def copy_support_files(meta: dict[str, str]) -> None:
    shutil.copy2(TEMPLATE / "sn-jnl.cls", MANUSCRIPT_DIR / "sn-jnl.cls")
    shutil.copy2(TEMPLATE / "bst/sn-mathphys-num.bst", MANUSCRIPT_DIR / "sn-mathphys-num.bst")
    shutil.copy2(BIB, MANUSCRIPT_DIR / "references_ajse.bib")
    shutil.copy2(TABLES_TEX, TABLE_DIR / "Tables.tex")
    shutil.copy2(SUPP_TABLES_TEX, SUPP_DIR / "Supplementary_Tables.tex")

    manifest_rows = []
    for number, stem in FIGURE_FILES.items():
        source_pdf = FIGURES_SRC / f"{stem}.pdf"
        target_pdf = FIGURE_DIR / f"Fig{number}.pdf"
        shutil.copy2(source_pdf, target_pdf)
        source_png = FIGURES_SRC / f"{stem}.png"
        target_png = FIGURE_DIR / f"Fig{number}.png"
        shutil.copy2(source_png, target_png)
        if number in {9, 10, 11}:
            source_production = FIGURES_SRC / f"{stem}.tiff"
            target_production = FIGURE_DIR / f"Fig{number}.tiff"
        else:
            source_production = FIGURES_SRC / f"{stem}.eps"
            target_production = FIGURE_DIR / f"Fig{number}.eps"
        if source_production.exists():
            shutil.copy2(source_production, target_production)
        manifest_rows.append(
            {
                "figure": number,
                "pdf": target_pdf.name,
                "png": target_png.name,
                "production": target_production.name,
            }
        )
    with (FIGURE_DIR / "figures_manifest.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["figure", "pdf", "png", "production"])
        writer.writeheader()
        writer.writerows(manifest_rows)


def build_supplementary() -> None:
    tables = SUPP_TABLES_TEX.read_text(encoding="utf-8").strip()
    text = rf"""\documentclass[11pt]{{article}}
\usepackage[a4paper,margin=25mm]{{geometry}}
\usepackage{{graphicx,booktabs,adjustbox}}
\usepackage[font=small]{{caption}}
\usepackage{{hyperref}}
\title{{Supplementary Information\\Subclass-level damage detection on concrete dams}}
\author{{AUTHOR\_INPUT\_NEEDED}}
\date{{}}
\begin{{document}}
\maketitle
\section*{{Supplementary tables}}
{tables}
\section*{{Reproducibility package}}
The submission package contains the derived split manifests, subclass labels, model weights, configurations, evaluation scripts and figure-generation scripts required to reproduce the reported results. The source datasets are cited in the main manuscript.
\end{{document}}
"""
    (SUPP_DIR / "supplementary_information.tex").write_text(text, encoding="utf-8")


def refresh_manuscript_sources() -> None:
    """把当前论文源文件快照到 06_reproducibility/manuscript_sources，随构建刷新（不再过期）。
    插入说明：Data availability 中承诺的源文件清单与 6 号目录里的快照必须与 01 号目录同步。"""
    dst = REPRO_DIR / "manuscript_sources"
    dst.mkdir(parents=True, exist_ok=True)
    for name in ("manuscript_ajse.md", "tables_ajse.tex", "figures_ajse.tex",
                 "references_ajse.bib", "figure_captions.md"):
        src = ROOT / "paper/en" / name
        if src.exists():
            shutil.copy2(src, dst / name)


def main() -> None:
    for directory in (MANUSCRIPT_DIR, FIGURE_DIR, TABLE_DIR, DECL_DIR, SUPP_DIR, REPRO_DIR, BUILD_DIR):
        directory.mkdir(parents=True, exist_ok=True)
    meta = build_manuscript()
    copy_support_files(meta)
    build_supplementary()
    refresh_manuscript_sources()
    print(f"[ajse] manuscript built: {meta['title']}")
    print(f"[ajse] output: {MANUSCRIPT_DIR / 'manuscript.tex'}")


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as exc:
        sys.stderr.write(exc.stdout or "")
        sys.stderr.write(exc.stderr or "")
        raise
