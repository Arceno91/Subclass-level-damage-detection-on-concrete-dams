# -*- coding: utf-8 -*-
"""55_render_figures_en.py — 英文版论文图表渲染器（AJSE 投稿用）

与中文渲染器（40_render_paper_figures.py）分开维护，原因：英文图需按 Springer 规范绘制
（图内不放标题、轴标签与图例全英文、300 dpi、色盲友好配色），且需新增第二数据集与方法实验两张图。

输出：paper/en/figures/*.png（300 dpi）
用法：python 55_render_figures_en.py [--only fig2,fig7]
"""
import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch  # noqa: E402

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
OUT = ROOT / "paper/en/figures"
DPI = 600
plt.rcParams.update({
    "font.family": ["Arial", "DejaVu Sans"],
    "font.size": 9,
    "axes.labelsize": 10,
    "axes.titlesize": 10,
    "legend.fontsize": 8.5,
    "xtick.labelsize": 8.5,
    "ytick.labelsize": 8.5,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.linewidth": 0.9,
    "xtick.major.width": 0.9,
    "ytick.major.width": 0.9,
    "xtick.major.size": 3.5,
    "ytick.major.size": 3.5,
    "lines.linewidth": 1.5,
    "legend.frameon": False,
    "mathtext.fontset": "custom",
    "mathtext.rm": "Arial",
    "mathtext.it": "Arial:italic",
    "mathtext.bf": "Arial:bold",
    "figure.autolayout": False,
    "savefig.bbox": "tight",
})
C = {"blue": "#4C72B0", "orange": "#DD8452", "green": "#55A868",
     "red": "#C44E52", "purple": "#8172B3", "brown": "#937860", "grey": "#8C8C8C"}
SUB = ["crack_fine", "crack_network", "crack_blocky", "spalling_small", "spalling_large"]
BOX_COLORS = {
    0: (76, 114, 176),
    1: (85, 168, 104),
    2: (129, 114, 179),
    3: (221, 132, 82),
    4: (196, 78, 82),
}


def load(rel):
    """Load a JSON or CSV artefact from the workspace root."""
    p = ROOT / rel
    if p.suffix.lower() == ".csv":
        import csv

        with p.open(encoding="utf-8") as fh:
            return list(csv.DictReader(fh))
    return json.loads(p.read_text(encoding="utf-8"))


def dsi5_shares():
    """DSI 五分类实例占比（按类别 id 顺序排列，与 suite 里 per_class 的顺序一致）。"""
    s = load("datasets/DSI_summary.json")["DSI-Det-5cls"]
    inst = s["instances"]
    total = sum(inst.values())
    return [100.0 * inst[str(i)] / total for i in range(len(inst))]


def save(fig, name):
    OUT.mkdir(parents=True, exist_ok=True)
    stem = Path(name).stem
    png = OUT / f"{stem}.png"
    pdf = OUT / f"{stem}.pdf"
    fig.savefig(png, dpi=DPI)
    fig.savefig(pdf)
    if stem in {"fig09_dataset_samples", "fig10_method_framework", "fig11_detection_results"}:
        fig.savefig(OUT / f"{stem}.tiff", dpi=DPI, pil_kwargs={"compression": "tiff_lzw"})
    else:
        fig.savefig(OUT / f"{stem}.eps")
    plt.close(fig)
    print(f"[fig] {png.name}  {png.stat().st_size/1024:.0f} KB", flush=True)


# ---------------------------------------------------------------- Fig. 9
def _draw_gt(img, lbl):
    import cv2

    h, w = img.shape[:2]
    for line in lbl.read_text(encoding="utf-8").splitlines():
        parts = line.split()
        if len(parts) != 5:
            continue
        cls, cx, cy, bw, bh = int(parts[0]), *map(float, parts[1:])
        x1 = int((cx - bw / 2) * w)
        y1 = int((cy - bh / 2) * h)
        x2 = int((cx + bw / 2) * w)
        y2 = int((cy + bh / 2) * h)
        colour = BOX_COLORS[cls][::-1]
        cv2.rectangle(img, (x1, y1), (x2, y2), colour, 2)
        cv2.putText(
            img,
            SUB[cls].replace("_", " "),
            (x1, max(14, y1 - 5)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            colour,
            1,
            cv2.LINE_AA,
        )
    return img


def _pick_samples():
    lbl_dir = ROOT / "datasets/DamCrack-Sub5/labels/test"
    picks = {}
    for lbl in sorted(lbl_dir.glob("*.txt")):
        counts = {}
        for line in lbl.read_text(encoding="utf-8").splitlines():
            if line.strip():
                c = int(line.split()[0])
                counts[c] = counts.get(c, 0) + 1
        for c, n in counts.items():
            if c not in picks or n > picks[c][1]:
                picks[c] = (lbl.stem, n)
    return picks


def fig9_dataset_samples():
    """Dataset samples and deterministic subclass illustration."""
    import cv2

    img_dir = ROOT / "datasets/DamCrack-Sub5/images/test"
    lbl_dir = ROOT / "datasets/DamCrack-Sub5/labels/test"
    picks = _pick_samples()
    fig, axes = plt.subplots(2, 3, figsize=(7.4, 4.9))
    axes = axes.ravel()
    for i, cls in enumerate(range(5)):
        stem, count = picks[cls]
        img = _draw_gt(cv2.imread(str(img_dir / f"{stem}.jpg")), lbl_dir / f"{stem}.txt")
        axes[i].imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        axes[i].set_title(
            f"({chr(97 + i)}) {SUB[cls].replace('_', ' ')} ({count} instances)",
            fontsize=8,
        )
        axes[i].axis("off")

    counts = {}
    for lbl in sorted(lbl_dir.glob("*.txt")):
        for line in lbl.read_text(encoding="utf-8").splitlines():
            if line.strip():
                c = int(line.split()[0])
                counts[c] = counts.get(c, 0) + 1
    ax = axes[5]
    ax.bar(
        range(5),
        [counts.get(c, 0) for c in range(5)],
        color=[f"#{r:02x}{g:02x}{b:02x}" for r, g, b in [BOX_COLORS[c] for c in range(5)]],
    )
    for i, c in enumerate(range(5)):
        ax.text(i, counts.get(c, 0) + 10, str(counts.get(c, 0)), ha="center", fontsize=7)
    ax.set_xticks(range(5))
    ax.set_xticklabels([name.replace("_", "\n") for name in SUB], fontsize=6.5)
    ax.set_ylabel("instances in test split", fontsize=8)
    ax.set_title("(f) long-tailed test distribution", fontsize=8)
    ax.grid(axis="y", alpha=0.25, linewidth=0.5)
    fig.tight_layout()
    save(fig, "fig09_dataset_samples.png")


# ---------------------------------------------------------------- Fig. 10
def fig10_method_framework():
    """Method framework without an in-figure title."""
    fig, ax = plt.subplots(figsize=(7.4, 4.2))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6.2)
    ax.axis("off")

    def box(x, y, w, h, text, fc="#EAF2FB", ec="#2B6CB0", fs=7.2):
        ax.add_patch(
            FancyBboxPatch(
                (x, y),
                w,
                h,
                boxstyle="round,pad=0.02,rounding_size=0.08",
                linewidth=1.0,
                edgecolor=ec,
                facecolor=fc,
            )
        )
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, linespacing=1.35)

    def arrow(x1, y1, x2, y2, color="#4A5568", ls="-"):
        ax.add_patch(
            FancyArrowPatch(
                (x1, y1),
                (x2, y2),
                arrowstyle="-|>",
                mutation_scale=10,
                linewidth=1.0,
                color=color,
                linestyle=ls,
                shrinkA=2,
                shrinkB=2,
            )
        )

    box(0.25, 4.55, 1.7, 1.1, "dam-surface\ninspection images\n640 x 640", fc="#F7FAFC")
    arrow(1.95, 5.1, 2.75, 5.1)
    box(2.75, 4.55, 2.0, 1.1, "YOLO11n\nbackbone + neck", fc="#E3F2FD")
    arrow(4.75, 5.1, 5.55, 5.1)
    box(5.55, 4.55, 1.9, 1.1, "five-subclass\ndetection head", fc="#E3F2FD")
    arrow(7.45, 5.1, 8.25, 5.1)
    box(8.25, 4.55, 1.5, 1.1, "subclass\npredictions", fc="#F7FAFC")
    box(0.25, 2.75, 2.6, 1.25, "data level\nrectangular Copy-Paste\nwith class filter", fc="#FFF4E6", ec="#C05621")
    arrow(1.55, 4.0, 3.2, 4.5, color="#C05621", ls="--")
    box(
        3.3,
        2.75,
        2.9,
        1.25,
        "structure level\nskeleton auxiliary branch\n(LSD pseudo-labels + BCE)",
        fc="#FFF4E6",
        ec="#C05621",
    )
    arrow(4.75, 4.0, 5.9, 4.5, color="#C05621", ls="--")
    box(6.65, 2.75, 3.1, 1.25, "loss level\nclass-prior weighting\nfor hypothesis testing", fc="#EDF7ED", ec="#2F855A")
    arrow(8.2, 4.0, 6.9, 4.5, color="#2F855A", ls="--")
    box(
        0.25,
        0.5,
        4.4,
        1.5,
        "evaluation protocol\n- full baseline (3 seeds)\n- 5-way K-shot (K = 1/5/10)\n  x {full fine-tuning, LoRA, MoLoRA}\n- base-to-novel adaptation",
        fc="#F7FAFC",
        ec="#718096",
        fs=6.8,
    )
    box(
        5.1,
        0.5,
        4.65,
        1.5,
        "engineering assessment\n- imaging simulation (GSD, blur, light, JPEG)\n- inference remedies (resolution, TTA, slicing)\n- operating point and cost",
        fc="#F7FAFC",
        ec="#718096",
        fs=6.8,
    )
    arrow(3.0, 2.75, 2.4, 2.0, color="#718096", ls=":")
    arrow(7.4, 2.75, 7.6, 2.0, color="#718096", ls=":")
    fig.tight_layout()
    save(fig, "fig10_method_framework.png")


# ---------------------------------------------------------------- Fig. 11
def fig11_detection_results():
    """Qualitative detection results on the held-out test split."""
    import cv2
    import torch
    from ultralytics import YOLO

    img_dir = ROOT / "datasets/DamCrack-Sub5/images/test"
    picks = _pick_samples()
    stems = [picks[c][0] for c in range(5)]
    background = None
    for lbl in sorted((ROOT / "datasets/DamCrack-Sub5/labels/test").glob("*.txt")):
        if not lbl.read_text(encoding="utf-8").strip():
            background = lbl.stem
            break
    if background:
        stems.append(background)
    else:
        stems.append(sorted(img_dir.glob("*.jpg"))[0].stem)

    model = YOLO(str(ROOT / "runs/e6_full/fullft_baseline/weights/best.pt"))
    device = 0 if torch.cuda.is_available() else "cpu"
    fig, axes = plt.subplots(2, 3, figsize=(7.4, 4.9))
    axes = axes.ravel()
    for i, stem in enumerate(stems[:6]):
        result = model.predict(
            source=str(img_dir / f"{stem}.jpg"),
            imgsz=640,
            conf=0.25,
            device=device,
            verbose=False,
        )[0]
        n = len(result.boxes) if result.boxes is not None else 0
        axes[i].imshow(cv2.cvtColor(result.plot(line_width=2), cv2.COLOR_BGR2RGB))
        axes[i].set_title(f"({chr(97 + i)}) {n} detections", fontsize=8)
        axes[i].axis("off")
    fig.tight_layout()
    save(fig, "fig11_detection_results.png")


# ---------------------------------------------------------------- Fig. 2
def fig2_frequency_vs_difficulty():
    """Frequency vs difficulty: main dataset (5 subclasses) and second dataset (5 classes)."""
    suite = {r["tag"]: r for r in load("runs/metrics_suite/suite_20260915.json")}
    main = suite["baseline"]
    dsi = suite["dsi5_yolo11n"]
    main_share = [20943, 12646, 24696, 4036, 1427]
    main_share = [100 * x / sum(main_share) for x in main_share]
    main_ap = [c["AP50_95"] * 100 for c in main["per_class"]]
    dsi_share = dsi5_shares()
    dsi_ap = [c["AP50_95"] * 100 for c in dsi["per_class"]]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.0, 2.9))
    for ax, share, ap, names, tag in (
        (ax1, main_share, main_ap, [s.replace("_", " ") for s in SUB], "DamCrack-Sub5"),
        (ax2, dsi_share, dsi_ap, [c["name"].replace("_", " ") for c in dsi["per_class"]], "DSI (5-class)"),
    ):
        for s, a, n in zip(share, ap, names):
            col = C["blue"] if "crack" in n else C["orange"]
            ax.scatter(s, a, s=46, color=col, zorder=3, edgecolor="white", linewidth=0.8)
            ax.annotate(n, (s, a), textcoords="offset points", xytext=(5, 4), fontsize=7.2)
        ax.set_xlabel("share of instances (%)")
        ax.set_ylabel("AP@[.50:.95] (%)")
        ax.grid(alpha=0.25, linewidth=0.5)
        ax.set_title(f"({tag})", fontsize=9)
    ax1.set_xlim(0, 45)
    ax1.set_ylim(20, 50)
    ax2.set_xlim(0, 40)
    ax2.set_ylim(0, 70)
    h = [plt.Line2D([], [], marker="o", ls="", color=C["blue"], label="crack classes"),
         plt.Line2D([], [], marker="o", ls="", color=C["orange"], label="spalling / other")]
    ax1.legend(handles=h, loc="lower right", frameon=False)
    fig.tight_layout()
    save(fig, "fig02_frequency_vs_difficulty.png")


# ---------------------------------------------------------------- Fig. 7
def fig7_imaging_envelope():
    """Imaging-condition degradation curves (four single-factor families)."""
    res = load("runs/sim_imaging/results.json")
    fam = {"gsd": ("Ground sampling distance (x reference)", "gsd_", [1.0, 0.75, 0.5, 0.35, 0.25]),
           "blur": ("Motion blur (px)", "blur_", [0, 3, 7, 11]),
           "light": ("Illumination change (level)", "light_", [1, 2, 3]),
           "jpeg": ("JPEG quality", "jpeg_", [100, 75, 50, 35])}
    fig, axes = plt.subplots(1, 4, figsize=(7.4, 2.4))
    for ax, (key, (xlabel, pre, levels)) in zip(axes, fam.items()):
        rows = [r for r in res if r["tag"].startswith(pre)]
        xs = [r["level"] for r in rows]
        ys = [r["mAP50_95"] * 100 for r in rows]
        thin = [r["per_class"]["crack_fine"] * 100 for r in rows]
        ax.plot(range(len(ys)), ys, "-o", color=C["blue"], lw=1.6, ms=4, label="overall")
        ax.plot(range(len(thin)), thin, "--s", color=C["red"], lw=1.4, ms=3.6, label="thin crack")
        ax.set_xticks(range(len(xs)))
        ax.set_xticklabels([str(x) for x in xs])
        ax.set_xlabel(xlabel, fontsize=8.6)
        ax.grid(alpha=0.25, linewidth=0.5)
        if ax is axes[0]:
            ax.set_ylabel("mAP / AP (%)")
            ax.legend(loc="lower left", frameon=False)
        ax.set_ylim(0, 42)
    fig.tight_layout()
    save(fig, "fig07_imaging_envelope.png")


# ---------------------------------------------------------------- Fig. 8
def fig8_inference_remedies():
    """Inference-side remedies under degradation (unified val() pipeline)."""
    recs = load("runs/sim_imaging/remedy_clean.json")
    by = {(r["condition"], r["variant"]): r for r in recs}
    scenarios = [("clean", "clean"), ("gsd_s0.35", "GSD 0.35×"), ("blur_k7", "blur 7 px")]
    labels, direct, up, uptta = [], [], [], []
    for cond, lab in scenarios:
        labels.append(lab)
        direct.append(by[(cond, "A_direct640")]["mAP50_95"] * 100)
        up.append(by[(cond, "B_up1280")]["mAP50_95"] * 100)
        uptta.append(by[(cond, "C_up1280_tta")]["mAP50_95"] * 100)
    x = np.arange(len(labels))
    w = 0.26
    fig, ax = plt.subplots(figsize=(4.4, 2.7))
    ax.bar(x - w, direct, w, label="direct", color=C["blue"])
    ax.bar(x, up, w, label="up-scale to 1280", color=C["orange"])
    ax.bar(x + w, uptta, w, label="up-scale + TTA", color=C["green"])
    for xi, v in zip(x - w, direct):
        ax.text(xi, v + 0.6, f"{v:.1f}", ha="center", fontsize=7)
    for xi, v in zip(x, up):
        if not np.isnan(v):
            ax.text(xi, v + 0.6, f"{v:.1f}", ha="center", fontsize=7)
    for xi, v in zip(x + w, uptta):
        ax.text(xi, v + 0.6, f"{v:.1f}", ha="center", fontsize=7)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=8.6)
    ax.set_ylabel("mAP@[.50:.95] (%)")
    ax.set_ylim(0, 40)
    ax.legend(frameon=False, loc="upper right")
    ax.grid(axis="y", alpha=0.25, linewidth=0.5)
    fig.tight_layout()
    save(fig, "fig08_inference_remedies.png")


# ---------------------------------------------------------------- Fig. 13
def fig13_class_group_hm():
    """Class-group AP and harmonic mean across models."""
    suite = {r["tag"]: r for r in load("runs/metrics_suite/suite_20260915.json")}
    order = [("baseline", "baseline\n(DamCrack-Sub5 test)"), ("dacw_b1", "DACW β=1"),
             ("dacw_b2", "DACW β=2"), ("dbjt→A", "DBJT\n(batch A test)"),
             ("dbjt→B", "DBJT\n(batch B test)"), ("dsi2_yolo11n", "DSI-2cls")]
    labels, crack, spall, hm = [], [], [], []
    for tag, lab in order:
        r = suite.get(tag)
        if not r or len(r.get("groups", {})) < 2:
            continue
        g = list(r["groups"].values())
        labels.append(lab)
        crack.append(g[0] * 100)
        spall.append(g[1] * 100)
        hm.append(r["HM"] * 100)
    x = np.arange(len(labels))
    w = 0.27
    fig, ax = plt.subplots(figsize=(6.6, 2.9))
    ax.bar(x - w, crack, w, label="crack group AP", color=C["blue"])
    ax.bar(x, spall, w, label="spalling group AP", color=C["orange"])
    ax.bar(x + w, hm, w, label="HM", color=C["green"])
    ax.axhline(34.34, color=C["grey"], ls=":", lw=1.1)
    ax.text(len(labels) - 0.5, 34.9, "baseline overall mAP 34.34", fontsize=7.2, color=C["grey"], ha="right")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=8)
    ax.set_ylabel("AP / HM (%)")
    ax.set_ylim(0, 55)
    ax.legend(frameon=False, ncol=3, loc="upper center")
    ax.grid(axis="y", alpha=0.25, linewidth=0.5)
    fig.tight_layout()
    save(fig, "fig13_class_group_hm.png")


# ---------------------------------------------------------------- Fig. 14
def fig14_threshold_tuning():
    """Confidence and NMS-IoU sweeps."""
    d = load("runs/threshold_tuning/results.json")
    conf = d["conf_sweep"]
    iou = d.get("iou_sweep") or d.get("nms_sweep") or []
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(6.4, 2.5))
    xs = [c["conf"] for c in conf]
    for key, lab, col in (("P", "precision", C["blue"]), ("R", "recall", C["orange"]), ("F1", "F1", C["green"])):
        ax1.plot(xs, [c[key] for c in conf], "-o", ms=3.4, lw=1.4, color=col, label=lab)
    ax1.set_xlabel("confidence threshold")
    ax1.set_ylabel("metric")
    ax1.set_ylim(0.3, 0.65)
    ax1.grid(alpha=0.25, linewidth=0.5)
    ax1.legend(frameon=False, loc="lower right")
    if iou:
        xi = [r.get("iou") for r in iou]
        ax2.plot(xi, [r["F1"] for r in iou], "-o", ms=3.4, lw=1.5, color=C["purple"])
        ax2.set_xlabel("NMS IoU threshold")
        ax2.set_ylabel("F1")
        ax2.grid(alpha=0.25, linewidth=0.5)
        best = max(iou, key=lambda r: r["F1"])
        ax2.annotate(f"best {best['F1']:.3f}\n@ IoU {best['iou']}", (best["iou"], best["F1"]),
                     textcoords="offset points", xytext=(-56, -22), fontsize=7.2,
                     arrowprops={"arrowstyle": "->", "lw": 0.7, "color": C["grey"]})
    fig.tight_layout()
    save(fig, "fig14_threshold_tuning.png")


# ---------------------------------------------------------------- Fig. 16
def fig16_detector_comparison():
    """Detector comparison: mAP versus GFLOPs."""
    zoo = load("runs/e13_zoo/detector_zoo.json")
    fig, ax = plt.subplots(figsize=(4.6, 2.8))
    for i, r in enumerate(zoo):
        col = C["blue"] if i == 0 else C["grey"]
        ax.bar(i, r["mAP50_95"] * 100, 0.6, color=col)
        ax.text(i, r["mAP50_95"] * 100 + 0.5, f"{r['mAP50_95']*100:.2f}", ha="center", fontsize=7.6)
        ax.text(i, 1.2, f"{r['gflops']:.1f} GFLOPs\n{r['params_M']:.2f} M", ha="center", fontsize=6.6, color="white")
    ax.set_xticks(range(len(zoo)))
    ax.set_xticklabels([r["name"].replace(" + ", "+\n") for r in zoo], fontsize=8)
    ax.set_ylabel("mAP@[.50:.95] (%)")
    ax.set_ylim(0, 40)
    ax.grid(axis="y", alpha=0.25, linewidth=0.5)
    fig.tight_layout()
    save(fig, "fig16_detector_comparison.png")


# ---------------------------------------------------------------- Fig. 17 (new)
def fig17_second_dataset():
    """Second dataset: AP versus instance share, five-class and two-class settings."""
    suite = {r["tag"]: r for r in load("runs/metrics_suite/suite_20260915.json")}
    d5, d2 = suite["dsi5_yolo11n"], suite["dsi2_yolo11n"]
    share5 = dsi5_shares()
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(6.8, 2.7))
    names = [c["name"].replace("_", " ") for c in d5["per_class"]]
    aps = [c["AP50_95"] * 100 for c in d5["per_class"]]
    cols = [C["grey"], C["blue"], C["red"], C["orange"], C["blue"]]
    ax1.barh(range(len(names)), aps, color=cols)
    for i, (v, s) in enumerate(zip(aps, share5)):
        ax1.text(v + 0.8, i, f"{v:.2f}  ({s:.1f}% of inst.)", va="center", fontsize=7)
    ax1.set_yticks(range(len(names)))
    ax1.set_yticklabels(names, fontsize=8)
    ax1.invert_yaxis()
    ax1.set_xlabel("AP@[.50:.95] (%)")
    ax1.set_xlim(0, 78)
    ax1.grid(axis="x", alpha=0.25, linewidth=0.5)
    ax1.set_title("(a) DSI, five classes", fontsize=9)

    labels = [c["name"] for c in d2["per_class"]]
    vals = [c["AP50_95"] * 100 for c in d2["per_class"]]
    share2 = [78.3, 21.7]
    ax2.bar(labels, vals, 0.5, color=[C["blue"], C["orange"]])
    for i, (v, s) in enumerate(zip(vals, share2)):
        ax2.text(i, v + 0.8, f"{v:.2f}\n({s:.1f}%)", ha="center", fontsize=7.4)
    ax2.set_ylim(0, 56)
    ax2.set_ylabel("AP@[.50:.95] (%)")
    ax2.grid(axis="y", alpha=0.25, linewidth=0.5)
    ax2.set_title("(b) DSI, two classes", fontsize=9)
    fig.tight_layout()
    save(fig, "fig17_second_dataset.png")


# ---------------------------------------------------------------- Fig. 18 (new)
def fig18_method_experiments():
    """Method experiments: DACW, DAAA and DBJT summary."""
    rows = {r["tag"]: r for r in load("runs/e16_method/results.json")}
    fig, axes = plt.subplots(1, 3, figsize=(7.4, 2.6))

    ax = axes[0]
    names = ["baseline", "cls-prior\n(freq.)", "DACW\nβ=1", "DACW\nβ=2"]
    vals = [34.66, 33.92, 33.98, 34.09]
    errs = [0.37, 0.33, 0.18, 0.25]  # 3-seed SD
    cols = [C["grey"], C["red"], C["blue"], C["blue"]]
    ax.bar(range(4), vals, 0.6, color=cols, yerr=errs, capsize=2.2,
           error_kw={"elinewidth": 0.8, "ecolor": "#444444"})
    ax.axhline(34.66, color=C["grey"], ls=":", lw=1.0)
    for i, v in enumerate(vals):
        ax.text(i, v + 0.12, f"{v:.2f}", ha="center", fontsize=7.2)
    ax.set_xticks(range(4))
    ax.set_xticklabels(names, fontsize=7.6)
    ax.set_ylim(32.5, 35.2)
    ax.set_ylabel("mAP@[.50:.95] (%)")
    ax.set_title("(a) class weighting", fontsize=9)
    ax.grid(axis="y", alpha=0.25, linewidth=0.5)

    ax = axes[1]
    names = ["uniform", "frequency", "difficulty"]
    vals = [3.82, 3.04, 3.09]
    errs = [0.55, 0.49, 0.63]  # 3-seed SD
    ax.bar(range(3), vals, 0.55, color=[C["green"], C["red"], C["blue"]], yerr=errs, capsize=2.2,
           error_kw={"elinewidth": 0.8, "ecolor": "#444444"})
    for i, v in enumerate(vals):
        ax.text(i, v + 0.07, f"{v:.2f}", ha="center", fontsize=7.2)
    ax.set_xticks(range(3))
    ax.set_xticklabels(names, fontsize=8)
    ax.set_ylim(0, 4.8)
    ax.set_ylabel("mAP@[.50:.95] (%)")
    ax.set_title("(b) 25-image budget", fontsize=9)
    ax.grid(axis="y", alpha=0.25, linewidth=0.5)

    ax = axes[2]
    x = np.arange(2)
    w = 0.36
    natural = [37.76, 27.61]
    dbjt = [rows["dbjt_batch→A"]["mAP50_95"] * 100, rows["dbjt_batch→B"]["mAP50_95"] * 100]
    ax.bar(x - w / 2, natural, w, label="natural ratio", color=C["grey"])
    ax.bar(x + w / 2, dbjt, w, label="domain-balanced", color=C["blue"])
    for xi, v in zip(x - w / 2, natural):
        ax.text(xi, v + 0.5, f"{v:.2f}", ha="center", fontsize=7.2)
    for xi, v in zip(x + w / 2, dbjt):
        ax.text(xi, v + 0.5, f"{v:.2f}", ha="center", fontsize=7.2)
    ax.set_xticks(x)
    ax.set_xticklabels(["batch A test", "batch B test"], fontsize=8)
    ax.set_ylim(0, 46)
    ax.set_ylabel("mAP@[.50:.95] (%)")
    ax.set_title("(c) joint training", fontsize=9)
    ax.legend(frameon=False, fontsize=7.4, loc="upper right")
    ax.grid(axis="y", alpha=0.25, linewidth=0.5)

    fig.tight_layout()
    save(fig, "fig18_method_experiments.png")


# ---------------------------------------------------------------- Fig. 1
# Source note: runs/e6_kshot/kshot_results.json currently holds a single record (it was overwritten by a
# later single-method run), so the published K-shot table (Table 6 of the manuscript, itself computed by
# 15_kshot_matrix.py from the checkpoints still present under runs/e6_kshot/*_s42) is used verbatim here.
KS = {
    "full fine-tuning": ([1, 5, 10], [0.27, 4.54, 5.84], "o", C["blue"]),
    "LoRA r = 8": ([1, 5, 10], [0.07, 1.29, 2.96], "s", C["orange"]),
    "MoLoRA (4 experts)": ([1, 5, 10], [0.12, 0.71, 1.40], "^", C["green"]),
}


def fig1_kshot_boundary():
    """K-shot adaptation boundary (log scale)."""
    fig, ax = plt.subplots(figsize=(4.6, 3.2))
    for label, (ks, vs, mk, col) in KS.items():
        ax.semilogy(ks, vs, mk + "-", color=col, lw=1.6, ms=5, label=label)
        for x, y in zip(ks, vs):
            ax.annotate(f"{y:.2f}", (x, y), textcoords="offset points", xytext=(0, 7), ha="center", fontsize=7)
    ax.set_xlabel("training images per subclass (K)")
    ax.set_ylabel("mAP@[.50:.95] (%) — log scale")
    ax.set_xticks([1, 5, 10])
    ax.set_ylim(0.03, 12)
    ax.grid(alpha=0.25, which="both", linewidth=0.5)
    ax.legend(frameon=False, loc="upper left")
    fig.tight_layout()
    save(fig, "fig01_kshot_boundary.png")


# ---------------------------------------------------------------- Fig. 3
# Same configuration list as the Chinese renderer (40_render_paper_figures.py::ABLATION).
# Figure 3 数据：seed42 的三元组 (overall, spalling_large, crack_fine)。
# seeds 123/456 从 runs/e8_multi/results_multi.json 实时读取并计算均值±SD，
# 避免像旧版那样把数字写死在脚本里造成与论文不同步。
AUG_S42 = {
    "baseline": (34.34, 44.05, 29.17),
    "e7skl05": (34.32, 47.65, 28.83),
    "e7skl02": (34.51, 46.90, 29.10),
    "e7cp05": (33.61, 46.30, 28.10),
    "e7cpsk": (33.18, 44.30, 28.10),
    "e7fullcp": (33.59, 47.24, 27.28),
    "e7cpca": (34.18, 45.65, 29.00),
}
BASE_SEEDS = [(34.34, 44.05, 29.17), (35.06, 48.34, 29.43), (34.59, 48.39, 29.12)]  # seed 42/123/456
AUG_LABELS = [("baseline", "baseline"), ("skeleton\nλ = 0.5", "e7skl05"), ("skeleton\nλ = 0.2", "e7skl02"),
              ("Copy-Paste\nonly", "e7cp05"), ("CP +\nskeleton", "e7cpsk"),
              ("full +\nclass prior", "e7fullcp"), ("class-aware\nCopy-Paste", "e7cpca")]


def fig3_augmentation_ablation():
    """Augmentation ablation: overall, large-spalling and thin-crack AP (3-seed mean ± SD)."""
    import statistics as st

    multi = {r["name"]: r for r in load("runs/e8_multi/results_multi.json")}

    def triples(cfg):
        if cfg == "baseline":
            rows = list(BASE_SEEDS)
        else:
            rows = [AUG_S42[cfg]]
            for s in (123, 456):
                r = multi[f"{cfg}_s{s}"]
                rows.append((r["mAP50_95"] * 100,
                             r["per_class"]["spalling_large"]["ap50_95"] * 100,
                             r["per_class"]["crack_fine"]["ap50_95"] * 100))
        mean = [st.mean(x[i] for x in rows) for i in range(3)]
        sd = [st.stdev(x[i] for x in rows) for i in range(3)]
        return mean, sd

    data = [triples(cfg) for _, cfg in AUG_LABELS]
    x = np.arange(len(data))
    w = 0.27
    fig, ax = plt.subplots(figsize=(6.8, 2.9))
    for off, idx, lab, col in ((-w, 0, "overall mAP", C["blue"]),
                               (0, 1, "large spalling AP", C["orange"]),
                               (w, 2, "thin crack AP", C["green"])):
        vals = [d[0][idx] for d in data]
        errs = [d[1][idx] for d in data]
        ax.bar(x + off, vals, w, label=lab, color=col, yerr=errs, capsize=2.2,
               error_kw={"elinewidth": 0.8, "ecolor": "#444444"})
    ax.axhline(34.66, color=C["grey"], ls=":", lw=1.0)
    ax.set_xticks(x)
    ax.set_xticklabels([a[0] for a in AUG_LABELS], fontsize=7.6)
    ax.set_ylabel("AP@[.50:.95] (%)")
    ax.set_ylim(25, 51)
    ax.legend(frameon=False, ncol=3, loc="upper center")
    ax.grid(axis="y", alpha=0.25, linewidth=0.5)
    fig.tight_layout()
    save(fig, "fig03_augmentation_ablation.png")


# ---------------------------------------------------------------- Fig. 4
def fig4_kshot_diagnostic():
    """K = 5 diagnostic across adaptation families."""
    labels = ["full\nfine-tuning", "LoRA\nr = 8", "MoLoRA\n4 experts", "MoLoRA\n2 experts r = 4", "LoRA r = 32\n+ distillation"]
    vals = [4.54, 1.29, 0.71, 1.36, 0.04]
    fig, ax = plt.subplots(figsize=(5.4, 2.7))
    bars = ax.bar(range(len(vals)), vals, 0.6,
                  color=[C["blue"], C["orange"], C["green"], C["purple"], C["brown"]])
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.08, f"{v:.2f}", ha="center", fontsize=7.6)
    ax.set_xticks(range(len(labels)))
    ax.set_xticklabels(labels, fontsize=7.6)
    ax.set_ylabel("mAP@[.50:.95] (%)")
    ax.set_ylim(0, 5.6)
    ax.grid(axis="y", alpha=0.25, linewidth=0.5)
    fig.tight_layout()
    save(fig, "fig04_kshot_diagnostic.png")


# ---------------------------------------------------------------- Fig. 5
def fig5_training_curves():
    """Baseline training curves (validation metrics per epoch)."""
    rows = load("runs/e6_full/fullft_baseline/results.csv")
    ep = [int(float(r["epoch"])) for r in rows]
    fig, ax = plt.subplots(figsize=(5.0, 2.8))
    ax.plot(ep, [float(r["metrics/mAP50-95(B)"]) * 100 for r in rows], color=C["blue"], lw=1.6, label="mAP@[.50:.95]")
    ax.plot(ep, [float(r["metrics/mAP50(B)"]) * 100 for r in rows], color=C["orange"], lw=1.3, alpha=0.9, label="mAP50")
    ax.set_xlabel("epoch")
    ax.set_ylabel("validation metric (%)")
    ax.set_ylim(0, 62)
    ax.grid(alpha=0.25, linewidth=0.5)
    ax.legend(frameon=False, loc="lower right")
    fig.tight_layout()
    save(fig, "fig05_training_curves.png")


# ---------------------------------------------------------------- Fig. 6
def fig6_seed_reproducibility():
    """Multi-seed reproducibility of the baseline."""
    vals = {"seed 42": 34.34, "seed 123": 35.06, "seed 456": 34.59}
    try:
        for r in load("runs/e8_multi/results_multi.json"):
            if str(r.get("name", "")).startswith("e6full") and "seed" in r:
                vals[f"seed {r['seed']}"] = r["mAP50_95"] * 100
    except Exception:
        pass
    vals = dict(sorted(vals.items()))
    mean = float(np.mean(list(vals.values())))
    sd = float(np.std(list(vals.values()), ddof=1))
    labels = list(vals) + ["mean"]
    values = list(vals.values()) + [mean]
    fig, ax = plt.subplots(figsize=(4.4, 2.7))
    ax.bar(range(len(values)), values, 0.55, color=[C["blue"]] * (len(values) - 1) + [C["orange"]])
    for i, v in enumerate(values):
        ax.text(i, v + 0.05, f"{v:.2f}", ha="center", fontsize=7.6)
    ax.errorbar(len(values) - 1, mean, yerr=sd, fmt="none", ecolor="black", capsize=4, lw=1.0)
    ax.set_xticks(range(len(labels)))
    ax.set_xticklabels(labels, fontsize=8)
    ax.set_ylabel("mAP@[.50:.95] (%)")
    ax.set_ylim(33.5, 35.8)
    ax.grid(axis="y", alpha=0.25, linewidth=0.5)
    fig.tight_layout()
    save(fig, "fig06_seed_reproducibility.png")


# ---------------------------------------------------------------- Fig. 12
def fig12_per_class_ap():
    """Per-class AP50, AP75 and AP@[.50:.95] of the baseline."""
    suite = {r["tag"]: r for r in load("runs/metrics_suite/suite_20260915.json")}
    base = suite["baseline"]
    names = [c["name"].replace("_", " ") for c in base["per_class"]]
    x = np.arange(len(names))
    w = 0.27
    fig, ax = plt.subplots(figsize=(6.2, 2.8))
    ax.bar(x - w, [c["AP50"] * 100 for c in base["per_class"]], w, label="AP50", color=C["blue"])
    ax.bar(x, [c["AP75"] * 100 for c in base["per_class"]], w, label="AP75", color=C["orange"])
    ax.bar(x + w, [c["AP50_95"] * 100 for c in base["per_class"]], w, label="AP@[.50:.95]", color=C["green"])
    ax.set_xticks(x)
    ax.set_xticklabels(names, fontsize=8)
    ax.set_ylabel("AP (%)")
    ax.set_ylim(0, 80)
    ax.legend(frameon=False, ncol=3, loc="upper right")
    ax.grid(axis="y", alpha=0.25, linewidth=0.5)
    fig.tight_layout()
    save(fig, "fig12_per_class_ap.png")


# ---------------------------------------------------------------- Fig. 15
# Source: Table 10 of the manuscript / paper/跨批次泛化.md (runs/e12_cross_batch, runs/e6_full baseline).
CROSS = [("A -> A\n(in-domain)", 37.58, C["blue"]), ("A -> B\n(cross)", 11.85, C["red"]),
         ("B -> B\n(in-domain)", 24.97, C["blue"]), ("B -> A\n(cross)", 2.94, C["red"]),
         ("A+B -> A\n(merge)", 37.76, C["green"]), ("A+B -> B\n(merge)", 27.61, C["green"])]


def fig15_cross_batch():
    """Cross-batch generalization."""
    fig, ax = plt.subplots(figsize=(5.6, 2.8))
    bars = ax.bar(range(len(CROSS)), [c[1] for c in CROSS], 0.6, color=[c[2] for c in CROSS])
    for b, c in zip(bars, CROSS):
        ax.text(b.get_x() + b.get_width() / 2, c[1] + 0.7, f"{c[1]:.2f}", ha="center", fontsize=7.6)
    ax.set_xticks(range(len(CROSS)))
    ax.set_xticklabels([c[0] for c in CROSS], fontsize=7.4)
    ax.set_ylabel("mAP@[.50:.95] (%)")
    ax.set_ylim(0, 44)
    ax.grid(axis="y", alpha=0.25, linewidth=0.5)
    h = [plt.Line2D([], [], color=C["blue"], lw=6, label="in-domain"),
         plt.Line2D([], [], color=C["red"], lw=6, label="cross-batch"),
         plt.Line2D([], [], color=C["green"], lw=6, label="merged training")]
    ax.legend(handles=h, frameon=False, ncol=3, loc="upper center", fontsize=7.4)
    fig.tight_layout()
    save(fig, "fig15_cross_batch.png")


# ---------------------------------------------------------------- Fig. 19 (new)
def fig19_resolution_matrix():
    """Train/inference resolution matrix: matched vs mismatched deployment."""
    labels = ["640 / 640\n(baseline)", "896 / 896", "960 / 960", "896 / 640", "960 / 640", "896 / 960"]
    vals = [34.34, 35.89, 36.65, 33.54, 33.58, 35.96]
    gfl = ["6.4", "12.6", "14.5", "6.4", "6.4", "14.5"]
    cols = [C["grey"], C["blue"], C["blue"], C["red"], C["red"], C["blue"]]
    fig, ax = plt.subplots(figsize=(6.8, 2.9))
    ax.bar(range(len(vals)), vals, 0.6, color=cols)
    for i, v in enumerate(vals):
        ax.text(i, v + 0.25, f"{v:.2f}", ha="center", fontsize=7.6)
        ax.text(i, 1.0, f"{gfl[i]} GFLOPs", ha="center", fontsize=6.2, color="white")
    ax.axhline(34.34, color=C["grey"], ls=":", lw=1.0)
    ax.set_xticks(range(len(vals)))
    ax.set_xticklabels(labels, fontsize=7.6)
    ax.set_xlabel("training / inference input size (px)", fontsize=8)
    ax.set_ylabel("mAP@[.50:.95] (%)")
    ax.set_ylim(0, 40)
    ax.grid(axis="y", alpha=0.25, linewidth=0.5)
    fig.tight_layout()
    save(fig, "fig19_resolution_matrix.png")


FIGS = {
    "fig1": fig1_kshot_boundary,
    "fig2": fig2_frequency_vs_difficulty,
    "fig3": fig3_augmentation_ablation,
    "fig4": fig4_kshot_diagnostic,
    "fig5": fig5_training_curves,
    "fig6": fig6_seed_reproducibility,
    "fig7": fig7_imaging_envelope,
    "fig8": fig8_inference_remedies,
    "fig9": fig9_dataset_samples,
    "fig10": fig10_method_framework,
    "fig11": fig11_detection_results,
    "fig12": fig12_per_class_ap,
    "fig13": fig13_class_group_hm,
    "fig14": fig14_threshold_tuning,
    "fig15": fig15_cross_batch,
    "fig16": fig16_detector_comparison,
    "fig17": fig17_second_dataset,
    "fig18": fig18_method_experiments,
    "fig19": fig19_resolution_matrix,
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    args = ap.parse_args()
    todo = FIGS
    if args.only:
        keep = {s.strip() for s in args.only.split(",")}
        todo = {k: v for k, v in FIGS.items() if k in keep}
    for name, fn in todo.items():
        try:
            fn()
        except Exception as exc:  # noqa: BLE001
            print(f"[fig] {name} FAILED: {type(exc).__name__}: {exc}", flush=True)
    print(f"[fig] done -> {OUT}")


if __name__ == "__main__":
    main()
