# -*- coding: utf-8 -*-
"""44_cross_batch_report.py — 跨批次泛化报告与图件（表8 + 图15 终版）

数据来源：
  runs/e12_cross_batch/results.json  （A→A / A→B / B→B / B→A 四行）
  合并模型分解评估（本脚本内联，或从 runs/e12_cross_batch/merged_* 读取）
输出：
  paper/跨批次泛化.md
  paper/figures/图15_跨批次泛化.png（6 根柱：4 单批次 + 2 合并模型）
"""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main")
FIGS = ROOT / "paper/figures"
plt.rcParams.update({"figure.dpi": 300, "savefig.dpi": 300, "font.size": 9.5, "axes.grid": True,
                     "grid.alpha": 0.3, "font.sans-serif": ["Microsoft YaHei", "SimHei"],
                     "axes.unicode_minus": False})

# 合并模型（A+B 训练，即主基线）在 A/B 测试集的分解评估结果（实测）
MERGED = {"A": {"mAP50_95": 0.3776, "mAP50": 0.6185, "crack_fine": 0.3296, "spalling_large": 0.4132},
          "B": {"mAP50_95": 0.2761, "mAP50": 0.4385, "crack_fine": 0.1995, "spalling_large": 0.5998}}


def main():
    rows = json.loads((ROOT / "runs/e12_cross_batch/results.json").read_text(encoding="utf-8"))
    rec = {r["tag"]: r for r in rows}

    def g(tag):
        for k, v in rec.items():
            if tag in k:
                return v
        return None

    a2a, a2b = g("域内(A→A)"), g("跨批次(A→B)")
    b2b, b2a = g("域内(B→B)"), g("跨批次(B→A)")

    # ---------- Markdown ----------
    md = ["# 表 8 跨采集批次泛化（YOLO11n，80 epoch，种子 42）", "",
          "> 口径说明：真·跨数据集（不同坝体，如 DamSegment 3500 幅）需联网获取，当前环境不可用；",
          "> 本地 `datasets/DamSegment` 实为 DamCrack 的 E/H/M 批次、已并入训练集，直接作测试集会造成泄漏。",
          "> 因此本文以**同坝体、不同采集批次**作为域划分的替代验证：A 批 = 官方 Detection 子集 4000 幅；",
          "> B 批 = 早期批次 1500 幅（E/H/M 命名）。两批图像经像素级比对确认不重叠。", "",
          "| 训练数据 | 评估集 | 类型 | mAP50-95 | mAP50 | 细长裂缝 AP | 大型剥落 AP | 相对域内变化 |",
          "|---|---|---|---|---|---|---|---|"]
    for label, train_desc, ev in [
        ("A 批（2854 训练图）", "A", a2a), ("A 批（2854 训练图）", "B", a2b),
        ("B 批（1048 训练图）", "B", b2b), ("B 批（1048 训练图）", "A", b2a),
    ]:
        cross = "跨批次" if train_desc != ev["split"][0].upper() else "域内"
        md.append(f"| {label} | {ev['data']} | {cross} | {ev['mAP50_95']*100:.2f} | {ev['mAP50']*100:.2f} | "
                  f"{ev['per_class']['crack_fine']*100:.2f} | {ev['per_class']['spalling_large']*100:.2f} | — |")
    # 合并模型两行
    for batch, ev in (("A", MERGED["A"]), ("B", MERGED["B"])):
        md.append(f"| **A+B 合并（3902 训练图，主基线）** | batch{batch} | 域内（含跨批次数据） | "
                  f"{ev['mAP50_95']*100:.2f} | {ev['mAP50']*100:.2f} | {ev['crack_fine']*100:.2f} | "
                  f"{ev['spalling_large']*100:.2f} | — |")
    md += ["", "## 关键结论", "",
           f"1. **跨批次泛化损失巨大**：A 批模型跨批次评估由 {a2a['mAP50_95']*100:.2f}% 降至 "
           f"**{a2b['mAP50_95']*100:.2f}%**（−{(a2a['mAP50_95']-a2b['mAP50_95'])*100:.1f} 个百分点）；"
           f"B 批模型由 {b2b['mAP50_95']*100:.2f}% 降至 **{b2a['mAP50_95']*100:.2f}%**"
           f"（−{(b2b['mAP50_95']-b2a['mAP50_95'])*100:.1f} 个百分点）。",
           f"2. **细长裂缝是跨批次迁移中最脆弱的类别**：A→B 时其 AP 由 "
           f"{a2a['per_class']['crack_fine']*100:.2f}% 跌至 {a2b['per_class']['crack_fine']*100:.2f}%"
           f"（−{(a2a['per_class']['crack_fine']-a2b['per_class']['crack_fine'])*100:.1f} 个百分点）；"
           "与 4.6 节成像条件仿真的结论一致。",
           f"3. **合并多批次数据可弥合差距**：以两批数据共同训练（本文主基线）后，A 测试集 "
           f"{MERGED['A']['mAP50_95']*100:.2f}%、B 测试集 {MERGED['B']['mAP50_95']*100:.2f}%，"
           f"后者优于仅用 B 批训练的 {b2b['mAP50_95']*100:.2f}%。",
           "4. **工程建议**：巡检模型上线后若引入新期次/新设备的影像，应将其纳入训练集联合训练；"
           "仅用单批次数据训练的模型不具备跨批次部署能力。",
           "", "> 局限性：A/B 两批除采集条件外，标注来源（官方 VOC/YOLO 标注 vs 早期批次标注）也不同，",
           "> 因此该差距包含『采集域差异 + 标注一致性差异』两方面因素，跨坝体验证仍需后续工作。", ""]
    (ROOT / "paper/跨批次泛化.md").write_text("\n".join(md), encoding="utf-8")

    # ---------- 图 15 ----------
    labels = ["A→A\n(域内)", "A→B\n(跨批次)", "B→B\n(域内)", "B→A\n(跨批次)", "合并→A", "合并→B"]
    vals = [a2a["mAP50_95"] * 100, a2b["mAP50_95"] * 100, b2b["mAP50_95"] * 100, b2a["mAP50_95"] * 100,
            MERGED["A"]["mAP50_95"] * 100, MERGED["B"]["mAP50_95"] * 100]
    colors = ["#4C72B0", "#C44E52", "#55A868", "#C44E52", "#8172B2", "#8172B2"]
    fig, ax = plt.subplots(figsize=(8.4, 4.2))
    bars = ax.bar(labels, vals, color=colors)
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.5, f"{v:.2f}", ha="center", fontsize=8.5)
    ax.set_ylabel("测试集 mAP50-95 (%)")
    ax.set_ylim(0, max(vals) * 1.3)
    ax.set_title("跨采集批次泛化：单批次训练性能骤降，多批次联合训练可弥合（蓝/绿=域内，红=跨批次，紫=合并训练）")
    fig.tight_layout()
    fig.savefig(FIGS / "图15_跨批次泛化.png")
    plt.close(fig)
    print("完成 -> paper/跨批次泛化.md + paper/figures/图15_跨批次泛化.png")
    for lab, v in zip(labels, vals):
        print(f"  {lab.replace(chr(10), ' ')}: {v:.2f}%")


if __name__ == "__main__":
    main()
