# -*- coding: utf-8 -*-
"""merge_results.py — 合并三个模型各自的 summary.json 到 combined.json"""
import json
from pathlib import Path

DAMSEG_ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main\datasets\DamSegment")
RES = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main\experiments\damsegment_fewshot") / "results"

combined = {"mode": "full", "seed": 0, "results": {}}
for m in ("protonet", "maml", "meta_baseline"):
    p = RES / m / "summary.json"
    if p.exists():
        combined["results"][m] = json.loads(p.read_text(encoding="utf-8"))
        print(f"[+] {m}: {combined['results'][m].get('test_5way1shot', {})}")
    else:
        print(f"[!] 缺 {m}")

(RES / "combined.json").write_text(json.dumps(combined, indent=2, ensure_ascii=False), encoding="utf-8")
print(f"[OK] {RES / 'combined.json'}")
