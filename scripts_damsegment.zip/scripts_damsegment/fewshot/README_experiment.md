# DamSegment Few-Shot Learning 研究管线

基于 `Damage Detection` 数据集（1500 张 640×640 路面损伤图），构建 **5-way K-shot 学术 few-shot 分类基线**，
复现 ProtoNet / MAML / Meta-Baseline 三个经典模型。

## 总体流程

```
原始数据 (Damage Detection/)
  ├─ 01_split_dataset.py     → 8:1:1 分层切分 (1199/149/152) + 重命名 + dataset/ + data.yaml
  ├─ 02_subclass_mapping.py  → 大类 → 5 子类 (mapping.csv 可人工修订)
  ├─ 03_preview_subclasses.py→ 子类可视化校验 (pipeline/preview/)
  ├─ 04_extract_patches.py   → 实例 patch 提取 (fewshot/patch_data/, 84x84)
  ├─ 05_build_episodes.py    → 5-way K-shot episodes (fewshot/episodes/, K=1/5/10)
  └─ 06_report.py            → 结果报告 (fewshot/REPORT.md)

fewshot/
  ├─ common.py               → Conv-4 backbone、patch 数据集、评估协议
  ├─ models.py               → ProtoNet / MAML(FOMAML) / Meta-Baseline
  └─ train_fewshot.py        → 训练与评估入口
```

## 子类体系（N=5）

| ID | 名称 | 定义规则 | 框数 |
|---|---|---|---|
| 0 | crack_fine | 宽高比 ≥3 或 ≤1/3（细长） | 5690 |
| 1 | crack_network | 同图邻近裂纹框 ≥4（网状聚集） | 4864 |
| 2 | crack_blocky | 非细长、孤立粗裂缝 | 8675 |
| 3 | spalling_small | 剥落面积 < 4096 px² (64×64) | 144 |
| 4 | spalling_large | 剥落面积 ≥ 4096 px² | 337 |

> 自动规则仅作起点：编辑 `pipeline/mapping.csv` 的 `new_class` 列后运行
> `python 02_subclass_mapping.py --apply-csv` 即可人工修订。

## 运行

```bash
# Smoke（快速验证管线，~10 分钟）
python fewshot/train_fewshot.py --model protonet --mode smoke
python fewshot/train_fewshot.py --model maml --mode smoke
python fewshot/train_fewshot.py --model meta_baseline --mode smoke

# Full（正式基线，CPU 约 2-3 小时）
python fewshot/train_fewshot.py --model all --mode full

# 报告
python pipeline/06_report.py
```

## 环境

- Python 3.13, torch 2.12 (CPU), OpenCV 4.13
- Conv-4 backbone, 84×84 输入, ImageNet 归一化
