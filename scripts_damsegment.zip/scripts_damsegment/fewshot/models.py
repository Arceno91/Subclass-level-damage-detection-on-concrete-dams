# -*- coding: utf-8 -*-
"""models.py — ProtoNet / MAML(FOMAML) / Meta-Baseline 实现（PyTorch, CPU 友好）"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from common import Conv4, device


class ProtoNet(nn.Module):
    """Snell et al. 2017: 支持集原型 + 负欧氏距离分类"""

    def __init__(self, feature_dim=3200):
        super().__init__()
        self.encoder = Conv4(feature_dim)

    def forward(self, support, support_labels, query):
        # 原型（按类平均）
        feats = self.encoder(support)
        unique = torch.unique(support_labels)
        protos = torch.stack([feats[support_labels == c].mean(0) for c in range(unique.max().item() + 1)
                              if (support_labels == c).any()])
        qfeats = self.encoder(query)
        dist = torch.cdist(qfeats, protos)  # (Nq, Nc)
        logits = -dist
        return logits, protos

    @torch.no_grad()
    def predict(self, support, support_labels, query):
        logits, _ = self.forward(support, support_labels, query)
        return logits.argmax(1)


class MAML(nn.Module):
    """Finn et al. 2017 (FOMAML): meta-learned init; inner SGD loop on cloned params."""

    def __init__(self, feature_dim=3200, inner_lr=0.01, inner_steps=5, n_classes=5):
        super().__init__()
        self.encoder = Conv4(feature_dim)
        self.head = nn.Linear(feature_dim, n_classes)
        self.inner_lr = inner_lr
        self.inner_steps = inner_steps

    def _clone(self):
        """克隆元参数（从 state_dict），返回可独立训练的 (encoder, head)，保持 device"""
        enc = Conv4(self.encoder.feature_dim).to(device)
        enc.load_state_dict(self.encoder.state_dict())
        head = nn.Linear(self.head.in_features, self.head.out_features).to(device)
        head.load_state_dict(self.head.state_dict())
        return enc, head

    def _inner_loop(self, enc, head, support, support_labels, device_=device):
        """在克隆参数上内循环 SGD（正常建图，克隆为叶）。"""
        params = list(enc.parameters()) + list(head.parameters())
        opt = torch.optim.SGD(params, lr=self.inner_lr, momentum=0.9)
        for _ in range(self.inner_steps):
            opt.zero_grad()
            logits = head(enc(support))
            loss = torch.nn.functional.cross_entropy(logits, support_labels)
            loss.backward()
            opt.step()
        return enc, head

    def meta_step(self, batch_episodes, opt):
        """FOMAML 外循环：每个任务的 query 梯度（在克隆参数上）直接作为元参数梯度。"""
        opt.zero_grad()
        avg_loss = 0.0
        with torch.enable_grad():
            for ep in batch_episodes:
                sup, sl, que, ql = ep
                enc, head = self._clone()
                enc, head = self._inner_loop(enc, head, sup, sl)
                logits = head(enc(que))
                loss = torch.nn.functional.cross_entropy(logits, ql)
                avg_loss = avg_loss + loss
                # 元参数梯度 = 克隆参数梯度（一阶近似）
                meta_params = list(self.encoder.parameters()) + list(self.head.parameters())
                clone_params = list(enc.parameters()) + list(head.parameters())
                grads = torch.autograd.grad(loss, clone_params, allow_unused=True)
                for p, g in zip(meta_params, grads):
                    if g is None:
                        continue
                    if p.grad is None:
                        p.grad = torch.zeros_like(p)
                    p.grad.add_(g)
        avg_loss = avg_loss / len(batch_episodes)
        opt.step()
        return float(avg_loss.detach())

    @torch.no_grad()
    def predict_episode(self, support, support_labels, query):
        """Meta-test：克隆元参数内循环微调，再预测。"""
        enc, head = self._clone()
        with torch.enable_grad():
            enc, head = self._inner_loop(enc, head, support, support_labels)
            logits = head(enc(query))
        return logits.argmax(1)


class MetaBaseline(nn.Module):
    """Chen et al. 2021: 全局预训练 + episode 级微调（无 meta-train）"""

    def __init__(self, feature_dim=3200, n_classes=5, inner_lr=0.01, inner_steps=20):
        super().__init__()
        self.encoder = Conv4(feature_dim)
        self.head = nn.Linear(feature_dim, n_classes)
        self.inner_lr = inner_lr
        self.inner_steps = inner_steps

    @torch.no_grad()
    def predict_episode(self, support, support_labels, query):
        enc = Conv4(self.encoder.feature_dim).to(device)
        enc.load_state_dict(self.encoder.state_dict())
        head = nn.Linear(self.head.in_features, self.head.out_features).to(device)
        head.load_state_dict(self.head.state_dict())
        params = list(enc.parameters()) + list(head.parameters())
        opt = torch.optim.SGD(params, lr=self.inner_lr, momentum=0.9)
        with torch.enable_grad():
            for _ in range(self.inner_steps):
                opt.zero_grad()
                loss = F.cross_entropy(head(enc(support)), support_labels)
                loss.backward()
                opt.step()
            logits = head(enc(query))
        return logits.argmax(1)
