# -*- coding: utf-8 -*-
"""
train_fewshot.py — 训练与评估 ProtoNet / MAML / Meta-Baseline（5-way, K=1/5/10）

用法:
  python train_fewshot.py --model protonet --mode smoke
  python train_fewshot.py --model maml --mode smoke
  python train_fewshot.py --model meta_baseline --mode smoke
  python train_fewshot.py --model all --mode full
输出: fewshot/results/{model}/summary.json + 训练日志
"""
import argparse
import json
import random
import time
from pathlib import Path

import torch

from common import (PatchStore, N_CLASSES, CLASS_NAMES, load_episodes, sample_episode,
                    evaluate_episodes, device)
from models import ProtoNet, MAML, MetaBaseline

DAMSEG_ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main\datasets\DamSegment")
EXPL = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main\experiments\damsegment_fewshot")
RESULT_DIR = EXPL / "results"
N_WAY = 5
KS = (1, 5, 10)


def set_seed(seed):
    random.seed(seed)
    torch.manual_seed(seed)


def train_protonet(store, epochs=2000, lr=1e-3, log_every=200, seed=0, verbose=True):
    """元训练，返回模型；Meta-train episodes 在线采样（K=5 训练）"""
    set_seed(seed)
    model = ProtoNet().to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    t0 = time.time()
    losses = []
    for ep_i in range(epochs):
        eps = sample_episode(store, "train", N_WAY, k_shot=5, n_query=15, rng=random.Random(ep_i + seed))
        sup, sl = eps["support"].to(device), eps["support_labels"].to(device)
        que, ql = eps["query"].to(device), eps["query_labels"].to(device)
        opt.zero_grad()
        logits, _ = model(sup, sl, que)
        loss = torch.nn.functional.cross_entropy(logits, ql)
        loss.backward()
        opt.step()
        losses.append(float(loss))
        if verbose and (ep_i + 1) % log_every == 0:
            print(f"  ep {ep_i+1}/{epochs} loss={losses[-1]:.4f} avg={sum(losses[-50:])/len(losses[-50:]):.4f} "
                  f"time={time.time()-t0:.0f}s")
    return model


def train_maml(store, epochs=500, lr=1e-3, meta_bs=4, inner_lr=0.01, inner_steps=3, seed=0, verbose=True):
    set_seed(seed)
    model = MAML(inner_lr=inner_lr, inner_steps=inner_steps, n_classes=N_CLASSES).to(device)
    opt = torch.optim.Adam([p for p in model.parameters() if p.requires_grad], lr=lr)
    t0 = time.time()
    for ep_i in range(epochs):
        batch = []
        for b in range(meta_bs):
            eps = sample_episode(store, "train", N_WAY, k_shot=5, n_query=8, rng=random.Random(ep_i * 100 + b + seed))
            batch.append((eps["support"].to(device), eps["support_labels"].to(device),
                          eps["query"].to(device), eps["query_labels"].to(device)))
        loss = model.meta_step(batch, opt)
        if verbose and (ep_i + 1) % 50 == 0:
            print(f"  ep {ep_i+1}/{epochs} loss={loss:.4f} time={time.time()-t0:.0f}s")
    return model


def train_meta_baseline(store, epochs=30, lr=0.01, batch=64, inner_steps=15, seed=0, verbose=True):
    """全局预训练（softmax 分类所有类）"""
    set_seed(seed)
    mb = MetaBaseline(n_classes=N_CLASSES, inner_steps=inner_steps).to(device)
    opt = torch.optim.SGD(list(mb.encoder.parameters()) + list(mb.head.parameters()), lr=lr, momentum=0.9)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    # 组一批训练样本（简化：全部载入）
    Xs, Ys = [], []
    rng = random.Random(seed)
    for c in sorted(store.by_split["train"].keys()):
        for p in store.by_split["train"][c]:
            Xs.append(p); Ys.append(c)
    idxs = list(range(len(Xs)))
    t0 = time.time()
    for epoch in range(epochs):
        rng.shuffle(idxs)
        running = 0.0
        nb = 0
        for i in range(0, len(idxs), batch):
            batch_idx = idxs[i:i + batch]
            from common import to_float_tensor
            x = torch.stack([to_float_tensor(store.get(Xs[j])).squeeze(0) for j in batch_idx]).to(device)
            y = torch.tensor([Ys[j] for j in batch_idx]).to(device)
            opt.zero_grad()
            logits = mb.head(mb.encoder(x))
            loss = torch.nn.functional.cross_entropy(logits, y)
            loss.backward()
            opt.step()
            running += float(loss)
            nb += 1
        sched.step()
        if verbose:
            print(f"  epoch {epoch+1}/{epochs} loss={running/max(nb,1):.4f} time={time.time()-t0:.0f}s")
    return mb


def evaluate(model_or_mb, store, split, k_shot, n_episodes, name, max_ep=None):
    eps, files = load_episodes(split, N_WAY, k_shot, max_ep=n_episodes)
    if name == "protonet":
        fn = lambda sup, sl, que, ql: model_or_mb.predict(sup, sl, que)
    elif name == "maml":
        fn = lambda sup, sl, que, ql: model_or_mb.predict_episode(sup, sl, que)
    elif name == "meta_baseline":
        fn = lambda sup, sl, que, ql: model_or_mb.predict_episode(sup, sl, que)
    else:
        raise ValueError(name)
    m, ci = evaluate_episodes(fn, eps, store, device, desc=f"{split}/{k_shot}shot")
    return m, ci


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="all", choices=["protonet", "maml", "meta_baseline", "all"])
    ap.add_argument("--mode", default="smoke", choices=["smoke", "full"])
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    store = PatchStore(cache=True)
    print(f"PatchStore: train 各class { {c: len(store.by_split['train'].get(c, [])) for c in range(5)} }")
    print(f"device: {device}")
    print(f"mode: {args.mode}")

    # 训练规模（smoke 用于验证管线，full 用于正式基线）
    if args.mode == "smoke":
        TRAIN_CFG = {"protonet": {"epochs": 200, "log_every": 50},
                     "maml": {"epochs": 40, "meta_bs": 2, "inner_steps": 2},
                     "meta_baseline": {"epochs": 1, "inner_steps": 10}}
        N_EVAL = 10
    else:
        TRAIN_CFG = {"protonet": {"epochs": 3000, "log_every": 300},
                     "maml": {"epochs": 800, "meta_bs": 4, "inner_steps": 4, "inner_lr": 0.01},
                     "meta_baseline": {"epochs": 30, "inner_steps": 15}}
        N_EVAL = 300

    models_to_run = ["protonet", "maml", "meta_baseline"] if args.model == "all" else [args.model]
    summary = {"mode": args.mode, "seed": args.seed, "results": {}}

    for name in models_to_run:
        out_dir = RESULT_DIR / name
        out_dir.mkdir(parents=True, exist_ok=True)
        print(f"\n{'='*60}\n=== 训练 {name} ===\n{'='*60}")
        t0 = time.time()
        if name == "protonet":
            model = train_protonet(store, **TRAIN_CFG["protonet"], seed=args.seed)
            torch.save(model.state_dict(), out_dir / "model.pt")
        elif name == "maml":
            model = train_maml(store, **TRAIN_CFG["maml"], seed=args.seed)
            torch.save(model.state_dict(), out_dir / "model.pt")
        else:
            model = train_meta_baseline(store, **TRAIN_CFG["meta_baseline"], seed=args.seed)
            torch.save(model.state_dict(), out_dir / "model.pt")
        train_sec = time.time() - t0

        res = {"train_sec": round(train_sec, 1)}
        for split in ("val", "test"):
            for k in KS:
                m, ci = evaluate(model, store, split, k, N_EVAL, name)
                res[f"{split}_5way{k}shot"] = {"acc": round(m * 100, 2), "ci95": round(ci * 100, 2)}
                print(f"  {split} 5-way {k}-shot: acc={m*100:.2f}% ± {ci*100:.2f}%")
        summary["results"][name] = res
        with (out_dir / "summary.json").open("w", encoding="utf-8") as f:
            json.dump(res, f, indent=2, ensure_ascii=False)

    (RESULT_DIR / "combined.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"\n[OK] 结果汇总: {RESULT_DIR / 'combined.json'}")


if __name__ == "__main__":
    main()
