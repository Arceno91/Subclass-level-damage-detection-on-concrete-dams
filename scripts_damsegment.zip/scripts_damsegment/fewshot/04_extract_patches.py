# -*- coding: utf-8 -*-
"""
04_extract_patches.py — 从 dataset 提取实例 patch（few-shot 分类的数据单位）

- 输入：pipeline/mapping.csv（每个 bbox 的子类）
- 输出：fewshot/patch_data/{split}/{class}/{image}_{box_index}.jpg  (84x84, 方形化)
        fewshot/patch_data/manifest.csv
- 方形化：以 bbox 长边为准扩成正方形（含 20% 上下文），保持宽高比不变形
"""
import csv
from pathlib import Path

import cv2
import numpy as np

DAMSEG_ROOT = Path(r"E:\Arceno\\harmess\\project\\YOLO-PEFT-main\\datasets\\DamSegment")
ROOT = DAMSEG_ROOT
DST = DAMSEG_ROOT
MAPPING = DAMSEG_ROOT / "metadata" / "mapping.csv"
OUT = DAMSEG_ROOT / "patch_data"
PATCH = 84
CTX = 1.4  # 长边放大系数（20% 上下文）


def main():
    with MAPPING.open(encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    print(f"mapping 行数: {len(rows)}")

    manifest_path = OUT / "manifest.csv"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest = open(manifest_path, "w", encoding="utf-8", newline="")
    mw = csv.DictWriter(manifest, fieldnames=[
        "patch_file", "split", "cls", "source_image", "box_index",
        "new_class", "area_px", "aspect_ratio",
    ])
    mw.writeheader()

    import collections
    counter = collections.Counter()
    for r in rows:
        split, image, bi = r["split"], r["image"], int(r["box_index"])
        cls = int(r["new_class"])
        img = cv2.imread(str(DST / "images" / split / image))
        if img is None:
            continue
        H, W = img.shape[:2]
        cx, cy = float(r["cx"]) * W, float(r["cy"]) * H
        w, h = float(r["w"]) * W, float(r["h"]) * H
        side = max(w, h) * CTX
        x1 = int(round(cx - side / 2))
        y1 = int(round(cy - side / 2))
        x1, y1 = max(0, x1), max(0, y1)
        x2, y2 = min(W, x1 + int(side)), min(H, y1 + int(side))
        if x2 - x1 < 4 or y2 - y1 < 4:
            x2, y2 = min(W, x1 + 8), min(H, y1 + 8)
        patch = img[y1:y2, x1:x2]
        if patch.shape[0] != patch.shape[1]:
            # 拉到正方形（短边用边缘复制或中心填充，保持主要内容不变形）
            psz = max(patch.shape[:2])
            canvas = np.zeros((psz, psz, 3), dtype=np.uint8)
            ox = (psz - patch.shape[1]) // 2
            oy = (psz - patch.shape[0]) // 2
            canvas[oy:oy + patch.shape[0], ox:ox + patch.shape[1]] = patch
            patch = canvas
        patch = cv2.resize(patch, (PATCH, PATCH), interpolation=cv2.INTER_AREA)
        out_dir = OUT / split / str(cls)
        out_dir.mkdir(parents=True, exist_ok=True)
        fname = f"{Path(image).stem}_{bi:03d}.jpg"
        cv2.imwrite(str(out_dir / fname), patch, [cv2.IMWRITE_JPEG_QUALITY, 95])
        mw.writerow({
            "patch_file": f"{split}/{cls}/{fname}", "split": split, "cls": cls,
            "source_image": image, "box_index": bi, "new_class": cls,
            "area_px": r["area_px"], "aspect_ratio": r["aspect_ratio"],
        })
        counter[(split, cls)] += 1

    manifest.close()
    print("\n=== patch 统计 (split, cls) -> 数量 ===")
    for (s, c), n in sorted(counter.items()):
        print(f"  {s:<6} class{c}: {n}")
    total = sum(counter.values())
    print(f"总计: {total}")
    print(f"\n[OK] 输出: {OUT}")


if __name__ == "__main__":
    main()
