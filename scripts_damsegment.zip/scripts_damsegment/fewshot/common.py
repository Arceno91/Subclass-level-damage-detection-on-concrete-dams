# -*- coding: utf-8 -*-
"""common.py — few-shot 公共组件：Conv-4 backbone、patch 数据集、episode 采样与评估"""
import csv
import math
import random
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

DAMSEG_ROOT = Path(r"E:\Arceno\harmess\project\YOLO-PEFT-main\datasets\DamSegment")
ROOT = DAMSEG_ROOT
PATCH_DIR = DAMSEG_ROOT / "patch_data"
MANIFEST = PATCH_DIR / "manifest.csv"
EPISODE_DIR = DAMSEG_ROOT / "episodes"
PATCH_SIZE = 84
N_CLASSES = 5
CLASS_NAMES = ["crack_fine", "crack_network", "crack_blocky", "spalling_small", "spalling_large"]

# ImageNet 归一化
MEAN = np.array([0.485, 0.456, 0.406], dtype=np.float32)
STD = np.array([0.229, 0.224, 0.225], dtype=np.float32)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class Conv4(nn.Module):
    """miniImageNet 标准 Conv-4: 64-64-128-128, Conv3x3+BN+ReLU+MaxPool"""

    def __init__(self, feature_dim=3200):
        super().__init__()
        self.feature_dim = feature_dim
        blocks = []
        in_c = 3
        for out_c in (64, 64, 128, 128):
            blocks += [nn.Conv2d(in_c, out_c, 3, padding=1), nn.BatchNorm2d(out_c), nn.ReLU(inplace=True),
                       nn.MaxPool2d(2)]
            in_c = out_c
        self.encoder = nn.Sequential(*blocks)

    def forward(self, x):
        return self.encoder(x).flatten(1)


def normalize_img(img_bgr):
    """BGR uint8 (H,W,3) -> RGB float tensor (3,H,W)"""
    rgb = img_bgr[:, :, ::-1].astype(np.float32) / 255.0
    rgb = (rgb - MEAN) / STD
    return torch.from_numpy(rgb.transpose(2, 0, 1).copy())


class PatchStore:
    """将 manifest 中的 patch 全部预载入内存（uint8），支持按 split/class 查询"""

    def __init__(self, cache=True):
        self.by_split = {"train": {}, "val": {}, "test": {}}  # cls -> list[(tensor, cls)]
        self.by_path = {}
        rows = list(csv.DictReader(MANIFEST.open(encoding="utf-8")))
        for row in rows:
            split, cls = row["split"], int(row["cls"])
            p = PATCH_DIR / row["patch_file"]
            self.by_path[row["patch_file"]] = (split, cls)
            self.by_split[split].setdefault(cls, []).append(row["patch_file"])
        self.imgs = {}
        if cache:
            for k in self.by_path:
                img = cv2.imread(str(PATCH_DIR / k))
                if img is not None:
                    rgb = img[:, :, ::-1].copy()  # BGR->RGB uint8
                    self.imgs[k] = torch.from_numpy(rgb.transpose(2, 0, 1).copy())  # (3,H,W) uint8

    def get(self, path):
        return self.imgs[path]

    def classes_by_split(self, split):
        return sorted(self.by_split[split].keys())


def to_float_tensor(t_uint8):
    """(3,H,W) uint8 -> (1,3,H,W) float normalized"""
    x = t_uint8.float().unsqueeze(0)
    m = torch.tensor(MEAN, device=x.device).view(1, 3, 1, 1)
    s = torch.tensor(STD, device=x.device).view(1, 3, 1, 1)
    return (x / 255.0 - m) / s


def sample_episode(store, split, n_way, k_shot, n_query=15, rng=None, augment=False):
    """在线采样一个 episode（train 用）。support 无放回，query 从剩余抽。"""
    rng = rng or random.Random()
    classes = []
    for c in range(n_way):
        pool = store.by_split[split].get(c, [])
        if len(pool) >= k_shot + 1:
            classes.append(c)
    if len(classes) < n_way:
        # 回退：允许同一 class 复用（数据极端不足时）
        classes = list(range(n_way))
    rng.shuffle(classes)
    sup_imgs, sup_labels, q_imgs, q_labels = [], [], [], []
    for c in classes[:n_way]:
        pool = store.by_split[split].get(c, [])[:]
        rng.shuffle(pool)
        sup = pool[:k_shot]
        que = pool[k_shot:k_shot + n_query]
        sup_imgs += [store.get(p) for p in sup]
        sup_labels += [c] * k_shot
        q_imgs += [store.get(p) for p in que]
        q_labels += [c] * len(que)
    return {
        "support": torch.stack([to_float_tensor(t) for t in sup_imgs]).squeeze(1),
        "support_labels": torch.tensor(sup_labels),
        "query": torch.stack([to_float_tensor(t) for t in q_imgs]).squeeze(1),
        "query_labels": torch.tensor(q_labels),
    }


def load_episodes(split, n_way, k_shot, max_ep=None):
    """读预生成的 episodes（val/test）"""
    d = EPISODE_DIR / split / f"{n_way}way{k_shot}shot"
    files = sorted(d.glob("ep_*.json"))
    if max_ep:
        files = files[:max_ep]
    eps = [json_load(f) for f in files]
    return eps, files


def json_load(path):
    import json
    return json.loads(path.read_text(encoding="utf-8"))


def episode_to_tensors(ep, store, device_):
    sup = torch.stack([to_float_tensor(store.get(x["path"])).squeeze(0) for x in ep["support"]])
    que = torch.stack([to_float_tensor(store.get(x["path"])).squeeze(0) for x in ep["query"]])
    sl = torch.tensor([x["cls"] for x in ep["support"]])
    ql = torch.tensor([x["cls"] for x in ep["query"]])
    return sup.to(device_), sl.to(device_), que.to(device_), ql.to(device_)


def mean_ci(accs):
    a = np.array(accs, dtype=np.float64)
    m = a.mean()
    if len(a) > 1:
        se = a.std(ddof=1) / math.sqrt(len(a))
        ci = 1.96 * se
    else:
        ci = 0.0
    return m, ci


def evaluate_episodes(model_fn, episodes, store, device_, desc=""):
    """model_fn(episode_tensors) -> accuracy float"""
    accs = []
    with torch.no_grad():
        for i, ep in enumerate(episodes):
            sup, sl, que, ql = episode_to_tensors(ep, store, device_)
            pred = model_fn(sup, sl, que, ql)
            accs.append(float((pred == ql).float().mean()))
    m, ci = mean_ci(accs)
    return m, ci
