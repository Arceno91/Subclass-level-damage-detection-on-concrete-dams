# -*- coding: utf-8 -*-
"""
05_build_episodes.py — 构建 N-way K-shot episode 数据集

- 从 fewshot/patch_data/manifest.csv 读所有 patch
- 为 val / test 各生成 {K}shot 的固定 episodes（K=1,5,10），每类 adaptive query
- train 集 episodes 不预生成，训练时在线采样
- 输出：fewshot/episodes/{split}/5way{K}shot/ep_{i:04d}.json
        fewshot/episodes/summary.json
"""
import csv
import json
import random
from pathlib import Path

DAMSEG_ROOT = Path(r"E:\Arceno\\harmess\\project\\YOLO-PEFT-main\\datasets\\DamSegment")
OUT = DAMSEG_ROOT / "episodes"
MANIFEST = DAMSEG_ROOT / "patch_data" / "manifest.csv"
SPLITS = ("val", "test")
KS = (1, 5, 10)
N_WAY = 5
N_EPISODES = 600
SEED = 123


def load_pools():
    pools = {}
    with MANIFEST.open(encoding="utf-8") as f:
        for row in csv.DictReader(f):
            key = (row["split"], int(row["cls"]))
            pools.setdefault(key, []).append(row["patch_file"])
    return pools


def main():
    pools = load_pools()
    rng = random.Random(SEED)
    summary = {}
    for split in SPLITS:
        for k in KS:
            out_dir = OUT / split / f"{N_WAY}way{k}shot"
            out_dir.mkdir(parents=True, exist_ok=True)
            # 每个类样本池
            cls_pool = {c: pools.get((split, c), []) for c in range(N_WAY)}
            # 检查样本充足性
            for c in range(N_WAY):
                n = len(cls_pool[c])
                n_query = min(15, max(5, n - k))
                if n < k + 5:
                    print(f"[WARN] {split} class{c}: {n} 个，K={k} 时 support+query 可能不足 (n_query={n_query})")
            episodes = []
            for ep in range(N_EPISODES):
                support, query = [], []
                for c in range(N_WAY):
                    pool = cls_pool[c][:]
                    rng.shuffle(pool)
                    n_query = min(15, max(5, len(pool) - k))
                    sup = pool[:k]
                    que = pool[k:k + n_query]
                    support.extend([{"path": p, "cls": c} for p in sup])
                    query.extend([{"path": p, "cls": c} for p in que])
                ep_file = out_dir / f"ep_{ep:04d}.json"
                ep_file.write_text(json.dumps(
                    {"split": split, "n_way": N_WAY, "k_shot": k,
                     "support": support, "query": query}, ensure_ascii=False),
                    encoding="utf-8")
                episodes.append(str(ep_file))
            summary[f"{split}/5way{k}shot"] = {
                "episodes": N_EPISODES,
                "k_shot": k,
                "support_per_class": k,
                "query_per_class": min(15, max(5, cls_pool[3] and len(cls_pool[3]) - k)),
                "counts": {str(c): len(cls_pool[c]) for c in range(N_WAY)},
            }
            print(f"{split}/5way{k}shot: {N_EPISODES} episodes OK")
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[OK] 输出: {OUT}")


if __name__ == "__main__":
    main()
