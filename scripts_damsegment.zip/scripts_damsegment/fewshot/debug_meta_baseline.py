# -*- coding: utf-8 -*-
"""debug_meta_baseline.py — 诊断 Meta-Baseline 预训练不收敛的原因"""
import random
import sys
from pathlib import Path

import torch

sys.path.insert(0, str(Path(__file__).parent))
from common import PatchStore, to_float_tensor, device, N_CLASSES
from models import MetaBaseline


def run_once(lr, epochs=3, batch=64, wd=0.0, label_smooth=0.0):
    store = PatchStore(cache=True)
    Xs, Ys = [], []
    for c in sorted(store.by_split["train"].keys()):
        for p in store.by_split["train"][c]:
            Xs.append(p); Ys.append(c)
    idxs = list(range(len(Xs)))
    rng = random.Random(0)

    mb = MetaBaseline(n_classes=N_CLASSES).to(device)
    opt = torch.optim.SGD(list(mb.encoder.parameters()) + list(mb.head.parameters()),
                          lr=lr, momentum=0.9, weight_decay=wd)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)

    print(f"\n--- lr={lr} wd={wd} smooth={label_smooth} ---")
    for e in range(epochs):
        rng.shuffle(idxs)
        total, nb, gnorm = 0.0, 0, 0.0
        for i in range(0, len(idxs), batch):
            b = idxs[i:i + batch]
            x = torch.stack([to_float_tensor(store.get(Xs[j])).squeeze(0) for j in b]).to(device)
            y = torch.tensor([Ys[j] for j in b]).to(device)
            opt.zero_grad()
            logits = mb.head(mb.encoder(x))
            loss = torch.nn.functional.cross_entropy(logits, y, label_smoothing=label_smooth)
            loss.backward()
            g = sum(p.grad.detach().abs().mean().item() for p in mb.parameters() if p.grad is not None)
            gnorm += g
            opt.step()
            total += float(loss); nb += 1
            if nb % 100 == 0:
                print(f"  e{e} step{nb} loss={float(loss):.4f} grad={g:.5f} lr={opt.param_groups[0]['lr']:.5f}")
        sched.step()
        print(f"  epoch {e+1}/{epochs} loss={total/nb:.4f} grad_avg={gnorm/nb:.5f}")


if __name__ == "__main__":
    for lr, wd, sm in [(0.1, 0.0, 0.0), (0.01, 0.0, 0.0), (0.1, 1e-4, 0.0)]:
        run_once(lr=lr, epochs=3, wd=wd, label_smooth=sm)
